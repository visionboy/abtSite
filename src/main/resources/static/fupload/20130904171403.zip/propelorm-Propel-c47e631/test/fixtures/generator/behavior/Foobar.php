<?php
namespace Foobar\Behavior;

/**
 * dummy class to test loading of namespaces behavior
 */
class Foobar extends \Behavior
{

}
