<?php

namespace Foo\Test;

/**
 * Fake class
 */
class FoobarWithNS
{
}
