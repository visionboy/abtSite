<?php
	session_start();
	require('inc/comm.php');
	$smarty->display('join.html');
?>