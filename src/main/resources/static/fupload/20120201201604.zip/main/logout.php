<?php session_start();?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php
//session_unset;
session_destroy();
echo "<script>alert('�α׾ƿ��Ǿ����ϴ�.');location.href='board.php';</script>";
 ?>