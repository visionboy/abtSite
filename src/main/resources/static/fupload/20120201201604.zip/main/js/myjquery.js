// ���� �� �����Ͽ� ���߰� ��ư �����ϱ�
$(document).ready(function(){
  $("#sc2").click(function(){
  $("#addteam").css("display","block");
  });
// ������ Ŭ��
$("#uposter1").click(function(){
//  $("#filedv").css("display","none");
//  $("#filetext").css("display","block");
  $("#postp").css("display","block");
  $("#slogp").css("display","none");
  var frm1 = document.fregisterfrm;
  frm1.ckps.value = 1;
});

// ���ΰ� Ŭ��
$("#uposter2").click(function(){
//  $("#filedv").css("display","block");
//  $("#filetext").css("display","none");
  $("#postp").css("display","none");
  $("#slogp").css("display","block");
  var frm1 = document.fregisterfrm;
  frm1.ckps.value = 2;
});


// ������ �ٽ� Ŭ���Ͽ����� ���߰� ��ư ���߱� 
  $("#sc1").click(function(){
 
  var frm1 = document.fregisterfrm;
  frm1.showteam.value = 0;
  frm1.cot.value = 0;
  frm1.destatus.value = "";
// �ش翵�� ��ǪƮ �� ��� �ʱ�ȭ ó��	
  frm1.sbname1.value = "";
  frm1.sbju1.value = "";
  frm1.sbtju1.value = "";
  frm1.sbaddr1.value = "";
  frm1.sbp1.value = "";
  frm1.sbop1.value = "";
  frm1.sbtp1.value = "";
  frm1.sbt1.value = "";
  frm1.sbot1.value = "";
  frm1.sbtt1.value = "";
  frm1.sbomail1.value = "";
  frm1.sbtmail1.value = "";
  frm1.sbsemail1.value = "";
  frm1.sbss1.value = "";
  frm1.sbst1.value = "";
  frm1.sbname2.value = "";
  frm1.sbju2.value = "";
  frm1.sbtju2.value = "";
  frm1.sbaddr2.value = "";
  frm1.sbp2.value = "";
  frm1.sbop2.value = "";
  frm1.sbtp2.value = "";
  frm1.sbt2.value = "";
  frm1.sbot2.value = "";
  frm1.sbtt2.value = "";
  frm1.sbomail2.value = "";
  frm1.sbtmail2.value = "";
  frm1.sbsemail2.value = "";
  frm1.sbss2.value = "";
  frm1.sbtt2.value = "";
  $("#addteam").css("display","none");
  $("#sumt1").css("display","none");
  $("#sumt2").css("display","none");
  });
  
// ����ư �߰��� �׼��Դϴ�.  
  $("#addteam").click(function(){
  var frm1 = document.fregisterfrm;
  var count = frm1.cot.value;
  if (Number(count) == 0)
					{
						frm1.cot.value = Number(count) + 1;
						var countf = frm1.cot.value;
						
						frm1.showteam.value = 1;
						$("#sumt1").css("display","block");
						var showid = frm1.showteam.value;
					//	alert(showid);
					//	alert(countf);
					}
  else if (Number(count) == 1)
					{
						
						frm1.cot.value = Number(count) + 1;
						var countf = frm1.cot.value;
						var de = frm1.destatus.value;
							if (Number(de) == 1)
							{
								$("#sumt1").css("display","block");
							}
							
						frm1.showteam.value = 3;
						var showid = frm1.showteam.value;
						
						$("#sumt2").css("display","block");
						//alert(showid);
					//	alert(countf);
					}
  else
  					{
						alert('������ �ִ� 2������ �߰������մϴ�!');
					}
  });

// ���� ���� ��ũ��Ʈ�Դϴ�
  $("#de1").click(function(){
  $("#sumt1").css("display","none");
  var frm1 = document.fregisterfrm;
  var count = frm1.cot.value;
  frm1.cot.value = Number(count) - 1;
  var countf = frm1.cot.value;
  
  frm1.destatus.value = 1;

  // �ش翵�� ��ǪƮ �� ��� �ʱ�ȭ ó��	
  frm1.sbname1.value = "";
  frm1.sbju1.value = "";
  frm1.sbtju1.value = "";
  frm1.sbname1.readOnly	= false;
  frm1.sbju1.readOnly	= false;
  frm1.sbtju1.readOnly	= false;
  frm1.sbaddr1.value = "";
  frm1.sbp1.value = "";
  frm1.sbop1.value = "";
  frm1.sbtp1.value = "";
  frm1.sbt1.value = "";
  frm1.sbot1.value = "";
  frm1.sbtt1.value = "";
  frm1.sbomail1.value = "";
  frm1.sbtmail1.value = "";
  frm1.sbsemail1.value = "";
  frm1.sbss1.value = "";
  frm1.sbst1.value = "";
  frm1.chkJumin1.value = "";

  // �ʱ�ȭ ����

  var de = frm1.destatus.value;
  
	  if (Number(countf) == 0)
		 {
			frm1.showteam.value = 0;
		 }
	  else
		{
			frm1.showteam.value = 2;
		}
	  
	  
	  var showid = frm1.showteam.value;
	  //alert(showid);
  
 // alert(countf);
 // alert(de);
  });
  
  $("#de2").click(function(){
  $("#sumt2").css("display","none");
  var frm1 = document.fregisterfrm;
  var count = frm1.cot.value;
  frm1.cot.value = Number(count) - 1;
  var countf = frm1.cot.value;
  frm1.destatus.value = 2;

  // �ش翵�� ��ǪƮ �� ��� �ʱ�ȭ ó��	
  frm1.sbname2.value = "";
  frm1.sbju2.value = "";
  frm1.sbtju2.value = "";
  frm1.sbname2.readOnly	= false;
  frm1.sbju2.readOnly	= false;
  frm1.sbtju2.readOnly	= false;

  frm1.sbaddr2.value = "";
  frm1.sbp2.value = "";
  frm1.sbop2.value = "";
  frm1.sbtp2.value = "";
  frm1.sbt2.value = "";
  frm1.sbot2.value = "";
  frm1.sbtt2.value = "";
  frm1.sbomail2.value = "";
  frm1.sbtmail2.value = "";
  frm1.sbsemail2.value = "";
  frm1.sbss2.value = "";
  frm1.sbst2.value = "";
  frm1.chkJumin2.value = "";
  
  var de = frm1.destatus.value;
  
	  if (Number(countf) == 0)
		 {
			frm1.showteam.value = 0;
		 }
	  else
		{
			frm1.showteam.value = 1;
		}
  
  
  var showid = frm1.showteam.value;
  //alert(showid);
//  alert(countf);
//  alert(de);
  });
});

//
