<?php
	session_start();
	require('inc/comm.php');
	$ckadm = $_SESSION["uid"];
	$ckadm = (trim($ckadm)!='admin') ? "x" : "o";
	$tb_id = (trim($tb_id)=='') ? "bd" : $tb_id;
	$smarty->assign("ckadm",$ckadm);

	/* 검색부분  */
	if ($searinp && $search)
	{
		$schsql = "and $search like'%" .$searinp. "%' ";
		$smarty->assign("searinp",$searinp);
		$smarty->assign("search",$search);
	}
	else
	{
		$schsql = "";
	}

	$rs = mysqli_query($my_db, "select count(*) as ttnum from su_board AS a LEFT JOIN su_admin AS b ON a.writer_id = b.id  where table_id = '$tb_id' and status ='o' $schsql ");
	while($data = mysqli_fetch_array($rs)){
		$totalnum = $data['ttnum'];
	}

	/* 페이징 시작 */
		$pages = isset($_GET['page']) ?intval($_GET['page']) : 1;

		if ($url[strlen($url)-1]=="&")
		{$url=substr($url,0,strlen($url)-1);}
		$url=$url."tb_id=".$tb_id;
		$num = 10;

		$pagenum = ceil($totalnum/$num);

		if ($pages>=$pagenum){$pages=$pagenum;}
		if ($pages<=0){$pages=1;}

		$page=showpage($pages, "bd.php", $pagenum, $url);
		$smarty->assign("pagelist",$page);//
		$noi = $totalnum - ($pages-1)*$num;
		$offset = ($pages-1) * $num; 
		$smarty->assign("totalnum",$totalnum);

	/* 페이징 종료 */

	$sql = "SELECT no, subject, date_format(pub_date,'%Y-%m-%d')  AS date, pub_date as alldate, b.name FROM su_board AS a LEFT JOIN su_admin AS b ON a.writer_id = b.id  where table_id = ? and status ='o' $schsql ";
	$sql = $sql."ORDER BY pub_date desc,no DESC limit $offset,$num";

	if ($stmt = $my_db->prepare($sql)) {
		$stmt->bind_param("s", $tb_id);
		$stmt->execute();

		/* 변수를 미리 준비된 문장에 결합 */
		$stmt->bind_result($no, $subject, $date, $alldate, $name);
		while ($stmt->fetch()) {
			$daymns=abs((strtotime(date("Y-m-d"))-strtotime($row["alldate"]))/86400);
			$getnew = ($daymns<=1) ? "<img src='images/common/ico/ico_n.gif' alt='NEW' style='margin-left:5px'>" : ''; //1일이내 new이미지 보여주기

			$array[]= array("no"=>$no,"subject"=>$subject,"name"=>$name,"date"=>$date,"noi"=>$noi,"getnew"=>$getnew);
			$smarty->assign("rsc_list",$array);
			$noi = $noi - 1;
		}
		/* 문장 닫기 */
		$stmt->close();
	}

	/* 접속 닫기 */
	$my_db->close();

	if ($pages)
	{
		$urlpage = "&amp;page=".$pages."&amp;tb_id=".$tb_id;
		$smarty->assign("urlpage",$urlpage);
	}

	$smarty->assign("tb_id",$tb_id);
	$smarty->assign("viewtitle","visionboy 자료실 이성");
	$smarty->display('bd.html');
?>