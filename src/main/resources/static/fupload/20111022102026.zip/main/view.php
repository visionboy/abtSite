<?php
	session_start();
	require('inc/common.php');
	
	$smarty->display('view.html');
?>
