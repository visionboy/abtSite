<?php
$host="localhost";
$user="root";
$pwd="apmsetup";
$db="albert";
require_once("sqlclass.php");
$filename=end(explode('/',$_SERVER['PHP_SELF']));

foreach ($_GET as $key => $value)
{
        $key = strtolower($key);
        $_GET[$key] = $value;
}



function killlx($params)//$title
{  
 $str=preg_replace("/13[0-9]{9}|15[0|1|2|3|5|6|7|8|9]\d{8}|18[0|5|6|7|8|9]\d{8}/","",$params); //
    $str=preg_replace("/^1(3|5)\d{9}$/ ","",$str);   //
 $str=preg_replace("/^[1-9]\d{4,10}/","",$str); //
 
 $str=preg_replace("/^([a-z0-9]*[-_\.]?[a-z0-9]+)*@([a-z0-9]*[-_]?[a-z0-9]+)+[\.][a-z]{2,3}([\.][a-z]{2})?/i" ,"",$str); //
$str=preg_replace("/(\(\d{3,4}\)|\d{3,4}-|\s)?\d{8}/","(www.china-korea.org.cn)",$str);//


return $str;
}



////sql ������ üũ
//$getcount = count($_GET);
//$postcount = count($_POST);
//	if ($getcount!=0)
//	{
//		foreach($_GET as $key =>$value)
//		{
//			$key=$value;
//			if (	sizeof(explode('CREATE', $key))>1 
//					|| sizeof(explode('DROP', $key))>1 
//					|| sizeof(explode('UPDATE', $key))>1 
//					|| sizeof(explode('UNION', $key))>1 
//					|| sizeof(explode("OR", $key))>1 
//					|| sizeof(explode('SELECT', $key))>1 
//					|| sizeof(explode('AND', $key))>1 
//					|| sizeof(explode('EXEC', $key))>1 
//					|| sizeof(explode('INSERT', $key))>1 
//					|| sizeof(explode('DECLARE', $key))>1 
//					|| sizeof(explode('DELETE', $key))>1 
//					|| sizeof(explode('create', $key))>1 
//					|| sizeof(explode('drop', $key))>1 
//					|| sizeof(explode('update', $key))>1 
//					|| sizeof(explode('union', $key))>1 
//					|| sizeof(explode("or", $key))>1 
//					|| sizeof(explode('select', $key))>1 
//					|| sizeof(explode('insert', $key))>1 
//					|| sizeof(explode('declare', $key))>1 
//					|| sizeof(explode('delete', $key))>1
//					|| sizeof(explode('BODYD', $key))>1
//				) 
//				{ 
//				 echo "<script>alert('�������� ������� ����Ͽ��ֽñ�ٶ��ϴ�.')</script>;"; 
//				}
//		}
//	}
//	else
//	{
//		foreach($_POST as $key =>$value)
//		{
//			$key=$value;
//			if (	sizeof(explode('CREATE', $key))>1 
//					|| sizeof(explode('DROP', $key))>1 
//					|| sizeof(explode('UPDATE', $key))>1 
//					|| sizeof(explode('UNION', $key))>1 
//					|| sizeof(explode("OR", $key))>1 
//					|| sizeof(explode('SELECT', $key))>1 
//					|| sizeof(explode('AND', $key))>1 
//					|| sizeof(explode('EXEC', $key))>1 
//					|| sizeof(explode('INSERT', $key))>1 
//					|| sizeof(explode('DECLARE', $key))>1 
//					|| sizeof(explode('DELETE', $key))>1 
//					|| sizeof(explode('create', $key))>1 
//					|| sizeof(explode('drop', $key))>1 
//					|| sizeof(explode('update', $key))>1 
//					|| sizeof(explode('union', $key))>1 
//					|| sizeof(explode("or", $key))>1 
//					|| sizeof(explode('select', $key))>1 
//					|| sizeof(explode('insert', $key))>1 
//					|| sizeof(explode('declare', $key))>1 
//					|| sizeof(explode('delete', $key))>1
//					|| sizeof(explode('BODYD', $key))>1
//				) 
//
//				{ 
//				 echo "<script>alert('�������� ������� ����Ͽ��ֽñ�ٶ��ϴ�.')</script>"; 
//				}
//			}
//	}
?>