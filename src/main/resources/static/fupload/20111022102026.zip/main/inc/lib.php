<?php
function get_skin_dir($skin, $len='')
	{

		$g4 = "smarty/templates/";
		$result_array = array();

		$dirname = "smarty/templates/$skin/";
		$handle = opendir($dirname);
		while ($file = readdir($handle)) 
		{
			if($file == "."||$file == "..") continue;

			if (is_dir($dirname.$file)) $result_array[] = $file;
		}
		closedir($handle);
		sort($result_array);

		return $result_array;
	}

// 메세지 출력 및 포워딩 
function goto_url($url)
{
    echo "<script type='text/javascript'> location.href='$url'; </script>";
    exit;
}
function alert($msg='', $url='')
{
    if (!$msg) $msg = '올바른 방법으로 이용해 주십시오.';
	echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
	echo "<script type='text/javascript'>alert('$msg');";
    if (!$url)
        echo "history.go(-1);";
    echo "</script>";
    if ($url)
        // 4.06.00 : 불여우의 경우 아래의 코드를 제대로 인식하지 못함
        goto_url($url);
    exit;
}

/**
 * 
 * Date : 
 * 
 * @param $page
 * @param $num
 * @param $pagenum 
 * @param $totalnum
 * showpage;
 */
//function showpage($page, $num, $pagenum, $totalnum) {
function showpage($page, $web, $pagenum, $url) {
	
	$strpage="";
	$maxto = 10; //
	$nextpage = $page + 1;
	if ($nextpage > $pagenum) $nextpage = $pagenum;
	if ($pagenum >=($page + $maxto))
	{
		if ($page<5)
		{
			$for_end=10;
		}else
		{
			if  (($page + 5)>$pagenum )
			{
				$for_end=$pagenum;
			}else 
			{
				$for_end=$page+5;
			}
		}
	}
	else
	{ 	
	if  (($page + 5)>$pagenum )
		{
			$for_end=$pagenum;
		}else 
		{
			$for_end=$page+5;
		}

	}
	if (($page - 4)>1)
	{
		$for_begin=$page - 4;
	}else
	{
		$for_begin=1;
	}


	if ($page>1)
	{
		if ($url!="")
		{
			$strpage=$strpage."<a href=\"".$web."?".$url."\" ><img src='images/common/btn/btn_first.gif' alt='처음'></a> <a href=\"".$web."?page=".($page-1)."&".$url."\" ><img src='images/common/btn/btn_prev02.gif' alt='이전'></a> ";
		}else
		{
			$strpage=$strpage."<a href=\"".$web."\" ><img src='images/common/btn/btn_first.gif' alt='처음'></a> <a href=\"".$web."?page=".($page-1)."\" ><img src='images/common/btn/btn_prev02.gif' alt='이전'></a> ";
		}
	}  else
	{
		$strpage=$strpage."<a href='#'><img src='images/common/btn/btn_first.gif' alt='처음'></a> <a href='#'><img src='images/common/btn/btn_prev02.gif' alt='이전'></a> ";
	}
	$strpage=$strpage."";
	for ($i = $for_begin; $i <= $for_end; $i++) {
//		if ($i != $for_begin)
//		{
//			$strpage=$strpage." | ";
//		}
		if ($i != $page){
			if ($url!="")
			{
				$strpage=$strpage. "<a href=\"".$web."?".$url."&page=$i\"> [$i] </a> ";
			}else

			{
				$strpage=$strpage. "<a href=\"".$web."?page=$i\"> [$i] </a> ";
			}

		} else {
			$strpage=$strpage. "<strong > [$i] </strong> ";
		}
	}
	$strpage=$strpage."";
	if ($page>=$pagenum)
	{
		$strpage=$strpage." <a href='#'><img src='images/common/btn/btn_next02.gif' alt='다음'></a> <a href='#'><img src='images/common/btn/btn_last.gif' alt='마지막'></a>";
	}else
	{
		if ($url!="")
		{
			$strpage=$strpage." <a href=\"".$web."?".$url."&page=$nextpage\" ><img src='images/common/btn/btn_next02.gif' alt='다음'></a> <a href=\"".$web."?page=$pagenum&".$url."\" class=\"last\"><img src='images/common/btn/btn_last.gif' alt='마지막'></a>";
		}else
		{
			$strpage=$strpage." <a href=\"".$web."?page=$nextpage\" class=\"next\"><img src='images/common/btn/btn_next02.gif' alt='다음'></a> <a href=\"".$web."?page=$pagenum\" class=\"last\"><img src='images/common/btn/btn_last.gif' alt='마지막'></a>";
		}
	}
	return $strpage;

}


//파일 업로드
function uploadfile($type,$name,$ext,$size,$error,$tmp_name,$targetname,$upload_dir)
{
	if ($_FILES["ufile"]["error"] > 0)

	{
		echo "Error: " . $_FILES["ufile"]["error"] . "<br />";
	}

	else
	{
		$MAX_SIZE = 50000000000;
		if($size>$MAX_SIZE)
			alert("업로드 하려는 파일크기가 최대치를 초과하여 업로드시 실패하였습니다.");

		if (sizeof(explode('.php', $name))>1 ||
			sizeof(explode('.phtm', $name))>1 ||
			sizeof(explode('.htm', $name))>1 ||
			sizeof(explode('.cgi', $name))>1 ||
			sizeof(explode('.pl', $name))>1 ||
			sizeof(explode('.exe', $name))>1 ||
			sizeof(explode('.jsp', $name))>1 ||
			sizeof(explode('.asp', $name))>1 ||
			sizeof(explode('.inc', $name))>1 
		)				
			alert("조건에 부합되는 파일을 업로드 하시길바랍니다.");

		copy($tmp_name, $upload_dir.$targetname);

	}
}

// 메인 공지사항 길이 짜르기
function substr_kr($s, $l)
	{
		if( strlen($s) <= ($l+3)) 
        return $s; 

		if( ord($s[$l-1]) > 127 ) {      //ord ->  ascii 체크. 127 초과면 한글
		  $nc = 2; 
		  while( ord($s[$l-$nc]) > 127 ) $nc++;
		  $l -= !($nc & 1); 
		}
		return substr($s, 0, $l) . ".."; 
	}
function strcut_utf8($str, $len, $checkmb=false, $tail='...') {
    preg_match_all('/[\xEA-\xED][\x80-\xFF]{2}|./', $str, $match);
 
    $m    = $match[0];
    $slen = strlen($str);  // length of source string
    $tlen = strlen($tail); // length of tail string
    $mlen = count($m); // length of matched characters
 
    if ($slen <= $len) return $str;
    if (!$checkmb && $mlen <= $len) return $str;
 
    $ret   = array();
    $count = 0;
 
    for ($i=0; $i < $len; $i++) {
        $count += ($checkmb && strlen($m[$i]) > 1)?2:1;
 
        if ($count + $tlen > $len) break;
        $ret[] = $m[$i];
    }
 
    return join('', $ret).$tail;
}

?>
