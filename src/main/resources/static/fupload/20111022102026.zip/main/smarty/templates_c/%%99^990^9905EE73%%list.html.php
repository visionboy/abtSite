<?php /* Smarty version 2.6.26, created on 2011-10-22 10:09:03
         compiled from list.html */ ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
 <head>
  <title> New Document </title>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
 </head>

 <body>
  리스트페이지
 </body>
</html>