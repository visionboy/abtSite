<?php
	session_start();
	require('inc/common.php');
	$ckadm = $_SESSION["uid"];
	$ckadm = (trim($ckadm)!='admin') ? "x" : "o";

	$tb_id = (trim($tb_id)=='') ? "bd" : $tb_id;

	$smarty->assign("ckadm",$ckadm);
	$sql = "SELECT no, subject, date_format(pub_date,'%Y-%m-%d')  AS date, pub_date as alldate, b.name FROM inun_board AS a LEFT JOIN inun_admin AS b ON a.writer_id = b.id  where table_id = '$tb_id' and status ='o' ";
	
	if ($searinp)
	{
		$sql = $sql."and $search like'%" .$searinp. "%'";
		$smarty->assign("searinp",$searinp);
		$smarty->assign("search",$search);
	}

	include 'inc/treuckr.php';

	//페이징 시작
	$pages = isset($_GET['page']) ?intval($_GET['page']) : 1;

	if ($url[strlen($url)-1]=="&")
	{$url=substr($url,0,strlen($url)-1);}
	$url=$url."tb_id=".$tb_id;
	$num = 20;
	$totalnum=$DB->num_rows($DB->query($sql));
	$pagenum = ceil($totalnum/$num); //

	if ($pages>=$pagenum){$pages=$pagenum;}
	if ($pages<=0){$pages=1;}

	$page=showpage($pages, "board.php", $pagenum, $url);
	$smarty->assign("pagelist",$page);//


	$noi = $totalnum - ($pages-1)*$num;
	$offset = ($pages-1) * $num;
	$smarty->assign("totalnum",$totalnum);
	$result=$DB->query($sql."ORDER BY no DESC limit $offset,$num");
		while ($row=$DB->fetch_row($result))
		 {
			$daymns=abs((strtotime(date("Y-m-d"))-strtotime($row["alldate"]))/86400);
			$getnew = ($daymns<=1) ? "<img src='images/common/ico/ico_n.gif' alt='NEW' style='margin-left:5px'>" : ''; //1일이내 new이미지 보여주기

			$array[]= array("no"=>$row['no'],"subject"=>$row['subject'],"name"=>$row['name'],"date"=>$row['date'],"noi"=>$noi,"getnew"=>$getnew);
			$smarty->assign("rsc_list",$array);
			$noi = $noi - 1;
		 }
	if ($pages)
	{
		$urlpage = "&amp;page=".$pages."&amp;tb_id=".$tb_id;
		$smarty->assign("urlpage",$urlpage);
	}
	$smarty->assign("tb_id",$tb_id);

	$smarty->assign("viewtitle","자료실 리스트페이지");
	$smarty->display('board.html');
?>
