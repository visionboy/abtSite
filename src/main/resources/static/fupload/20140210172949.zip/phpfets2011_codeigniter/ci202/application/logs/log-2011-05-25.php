<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-25 21:17:48 --> Config Class Initialized
DEBUG - 2011-05-25 21:17:48 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:17:48 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:17:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:17:48 --> Config Class Initialized
DEBUG - 2011-05-25 21:17:48 --> Config Class Initialized
DEBUG - 2011-05-25 21:17:48 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:17:48 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:17:48 --> Config Class Initialized
DEBUG - 2011-05-25 21:17:48 --> URI Class Initialized
DEBUG - 2011-05-25 21:17:48 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:17:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:17:48 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:17:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:17:48 --> Router Class Initialized
DEBUG - 2011-05-25 21:17:48 --> URI Class Initialized
DEBUG - 2011-05-25 21:17:48 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:17:48 --> Router Class Initialized
DEBUG - 2011-05-25 21:17:48 --> URI Class Initialized
DEBUG - 2011-05-25 21:17:48 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:17:48 --> Router Class Initialized
ERROR - 2011-05-25 21:17:48 --> 404 Page Not Found --> wpad.dat
ERROR - 2011-05-25 21:17:48 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:17:48 --> UTF-8 Support Enabled
ERROR - 2011-05-25 21:17:48 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:17:48 --> URI Class Initialized
DEBUG - 2011-05-25 21:17:48 --> Router Class Initialized
ERROR - 2011-05-25 21:17:48 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:17:48 --> Config Class Initialized
DEBUG - 2011-05-25 21:17:48 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:17:48 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:17:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:17:48 --> URI Class Initialized
DEBUG - 2011-05-25 21:17:48 --> Router Class Initialized
ERROR - 2011-05-25 21:17:48 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:17:49 --> Config Class Initialized
DEBUG - 2011-05-25 21:17:49 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:17:49 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:17:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:17:49 --> URI Class Initialized
DEBUG - 2011-05-25 21:17:49 --> Router Class Initialized
ERROR - 2011-05-25 21:17:49 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:18:10 --> Config Class Initialized
DEBUG - 2011-05-25 21:18:10 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:18:10 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:18:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:18:10 --> URI Class Initialized
DEBUG - 2011-05-25 21:18:10 --> Router Class Initialized
ERROR - 2011-05-25 21:18:10 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:18:14 --> Config Class Initialized
DEBUG - 2011-05-25 21:18:14 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:18:14 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:18:14 --> URI Class Initialized
DEBUG - 2011-05-25 21:18:14 --> Router Class Initialized
ERROR - 2011-05-25 21:18:14 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:18:37 --> Config Class Initialized
DEBUG - 2011-05-25 21:18:37 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:18:37 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:18:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:18:37 --> URI Class Initialized
DEBUG - 2011-05-25 21:18:37 --> Router Class Initialized
ERROR - 2011-05-25 21:18:37 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:19:12 --> Config Class Initialized
DEBUG - 2011-05-25 21:19:12 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:19:12 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:19:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:19:12 --> URI Class Initialized
DEBUG - 2011-05-25 21:19:12 --> Router Class Initialized
ERROR - 2011-05-25 21:19:12 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:19:37 --> Config Class Initialized
DEBUG - 2011-05-25 21:19:37 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:19:37 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:19:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:19:37 --> URI Class Initialized
DEBUG - 2011-05-25 21:19:37 --> Router Class Initialized
ERROR - 2011-05-25 21:19:37 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:20:37 --> Config Class Initialized
DEBUG - 2011-05-25 21:20:37 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:20:37 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:20:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:20:37 --> URI Class Initialized
DEBUG - 2011-05-25 21:20:37 --> Router Class Initialized
ERROR - 2011-05-25 21:20:37 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:20:42 --> Config Class Initialized
DEBUG - 2011-05-25 21:20:42 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:20:42 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:20:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:20:42 --> URI Class Initialized
DEBUG - 2011-05-25 21:20:42 --> Router Class Initialized
ERROR - 2011-05-25 21:20:42 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:20:43 --> Config Class Initialized
DEBUG - 2011-05-25 21:20:43 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:20:43 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:20:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:20:43 --> URI Class Initialized
DEBUG - 2011-05-25 21:20:43 --> Router Class Initialized
ERROR - 2011-05-25 21:20:43 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:20:55 --> Config Class Initialized
DEBUG - 2011-05-25 21:20:55 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:20:55 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:20:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:20:55 --> URI Class Initialized
DEBUG - 2011-05-25 21:20:55 --> Router Class Initialized
ERROR - 2011-05-25 21:20:55 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:21:37 --> Config Class Initialized
DEBUG - 2011-05-25 21:21:37 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:21:37 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:21:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:21:37 --> URI Class Initialized
DEBUG - 2011-05-25 21:21:37 --> Router Class Initialized
ERROR - 2011-05-25 21:21:37 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:22:13 --> Config Class Initialized
DEBUG - 2011-05-25 21:22:13 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:22:13 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:22:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:22:13 --> URI Class Initialized
DEBUG - 2011-05-25 21:22:13 --> Router Class Initialized
ERROR - 2011-05-25 21:22:13 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:26:24 --> Config Class Initialized
DEBUG - 2011-05-25 21:26:24 --> Config Class Initialized
DEBUG - 2011-05-25 21:26:24 --> Config Class Initialized
DEBUG - 2011-05-25 21:26:24 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:26:24 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:26:24 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:26:24 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:26:24 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:26:24 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:26:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:26:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:26:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:26:24 --> URI Class Initialized
DEBUG - 2011-05-25 21:26:24 --> Config Class Initialized
DEBUG - 2011-05-25 21:26:24 --> URI Class Initialized
DEBUG - 2011-05-25 21:26:24 --> Router Class Initialized
DEBUG - 2011-05-25 21:26:24 --> Router Class Initialized
DEBUG - 2011-05-25 21:26:24 --> URI Class Initialized
DEBUG - 2011-05-25 21:26:24 --> Router Class Initialized
ERROR - 2011-05-25 21:26:24 --> 404 Page Not Found --> wpad.dat
ERROR - 2011-05-25 21:26:24 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:26:24 --> Hooks Class Initialized
ERROR - 2011-05-25 21:26:24 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:26:24 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:26:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:26:24 --> URI Class Initialized
DEBUG - 2011-05-25 21:26:24 --> Router Class Initialized
ERROR - 2011-05-25 21:26:24 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:26:28 --> Config Class Initialized
DEBUG - 2011-05-25 21:26:28 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:26:28 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:26:28 --> URI Class Initialized
DEBUG - 2011-05-25 21:26:28 --> Router Class Initialized
ERROR - 2011-05-25 21:26:28 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:27:16 --> Config Class Initialized
DEBUG - 2011-05-25 21:27:16 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:27:16 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:27:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:27:16 --> URI Class Initialized
DEBUG - 2011-05-25 21:27:16 --> Router Class Initialized
ERROR - 2011-05-25 21:27:16 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:28:16 --> Config Class Initialized
DEBUG - 2011-05-25 21:28:16 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:28:16 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:28:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:28:16 --> URI Class Initialized
DEBUG - 2011-05-25 21:28:16 --> Router Class Initialized
ERROR - 2011-05-25 21:28:16 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:33:00 --> Config Class Initialized
DEBUG - 2011-05-25 21:33:00 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:33:00 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:33:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:33:00 --> URI Class Initialized
DEBUG - 2011-05-25 21:33:00 --> Router Class Initialized
ERROR - 2011-05-25 21:33:00 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:33:02 --> Config Class Initialized
DEBUG - 2011-05-25 21:33:02 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:33:02 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:33:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:33:02 --> URI Class Initialized
DEBUG - 2011-05-25 21:33:02 --> Router Class Initialized
ERROR - 2011-05-25 21:33:02 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:33:10 --> Config Class Initialized
DEBUG - 2011-05-25 21:33:10 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:33:10 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:33:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:33:10 --> URI Class Initialized
DEBUG - 2011-05-25 21:33:10 --> Router Class Initialized
DEBUG - 2011-05-25 21:33:10 --> Output Class Initialized
DEBUG - 2011-05-25 21:33:10 --> Security Class Initialized
DEBUG - 2011-05-25 21:33:10 --> Input Class Initialized
DEBUG - 2011-05-25 21:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 21:33:10 --> Language Class Initialized
DEBUG - 2011-05-25 21:33:11 --> Loader Class Initialized
DEBUG - 2011-05-25 21:33:11 --> Controller Class Initialized
DEBUG - 2011-05-25 21:33:11 --> Database Driver Class Initialized
DEBUG - 2011-05-25 21:33:11 --> Final output sent to browser
DEBUG - 2011-05-25 21:33:11 --> Total execution time: 0.1870
DEBUG - 2011-05-25 21:33:11 --> Config Class Initialized
DEBUG - 2011-05-25 21:33:11 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:33:11 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:33:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:33:11 --> URI Class Initialized
DEBUG - 2011-05-25 21:33:11 --> Router Class Initialized
ERROR - 2011-05-25 21:33:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 21:41:53 --> Config Class Initialized
DEBUG - 2011-05-25 21:41:53 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:41:53 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:41:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:41:53 --> URI Class Initialized
DEBUG - 2011-05-25 21:41:53 --> Router Class Initialized
ERROR - 2011-05-25 21:41:53 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 21:44:49 --> Config Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:44:49 --> URI Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Router Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Output Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Security Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Input Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 21:44:49 --> Language Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Loader Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Controller Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Database Driver Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Final output sent to browser
DEBUG - 2011-05-25 21:44:49 --> Total execution time: 0.1439
DEBUG - 2011-05-25 21:44:49 --> Config Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:44:49 --> URI Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Router Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Output Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Security Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Input Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 21:44:49 --> Language Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Loader Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Controller Class Initialized
ERROR - 2011-05-25 21:44:49 --> 404 Page Not Found --> c_only/include
DEBUG - 2011-05-25 21:44:49 --> Config Class Initialized
DEBUG - 2011-05-25 21:44:49 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:44:50 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:44:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:44:50 --> URI Class Initialized
DEBUG - 2011-05-25 21:44:50 --> Router Class Initialized
ERROR - 2011-05-25 21:44:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 21:45:03 --> Config Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:45:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:45:03 --> URI Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Router Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Output Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Security Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Input Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 21:45:03 --> Language Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Loader Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Controller Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Database Driver Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Final output sent to browser
DEBUG - 2011-05-25 21:45:03 --> Total execution time: 0.1453
DEBUG - 2011-05-25 21:45:03 --> Config Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:45:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:45:03 --> URI Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Router Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Config Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Output Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Security Class Initialized
DEBUG - 2011-05-25 21:45:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:45:03 --> URI Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Input Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 21:45:03 --> Router Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Language Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Loader Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Output Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Controller Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Security Class Initialized
ERROR - 2011-05-25 21:45:03 --> 404 Page Not Found --> c_only/include
DEBUG - 2011-05-25 21:45:03 --> Input Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 21:45:03 --> Language Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Loader Class Initialized
DEBUG - 2011-05-25 21:45:03 --> Controller Class Initialized
ERROR - 2011-05-25 21:45:03 --> 404 Page Not Found --> c_only/include
DEBUG - 2011-05-25 21:45:08 --> Config Class Initialized
DEBUG - 2011-05-25 21:45:08 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:45:08 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:45:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:45:08 --> URI Class Initialized
DEBUG - 2011-05-25 21:45:08 --> Router Class Initialized
DEBUG - 2011-05-25 21:45:08 --> Output Class Initialized
DEBUG - 2011-05-25 21:45:08 --> Security Class Initialized
DEBUG - 2011-05-25 21:45:08 --> Input Class Initialized
DEBUG - 2011-05-25 21:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 21:45:08 --> Language Class Initialized
DEBUG - 2011-05-25 21:45:08 --> Loader Class Initialized
DEBUG - 2011-05-25 21:45:08 --> Controller Class Initialized
DEBUG - 2011-05-25 21:45:08 --> Database Driver Class Initialized
DEBUG - 2011-05-25 21:45:08 --> Final output sent to browser
DEBUG - 2011-05-25 21:45:08 --> Total execution time: 0.1455
DEBUG - 2011-05-25 21:46:44 --> Config Class Initialized
DEBUG - 2011-05-25 21:46:44 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:46:44 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:46:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:46:44 --> URI Class Initialized
DEBUG - 2011-05-25 21:46:44 --> Router Class Initialized
DEBUG - 2011-05-25 21:46:44 --> Output Class Initialized
DEBUG - 2011-05-25 21:46:44 --> Security Class Initialized
DEBUG - 2011-05-25 21:46:44 --> Input Class Initialized
DEBUG - 2011-05-25 21:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 21:46:44 --> Language Class Initialized
DEBUG - 2011-05-25 21:46:44 --> Loader Class Initialized
DEBUG - 2011-05-25 21:46:44 --> Controller Class Initialized
DEBUG - 2011-05-25 21:46:44 --> Database Driver Class Initialized
DEBUG - 2011-05-25 21:46:44 --> Model Class Initialized
DEBUG - 2011-05-25 21:46:44 --> Model Class Initialized
DEBUG - 2011-05-25 21:46:44 --> Final output sent to browser
DEBUG - 2011-05-25 21:46:44 --> Total execution time: 0.1585
DEBUG - 2011-05-25 21:47:56 --> Config Class Initialized
DEBUG - 2011-05-25 21:47:56 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:47:56 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:47:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:47:56 --> URI Class Initialized
DEBUG - 2011-05-25 21:47:56 --> Router Class Initialized
DEBUG - 2011-05-25 21:47:56 --> Output Class Initialized
DEBUG - 2011-05-25 21:47:56 --> Security Class Initialized
DEBUG - 2011-05-25 21:47:56 --> Input Class Initialized
DEBUG - 2011-05-25 21:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 21:47:56 --> Language Class Initialized
DEBUG - 2011-05-25 21:47:56 --> Loader Class Initialized
DEBUG - 2011-05-25 21:47:56 --> Controller Class Initialized
DEBUG - 2011-05-25 21:47:56 --> Database Driver Class Initialized
DEBUG - 2011-05-25 21:47:56 --> Model Class Initialized
DEBUG - 2011-05-25 21:47:56 --> Model Class Initialized
DEBUG - 2011-05-25 21:47:56 --> File loaded: application/views/list_v.php
DEBUG - 2011-05-25 21:47:56 --> Final output sent to browser
DEBUG - 2011-05-25 21:47:56 --> Total execution time: 0.1579
DEBUG - 2011-05-25 21:52:57 --> Config Class Initialized
DEBUG - 2011-05-25 21:52:57 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:52:57 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:52:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:52:57 --> URI Class Initialized
DEBUG - 2011-05-25 21:52:58 --> Router Class Initialized
ERROR - 2011-05-25 21:52:58 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 22:08:12 --> Config Class Initialized
DEBUG - 2011-05-25 22:08:12 --> Hooks Class Initialized
DEBUG - 2011-05-25 22:08:12 --> Utf8 Class Initialized
DEBUG - 2011-05-25 22:08:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 22:08:12 --> URI Class Initialized
DEBUG - 2011-05-25 22:08:12 --> Router Class Initialized
DEBUG - 2011-05-25 22:08:12 --> Output Class Initialized
DEBUG - 2011-05-25 22:08:12 --> Security Class Initialized
DEBUG - 2011-05-25 22:08:12 --> Input Class Initialized
DEBUG - 2011-05-25 22:08:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 22:08:12 --> Language Class Initialized
DEBUG - 2011-05-25 22:08:12 --> Loader Class Initialized
DEBUG - 2011-05-25 22:08:12 --> Controller Class Initialized
DEBUG - 2011-05-25 22:08:12 --> Database Driver Class Initialized
DEBUG - 2011-05-25 22:08:12 --> Model Class Initialized
DEBUG - 2011-05-25 22:08:12 --> Model Class Initialized
DEBUG - 2011-05-25 22:08:12 --> File loaded: application/views/list_v.php
DEBUG - 2011-05-25 22:08:12 --> Final output sent to browser
DEBUG - 2011-05-25 22:08:12 --> Total execution time: 0.1607
DEBUG - 2011-05-25 22:08:13 --> Config Class Initialized
DEBUG - 2011-05-25 22:08:13 --> Hooks Class Initialized
DEBUG - 2011-05-25 22:08:13 --> Utf8 Class Initialized
DEBUG - 2011-05-25 22:08:13 --> Config Class Initialized
DEBUG - 2011-05-25 22:08:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 22:08:13 --> Hooks Class Initialized
DEBUG - 2011-05-25 22:08:13 --> URI Class Initialized
DEBUG - 2011-05-25 22:08:13 --> Utf8 Class Initialized
DEBUG - 2011-05-25 22:08:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 22:08:13 --> Router Class Initialized
DEBUG - 2011-05-25 22:08:13 --> URI Class Initialized
DEBUG - 2011-05-25 22:08:13 --> Router Class Initialized
DEBUG - 2011-05-25 22:08:13 --> Output Class Initialized
DEBUG - 2011-05-25 22:08:13 --> Output Class Initialized
DEBUG - 2011-05-25 22:08:13 --> Security Class Initialized
DEBUG - 2011-05-25 22:08:13 --> Security Class Initialized
DEBUG - 2011-05-25 22:08:13 --> Input Class Initialized
DEBUG - 2011-05-25 22:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 22:08:13 --> Input Class Initialized
DEBUG - 2011-05-25 22:08:13 --> Language Class Initialized
DEBUG - 2011-05-25 22:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 22:08:13 --> Language Class Initialized
DEBUG - 2011-05-25 22:08:13 --> Loader Class Initialized
DEBUG - 2011-05-25 22:08:13 --> Controller Class Initialized
DEBUG - 2011-05-25 22:08:13 --> Loader Class Initialized
DEBUG - 2011-05-25 22:08:13 --> Controller Class Initialized
ERROR - 2011-05-25 22:08:13 --> 404 Page Not Found --> mvc/include
ERROR - 2011-05-25 22:08:13 --> 404 Page Not Found --> mvc/include
DEBUG - 2011-05-25 22:09:32 --> Config Class Initialized
DEBUG - 2011-05-25 22:09:32 --> Hooks Class Initialized
DEBUG - 2011-05-25 22:09:32 --> Utf8 Class Initialized
DEBUG - 2011-05-25 22:09:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 22:09:32 --> URI Class Initialized
DEBUG - 2011-05-25 22:09:32 --> Router Class Initialized
DEBUG - 2011-05-25 22:09:32 --> Output Class Initialized
DEBUG - 2011-05-25 22:09:32 --> Security Class Initialized
DEBUG - 2011-05-25 22:09:32 --> Input Class Initialized
DEBUG - 2011-05-25 22:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 22:09:32 --> Language Class Initialized
DEBUG - 2011-05-25 22:09:32 --> Loader Class Initialized
DEBUG - 2011-05-25 22:09:32 --> Controller Class Initialized
DEBUG - 2011-05-25 22:09:32 --> Final output sent to browser
DEBUG - 2011-05-25 22:09:32 --> Total execution time: 0.1127
DEBUG - 2011-05-25 22:20:32 --> Config Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Hooks Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Config Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Hooks Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Utf8 Class Initialized
DEBUG - 2011-05-25 22:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 22:20:32 --> Utf8 Class Initialized
DEBUG - 2011-05-25 22:20:32 --> URI Class Initialized
DEBUG - 2011-05-25 22:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 22:20:32 --> Config Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Router Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Hooks Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Utf8 Class Initialized
ERROR - 2011-05-25 22:20:32 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 22:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 22:20:32 --> URI Class Initialized
DEBUG - 2011-05-25 22:20:32 --> URI Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Router Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Router Class Initialized
ERROR - 2011-05-25 22:20:32 --> 404 Page Not Found --> wpad.dat
ERROR - 2011-05-25 22:20:32 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 22:20:32 --> Config Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Hooks Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Utf8 Class Initialized
DEBUG - 2011-05-25 22:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 22:20:32 --> URI Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Router Class Initialized
ERROR - 2011-05-25 22:20:32 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 22:20:32 --> Config Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Hooks Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Config Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Utf8 Class Initialized
DEBUG - 2011-05-25 22:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 22:20:32 --> Hooks Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Utf8 Class Initialized
DEBUG - 2011-05-25 22:20:32 --> URI Class Initialized
DEBUG - 2011-05-25 22:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 22:20:32 --> Router Class Initialized
DEBUG - 2011-05-25 22:20:32 --> URI Class Initialized
ERROR - 2011-05-25 22:20:32 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 22:20:32 --> Router Class Initialized
ERROR - 2011-05-25 22:20:32 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 22:20:32 --> Config Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Hooks Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Utf8 Class Initialized
DEBUG - 2011-05-25 22:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 22:20:32 --> URI Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Router Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Config Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Hooks Class Initialized
ERROR - 2011-05-25 22:20:32 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 22:20:32 --> Utf8 Class Initialized
DEBUG - 2011-05-25 22:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 22:20:32 --> URI Class Initialized
DEBUG - 2011-05-25 22:20:32 --> Router Class Initialized
ERROR - 2011-05-25 22:20:32 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 22:21:02 --> Config Class Initialized
DEBUG - 2011-05-25 22:21:02 --> Hooks Class Initialized
DEBUG - 2011-05-25 22:21:02 --> Utf8 Class Initialized
DEBUG - 2011-05-25 22:21:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 22:21:02 --> URI Class Initialized
DEBUG - 2011-05-25 22:21:02 --> Router Class Initialized
ERROR - 2011-05-25 22:21:02 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 22:21:02 --> Config Class Initialized
DEBUG - 2011-05-25 22:21:02 --> Hooks Class Initialized
DEBUG - 2011-05-25 22:21:02 --> Utf8 Class Initialized
DEBUG - 2011-05-25 22:21:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 22:21:02 --> URI Class Initialized
DEBUG - 2011-05-25 22:21:02 --> Router Class Initialized
ERROR - 2011-05-25 22:21:02 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 22:21:03 --> Config Class Initialized
DEBUG - 2011-05-25 22:21:03 --> Hooks Class Initialized
DEBUG - 2011-05-25 22:21:03 --> Utf8 Class Initialized
DEBUG - 2011-05-25 22:21:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 22:21:03 --> URI Class Initialized
DEBUG - 2011-05-25 22:21:03 --> Router Class Initialized
ERROR - 2011-05-25 22:21:03 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-25 22:21:03 --> Config Class Initialized
DEBUG - 2011-05-25 22:21:03 --> Hooks Class Initialized
DEBUG - 2011-05-25 22:21:03 --> Utf8 Class Initialized
DEBUG - 2011-05-25 22:21:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 22:21:03 --> URI Class Initialized
DEBUG - 2011-05-25 22:21:03 --> Router Class Initialized
ERROR - 2011-05-25 22:21:03 --> 404 Page Not Found --> wpad.dat
