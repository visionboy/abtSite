<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko" lang="ko" dir="ltr">

<head>
    <title>mvc 테스트</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="include/css/board.css" />
</head>
<body>
MVC패턴<br>
<table class="board_list">
	<tr>
		<td>번호</td>
		<td>제목</td>
		<td>작성자</td>
		<td>날짜</td>
	</tr>
<?php
	foreach($result as $rt) {
?>
	<tr class="bg0">
		<td><?php echo $rt['board_idx']?></td>
		<td><?php echo $rt['title'] ?></td>
		<td><?php echo $rt['name'] ?></td>
		<td><?php echo substr($rt['date'], 0, 10) ?></td>
	</tr>
<?php } ?>
</table>
<body>
</html>