<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_only extends CI_Controller {

	public function index()
	{
		//database 라이브러리 로딩
		$this->load->database();

		//db에서 데이터 가져오기
		$this->db->order_by('board_idx', 'desc');
		$query = $this->db->get('board');

		$result = $query->result_array();

		//view
		echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link rel="stylesheet" type="text/css" href="include/css/board.css" />
		기존 개발방식<br>
		<table class="board_list"><tr><td>번호</td><td>제목</td><td>작성자</td><td>날짜</td></tr>';
		foreach($result as $rt) {
			echo "<tr><td>".$rt['board_idx']."</td><td>".$rt['title']."</td><td>".$rt['name']."</td><td>".substr($rt['date'], 0, 10)."</td></tr>";

		}
		echo "</table>";

	}
}