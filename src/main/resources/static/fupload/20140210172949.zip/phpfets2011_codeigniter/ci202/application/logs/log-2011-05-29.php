<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-29 16:19:36 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-29 16:19:36 --> Config Class Initialized
DEBUG - 2011-05-29 16:19:36 --> Hooks Class Initialized
DEBUG - 2011-05-29 16:19:36 --> Hooks Class Initialized
DEBUG - 2011-05-29 16:19:36 --> Utf8 Class Initialized
DEBUG - 2011-05-29 16:19:36 --> Utf8 Class Initialized
DEBUG - 2011-05-29 16:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 16:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 16:19:36 --> URI Class Initialized
DEBUG - 2011-05-29 16:19:36 --> URI Class Initialized
DEBUG - 2011-05-29 16:19:36 --> Router Class Initialized
DEBUG - 2011-05-29 16:19:36 --> Router Class Initialized
ERROR - 2011-05-29 16:19:36 --> 404 Page Not Found --> wpad.dat
ERROR - 2011-05-29 16:19:36 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-29 16:19:36 --> Config Class Initialized
DEBUG - 2011-05-29 16:19:36 --> Hooks Class Initialized
DEBUG - 2011-05-29 16:19:36 --> Utf8 Class Initialized
DEBUG - 2011-05-29 16:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 16:19:36 --> URI Class Initialized
DEBUG - 2011-05-29 16:19:36 --> Router Class Initialized
ERROR - 2011-05-29 16:19:36 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-29 16:19:36 --> Config Class Initialized
DEBUG - 2011-05-29 16:19:36 --> Hooks Class Initialized
DEBUG - 2011-05-29 16:19:36 --> Utf8 Class Initialized
DEBUG - 2011-05-29 16:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 16:19:36 --> URI Class Initialized
DEBUG - 2011-05-29 16:19:37 --> Router Class Initialized
DEBUG - 2011-05-29 16:19:37 --> Config Class Initialized
DEBUG - 2011-05-29 16:19:37 --> Hooks Class Initialized
DEBUG - 2011-05-29 16:19:37 --> Utf8 Class Initialized
DEBUG - 2011-05-29 16:19:37 --> UTF-8 Support Enabled
ERROR - 2011-05-29 16:19:37 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-29 16:19:37 --> URI Class Initialized
DEBUG - 2011-05-29 16:19:37 --> Router Class Initialized
ERROR - 2011-05-29 16:19:37 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-29 16:19:56 --> Config Class Initialized
DEBUG - 2011-05-29 16:19:56 --> Hooks Class Initialized
DEBUG - 2011-05-29 16:19:56 --> Utf8 Class Initialized
DEBUG - 2011-05-29 16:19:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 16:19:56 --> URI Class Initialized
DEBUG - 2011-05-29 16:19:56 --> Router Class Initialized
ERROR - 2011-05-29 16:19:56 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-29 16:20:00 --> Config Class Initialized
DEBUG - 2011-05-29 16:20:00 --> Hooks Class Initialized
DEBUG - 2011-05-29 16:20:00 --> Utf8 Class Initialized
DEBUG - 2011-05-29 16:20:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 16:20:00 --> URI Class Initialized
DEBUG - 2011-05-29 16:20:00 --> Router Class Initialized
ERROR - 2011-05-29 16:20:00 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-29 16:20:27 --> Config Class Initialized
DEBUG - 2011-05-29 16:20:27 --> Hooks Class Initialized
DEBUG - 2011-05-29 16:20:27 --> Utf8 Class Initialized
DEBUG - 2011-05-29 16:20:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 16:20:27 --> URI Class Initialized
DEBUG - 2011-05-29 16:20:27 --> Router Class Initialized
ERROR - 2011-05-29 16:20:27 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-29 16:21:27 --> Config Class Initialized
DEBUG - 2011-05-29 16:21:27 --> Hooks Class Initialized
DEBUG - 2011-05-29 16:21:27 --> Utf8 Class Initialized
DEBUG - 2011-05-29 16:21:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-29 16:21:27 --> URI Class Initialized
DEBUG - 2011-05-29 16:21:27 --> Router Class Initialized
ERROR - 2011-05-29 16:21:27 --> 404 Page Not Found --> wpad.dat
