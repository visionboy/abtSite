<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Security extends CI_Controller {

	public function index()
	{

		//model 로딩 및 데이터 가져오기
		$this->load->model('model_m');
		$result = $this->model_m->table_get('board');

		//view
		echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link rel="stylesheet" type="text/css" href="include/css/board.css" />
		기존방식에서 모델만 분리<br>
		<table class="board_list"><tr><td>번호</td><td>제목</td><td>작성자</td><td>날짜</td></tr>';
		foreach($result as $rt) {
			echo "<tr><td>".$rt['board_idx']."</td><td>".$rt['title']."</td><td>".$rt['name']."</td><td>".substr($rt['date'], 0, 10)."</td></tr>";

		}
		echo "</table>";

	}
}