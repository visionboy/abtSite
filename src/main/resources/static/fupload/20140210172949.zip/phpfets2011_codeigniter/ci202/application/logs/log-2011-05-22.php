<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-22 01:03:19 --> Config Class Initialized
DEBUG - 2011-05-22 01:03:19 --> Hooks Class Initialized
DEBUG - 2011-05-22 01:03:19 --> Utf8 Class Initialized
DEBUG - 2011-05-22 01:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 01:03:19 --> URI Class Initialized
DEBUG - 2011-05-22 01:03:19 --> Router Class Initialized
DEBUG - 2011-05-22 01:03:19 --> Output Class Initialized
DEBUG - 2011-05-22 01:03:19 --> Security Class Initialized
DEBUG - 2011-05-22 01:03:19 --> Input Class Initialized
DEBUG - 2011-05-22 01:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 01:03:19 --> Language Class Initialized
DEBUG - 2011-05-22 01:03:19 --> Loader Class Initialized
DEBUG - 2011-05-22 01:03:19 --> Controller Class Initialized
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_ID - assumed 'MENU_ID' C:\work_php\ci202\application\controllers\board.php 9
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_NAME - assumed 'MENU_NAME' C:\work_php\ci202\application\controllers\board.php 10
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_NAME_EN - assumed 'MENU_NAME_EN' C:\work_php\ci202\application\controllers\board.php 11
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_DETAIL_XML - assumed 'MENU_DETAIL_XML' C:\work_php\ci202\application\controllers\board.php 12
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_PLUGIN_NO - assumed 'MENU_PLUGIN_NO' C:\work_php\ci202\application\controllers\board.php 13
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_NO - assumed 'MENU_SKIN_NO' C:\work_php\ci202\application\controllers\board.php 14
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_NAME - assumed 'MENU_BOARD_NAME' C:\work_php\ci202\application\controllers\board.php 15
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_NAME_EN - assumed 'MENU_BOARD_NAME_EN' C:\work_php\ci202\application\controllers\board.php 16
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_PERM - assumed 'MENU_BOARD_PERM' C:\work_php\ci202\application\controllers\board.php 17
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_CATEGORY_WORD - assumed 'MENU_CATEGORY_WORD' C:\work_php\ci202\application\controllers\board.php 18
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_TOP_USE - assumed 'MENU_TOP_USE' C:\work_php\ci202\application\controllers\board.php 19
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_BOTTOM_USE - assumed 'MENU_BOTTOM_USE' C:\work_php\ci202\application\controllers\board.php 20
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_HEADER_HTML - assumed 'MENU_HEADER_HTML' C:\work_php\ci202\application\controllers\board.php 21
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_FOOTER_HTML - assumed 'MENU_FOOTER_HTML' C:\work_php\ci202\application\controllers\board.php 22
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_HEADER - assumed 'MENU_HEADER' C:\work_php\ci202\application\controllers\board.php 23
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_FOOTER - assumed 'MENU_FOOTER' C:\work_php\ci202\application\controllers\board.php 24
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_DETAIL_SETTING - assumed 'MENU_DETAIL_SETTING' C:\work_php\ci202\application\controllers\board.php 25
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_DETAIL_SETTING - assumed 'MENU_BOARD_DETAIL_SETTING' C:\work_php\ci202\application\controllers\board.php 26
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_LOAD_CONFIG - assumed 'MENU_LOAD_CONFIG' C:\work_php\ci202\application\controllers\board.php 27
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_TYPE - assumed 'MENU_CONNECT_TYPE' C:\work_php\ci202\application\controllers\board.php 28
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_TYPE_CONTENTS - assumed 'MENU_CONNECT_TYPE_CONTENTS' C:\work_php\ci202\application\controllers\board.php 29
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_HTML - assumed 'MENU_CONNECT_HTML' C:\work_php\ci202\application\controllers\board.php 30
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_LINK - assumed 'MENU_CONNECT_LINK' C:\work_php\ci202\application\controllers\board.php 31
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_PLUGIN_NO - assumed 'MENU_CONNECT_PLUGIN_NO' C:\work_php\ci202\application\controllers\board.php 32
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_BOARD_NO - assumed 'MENU_CONNECT_BOARD_NO' C:\work_php\ci202\application\controllers\board.php 33
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_LAYOUT_TYPE - assumed 'MENU_CONNECT_LAYOUT_TYPE' C:\work_php\ci202\application\controllers\board.php 34
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_LAYOUT - assumed 'MENU_CONNECT_LAYOUT' C:\work_php\ci202\application\controllers\board.php 35
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_PERMISSION - assumed 'MENU_PERMISSION' C:\work_php\ci202\application\controllers\board.php 36
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_NAME - assumed 'MENU_MODULE_NAME' C:\work_php\ci202\application\controllers\board.php 37
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_TYPE - assumed 'MENU_MODULE_TYPE' C:\work_php\ci202\application\controllers\board.php 38
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_DIRECTORY - assumed 'MENU_MODULE_DIRECTORY' C:\work_php\ci202\application\controllers\board.php 39
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_DEFAULT_SKIN_NO - assumed 'MENU_DEFAULT_SKIN_NO' C:\work_php\ci202\application\controllers\board.php 40
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_DIRECTORY - assumed 'MENU_SKIN_DIRECTORY' C:\work_php\ci202\application\controllers\board.php 41
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_OPTIONS - assumed 'MENU_SKIN_OPTIONS' C:\work_php\ci202\application\controllers\board.php 42
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_PLUGIN_SKIN_DIRECTORY - assumed 'MENU_PLUGIN_SKIN_DIRECTORY' C:\work_php\ci202\application\controllers\board.php 43
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_PLUGIN_SKIN_OPTIONS - assumed 'MENU_PLUGIN_SKIN_OPTIONS' C:\work_php\ci202\application\controllers\board.php 44
ERROR - 2011-05-22 01:03:19 --> Severity: Notice  --> Use of undefined constant MENU_PARENT_NAME_EN - assumed 'MENU_PARENT_NAME_EN' C:\work_php\ci202\application\controllers\board.php 45
DEBUG - 2011-05-22 01:03:19 --> Final output sent to browser
DEBUG - 2011-05-22 01:03:19 --> Total execution time: 0.2819
DEBUG - 2011-05-22 01:04:49 --> Config Class Initialized
DEBUG - 2011-05-22 01:04:49 --> Hooks Class Initialized
DEBUG - 2011-05-22 01:04:49 --> Utf8 Class Initialized
DEBUG - 2011-05-22 01:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 01:04:49 --> URI Class Initialized
DEBUG - 2011-05-22 01:04:49 --> Router Class Initialized
DEBUG - 2011-05-22 01:04:49 --> Output Class Initialized
DEBUG - 2011-05-22 01:04:49 --> Security Class Initialized
DEBUG - 2011-05-22 01:04:49 --> Input Class Initialized
DEBUG - 2011-05-22 01:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 01:04:49 --> Language Class Initialized
DEBUG - 2011-05-22 01:04:49 --> Loader Class Initialized
DEBUG - 2011-05-22 01:04:49 --> Controller Class Initialized
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_ID - assumed 'MENU_ID' C:\work_php\ci202\application\controllers\board.php 9
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_NAME - assumed 'MENU_NAME' C:\work_php\ci202\application\controllers\board.php 10
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_NAME_EN - assumed 'MENU_NAME_EN' C:\work_php\ci202\application\controllers\board.php 11
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_DETAIL_XML - assumed 'MENU_DETAIL_XML' C:\work_php\ci202\application\controllers\board.php 12
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_PLUGIN_NO - assumed 'MENU_PLUGIN_NO' C:\work_php\ci202\application\controllers\board.php 13
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_NO - assumed 'MENU_SKIN_NO' C:\work_php\ci202\application\controllers\board.php 14
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_NAME - assumed 'MENU_BOARD_NAME' C:\work_php\ci202\application\controllers\board.php 15
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_NAME_EN - assumed 'MENU_BOARD_NAME_EN' C:\work_php\ci202\application\controllers\board.php 16
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_PERM - assumed 'MENU_BOARD_PERM' C:\work_php\ci202\application\controllers\board.php 17
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_CATEGORY_WORD - assumed 'MENU_CATEGORY_WORD' C:\work_php\ci202\application\controllers\board.php 18
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_TOP_USE - assumed 'MENU_TOP_USE' C:\work_php\ci202\application\controllers\board.php 19
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_BOTTOM_USE - assumed 'MENU_BOTTOM_USE' C:\work_php\ci202\application\controllers\board.php 20
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_HEADER_HTML - assumed 'MENU_HEADER_HTML' C:\work_php\ci202\application\controllers\board.php 21
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_FOOTER_HTML - assumed 'MENU_FOOTER_HTML' C:\work_php\ci202\application\controllers\board.php 22
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_HEADER - assumed 'MENU_HEADER' C:\work_php\ci202\application\controllers\board.php 23
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_FOOTER - assumed 'MENU_FOOTER' C:\work_php\ci202\application\controllers\board.php 24
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_DETAIL_SETTING - assumed 'MENU_DETAIL_SETTING' C:\work_php\ci202\application\controllers\board.php 25
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_DETAIL_SETTING - assumed 'MENU_BOARD_DETAIL_SETTING' C:\work_php\ci202\application\controllers\board.php 26
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_LOAD_CONFIG - assumed 'MENU_LOAD_CONFIG' C:\work_php\ci202\application\controllers\board.php 27
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_TYPE - assumed 'MENU_CONNECT_TYPE' C:\work_php\ci202\application\controllers\board.php 28
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_TYPE_CONTENTS - assumed 'MENU_CONNECT_TYPE_CONTENTS' C:\work_php\ci202\application\controllers\board.php 29
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_HTML - assumed 'MENU_CONNECT_HTML' C:\work_php\ci202\application\controllers\board.php 30
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_LINK - assumed 'MENU_CONNECT_LINK' C:\work_php\ci202\application\controllers\board.php 31
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_PLUGIN_NO - assumed 'MENU_CONNECT_PLUGIN_NO' C:\work_php\ci202\application\controllers\board.php 32
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_BOARD_NO - assumed 'MENU_CONNECT_BOARD_NO' C:\work_php\ci202\application\controllers\board.php 33
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_LAYOUT_TYPE - assumed 'MENU_CONNECT_LAYOUT_TYPE' C:\work_php\ci202\application\controllers\board.php 34
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_LAYOUT - assumed 'MENU_CONNECT_LAYOUT' C:\work_php\ci202\application\controllers\board.php 35
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_PERMISSION - assumed 'MENU_PERMISSION' C:\work_php\ci202\application\controllers\board.php 36
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_NAME - assumed 'MENU_MODULE_NAME' C:\work_php\ci202\application\controllers\board.php 37
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_TYPE - assumed 'MENU_MODULE_TYPE' C:\work_php\ci202\application\controllers\board.php 38
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_DIRECTORY - assumed 'MENU_MODULE_DIRECTORY' C:\work_php\ci202\application\controllers\board.php 39
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_DEFAULT_SKIN_NO - assumed 'MENU_DEFAULT_SKIN_NO' C:\work_php\ci202\application\controllers\board.php 40
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_DIRECTORY - assumed 'MENU_SKIN_DIRECTORY' C:\work_php\ci202\application\controllers\board.php 41
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_OPTIONS - assumed 'MENU_SKIN_OPTIONS' C:\work_php\ci202\application\controllers\board.php 42
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_PLUGIN_SKIN_DIRECTORY - assumed 'MENU_PLUGIN_SKIN_DIRECTORY' C:\work_php\ci202\application\controllers\board.php 43
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_PLUGIN_SKIN_OPTIONS - assumed 'MENU_PLUGIN_SKIN_OPTIONS' C:\work_php\ci202\application\controllers\board.php 44
ERROR - 2011-05-22 01:04:49 --> Severity: Notice  --> Use of undefined constant MENU_PARENT_NAME_EN - assumed 'MENU_PARENT_NAME_EN' C:\work_php\ci202\application\controllers\board.php 45
DEBUG - 2011-05-22 01:04:49 --> Final output sent to browser
DEBUG - 2011-05-22 01:04:49 --> Total execution time: 0.2908
DEBUG - 2011-05-22 01:05:46 --> Config Class Initialized
DEBUG - 2011-05-22 01:05:46 --> Hooks Class Initialized
DEBUG - 2011-05-22 01:05:46 --> Utf8 Class Initialized
DEBUG - 2011-05-22 01:05:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 01:05:46 --> URI Class Initialized
DEBUG - 2011-05-22 01:05:46 --> Router Class Initialized
DEBUG - 2011-05-22 01:05:46 --> Output Class Initialized
DEBUG - 2011-05-22 01:05:46 --> Security Class Initialized
DEBUG - 2011-05-22 01:05:46 --> Input Class Initialized
DEBUG - 2011-05-22 01:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 01:05:46 --> Language Class Initialized
DEBUG - 2011-05-22 01:05:46 --> Loader Class Initialized
DEBUG - 2011-05-22 01:05:46 --> Controller Class Initialized
ERROR - 2011-05-22 01:05:46 --> Severity: 4096  --> Object of class Board could not be converted to string C:\work_php\ci202\application\hooks\read_xml.php 16
ERROR - 2011-05-22 01:05:46 --> Severity: Notice  --> Object of class Board to string conversion C:\work_php\ci202\application\hooks\read_xml.php 16
ERROR - 2011-05-22 01:05:46 --> Severity: Notice  --> Undefined variable: Object C:\work_php\ci202\application\hooks\read_xml.php 16
ERROR - 2011-05-22 01:05:46 --> Severity: Notice  --> Trying to get property of non-object C:\work_php\ci202\application\hooks\read_xml.php 16
DEBUG - 2011-05-22 01:06:38 --> Config Class Initialized
DEBUG - 2011-05-22 01:06:38 --> Hooks Class Initialized
DEBUG - 2011-05-22 01:06:38 --> Utf8 Class Initialized
DEBUG - 2011-05-22 01:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 01:06:38 --> URI Class Initialized
DEBUG - 2011-05-22 01:06:38 --> Router Class Initialized
DEBUG - 2011-05-22 01:06:38 --> Output Class Initialized
DEBUG - 2011-05-22 01:06:38 --> Security Class Initialized
DEBUG - 2011-05-22 01:06:38 --> Input Class Initialized
DEBUG - 2011-05-22 01:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 01:06:38 --> Language Class Initialized
DEBUG - 2011-05-22 01:06:38 --> Loader Class Initialized
DEBUG - 2011-05-22 01:06:38 --> Controller Class Initialized
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_ID - assumed 'MENU_ID' C:\work_php\ci202\application\controllers\board.php 9
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_NAME - assumed 'MENU_NAME' C:\work_php\ci202\application\controllers\board.php 10
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_NAME_EN - assumed 'MENU_NAME_EN' C:\work_php\ci202\application\controllers\board.php 11
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_DETAIL_XML - assumed 'MENU_DETAIL_XML' C:\work_php\ci202\application\controllers\board.php 12
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_PLUGIN_NO - assumed 'MENU_PLUGIN_NO' C:\work_php\ci202\application\controllers\board.php 13
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_NO - assumed 'MENU_SKIN_NO' C:\work_php\ci202\application\controllers\board.php 14
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_NAME - assumed 'MENU_BOARD_NAME' C:\work_php\ci202\application\controllers\board.php 15
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_NAME_EN - assumed 'MENU_BOARD_NAME_EN' C:\work_php\ci202\application\controllers\board.php 16
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_PERM - assumed 'MENU_BOARD_PERM' C:\work_php\ci202\application\controllers\board.php 17
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_CATEGORY_WORD - assumed 'MENU_CATEGORY_WORD' C:\work_php\ci202\application\controllers\board.php 18
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_TOP_USE - assumed 'MENU_TOP_USE' C:\work_php\ci202\application\controllers\board.php 19
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_BOTTOM_USE - assumed 'MENU_BOTTOM_USE' C:\work_php\ci202\application\controllers\board.php 20
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_HEADER_HTML - assumed 'MENU_HEADER_HTML' C:\work_php\ci202\application\controllers\board.php 21
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_FOOTER_HTML - assumed 'MENU_FOOTER_HTML' C:\work_php\ci202\application\controllers\board.php 22
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_HEADER - assumed 'MENU_HEADER' C:\work_php\ci202\application\controllers\board.php 23
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_FOOTER - assumed 'MENU_FOOTER' C:\work_php\ci202\application\controllers\board.php 24
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_DETAIL_SETTING - assumed 'MENU_DETAIL_SETTING' C:\work_php\ci202\application\controllers\board.php 25
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_DETAIL_SETTING - assumed 'MENU_BOARD_DETAIL_SETTING' C:\work_php\ci202\application\controllers\board.php 26
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_LOAD_CONFIG - assumed 'MENU_LOAD_CONFIG' C:\work_php\ci202\application\controllers\board.php 27
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_TYPE - assumed 'MENU_CONNECT_TYPE' C:\work_php\ci202\application\controllers\board.php 28
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_TYPE_CONTENTS - assumed 'MENU_CONNECT_TYPE_CONTENTS' C:\work_php\ci202\application\controllers\board.php 29
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_HTML - assumed 'MENU_CONNECT_HTML' C:\work_php\ci202\application\controllers\board.php 30
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_LINK - assumed 'MENU_CONNECT_LINK' C:\work_php\ci202\application\controllers\board.php 31
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_PLUGIN_NO - assumed 'MENU_CONNECT_PLUGIN_NO' C:\work_php\ci202\application\controllers\board.php 32
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_BOARD_NO - assumed 'MENU_CONNECT_BOARD_NO' C:\work_php\ci202\application\controllers\board.php 33
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_LAYOUT_TYPE - assumed 'MENU_CONNECT_LAYOUT_TYPE' C:\work_php\ci202\application\controllers\board.php 34
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_LAYOUT - assumed 'MENU_CONNECT_LAYOUT' C:\work_php\ci202\application\controllers\board.php 35
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_PERMISSION - assumed 'MENU_PERMISSION' C:\work_php\ci202\application\controllers\board.php 36
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_NAME - assumed 'MENU_MODULE_NAME' C:\work_php\ci202\application\controllers\board.php 37
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_TYPE - assumed 'MENU_MODULE_TYPE' C:\work_php\ci202\application\controllers\board.php 38
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_DIRECTORY - assumed 'MENU_MODULE_DIRECTORY' C:\work_php\ci202\application\controllers\board.php 39
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_DEFAULT_SKIN_NO - assumed 'MENU_DEFAULT_SKIN_NO' C:\work_php\ci202\application\controllers\board.php 40
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_DIRECTORY - assumed 'MENU_SKIN_DIRECTORY' C:\work_php\ci202\application\controllers\board.php 41
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_OPTIONS - assumed 'MENU_SKIN_OPTIONS' C:\work_php\ci202\application\controllers\board.php 42
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_PLUGIN_SKIN_DIRECTORY - assumed 'MENU_PLUGIN_SKIN_DIRECTORY' C:\work_php\ci202\application\controllers\board.php 43
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_PLUGIN_SKIN_OPTIONS - assumed 'MENU_PLUGIN_SKIN_OPTIONS' C:\work_php\ci202\application\controllers\board.php 44
ERROR - 2011-05-22 01:06:39 --> Severity: Notice  --> Use of undefined constant MENU_PARENT_NAME_EN - assumed 'MENU_PARENT_NAME_EN' C:\work_php\ci202\application\controllers\board.php 45
DEBUG - 2011-05-22 01:06:39 --> Final output sent to browser
DEBUG - 2011-05-22 01:06:39 --> Total execution time: 0.2949
DEBUG - 2011-05-22 01:07:45 --> Config Class Initialized
DEBUG - 2011-05-22 01:07:45 --> Hooks Class Initialized
DEBUG - 2011-05-22 01:07:45 --> Utf8 Class Initialized
DEBUG - 2011-05-22 01:07:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 01:07:45 --> URI Class Initialized
DEBUG - 2011-05-22 01:07:45 --> Router Class Initialized
DEBUG - 2011-05-22 01:07:45 --> Output Class Initialized
DEBUG - 2011-05-22 01:07:45 --> Security Class Initialized
DEBUG - 2011-05-22 01:07:45 --> Input Class Initialized
DEBUG - 2011-05-22 01:07:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 01:07:45 --> Language Class Initialized
DEBUG - 2011-05-22 01:07:45 --> Loader Class Initialized
DEBUG - 2011-05-22 01:07:45 --> Controller Class Initialized
DEBUG - 2011-05-22 01:07:45 --> Final output sent to browser
DEBUG - 2011-05-22 01:07:45 --> Total execution time: 0.1334
DEBUG - 2011-05-22 01:08:40 --> Config Class Initialized
DEBUG - 2011-05-22 01:08:40 --> Hooks Class Initialized
DEBUG - 2011-05-22 01:08:40 --> Utf8 Class Initialized
DEBUG - 2011-05-22 01:08:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 01:08:40 --> URI Class Initialized
DEBUG - 2011-05-22 01:08:40 --> Router Class Initialized
DEBUG - 2011-05-22 01:08:40 --> Output Class Initialized
DEBUG - 2011-05-22 01:08:40 --> Security Class Initialized
DEBUG - 2011-05-22 01:08:40 --> Input Class Initialized
DEBUG - 2011-05-22 01:08:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 01:08:40 --> Language Class Initialized
DEBUG - 2011-05-22 01:08:40 --> Loader Class Initialized
DEBUG - 2011-05-22 01:08:40 --> Controller Class Initialized
DEBUG - 2011-05-22 01:08:40 --> Final output sent to browser
DEBUG - 2011-05-22 01:08:40 --> Total execution time: 0.1195
DEBUG - 2011-05-22 01:09:17 --> Config Class Initialized
DEBUG - 2011-05-22 01:09:17 --> Hooks Class Initialized
DEBUG - 2011-05-22 01:09:17 --> Utf8 Class Initialized
DEBUG - 2011-05-22 01:09:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 01:09:17 --> URI Class Initialized
DEBUG - 2011-05-22 01:09:17 --> Router Class Initialized
DEBUG - 2011-05-22 01:09:17 --> Output Class Initialized
DEBUG - 2011-05-22 01:09:17 --> Security Class Initialized
DEBUG - 2011-05-22 01:09:17 --> Input Class Initialized
DEBUG - 2011-05-22 01:09:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 01:09:17 --> Language Class Initialized
DEBUG - 2011-05-22 01:09:17 --> Loader Class Initialized
DEBUG - 2011-05-22 01:09:17 --> Controller Class Initialized
DEBUG - 2011-05-22 01:09:17 --> Final output sent to browser
DEBUG - 2011-05-22 01:09:17 --> Total execution time: 0.1209
DEBUG - 2011-05-22 01:10:31 --> Config Class Initialized
DEBUG - 2011-05-22 01:10:31 --> Hooks Class Initialized
DEBUG - 2011-05-22 01:10:31 --> Utf8 Class Initialized
DEBUG - 2011-05-22 01:10:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 01:10:31 --> URI Class Initialized
DEBUG - 2011-05-22 01:10:31 --> Router Class Initialized
DEBUG - 2011-05-22 01:10:31 --> Output Class Initialized
DEBUG - 2011-05-22 01:10:31 --> Security Class Initialized
DEBUG - 2011-05-22 01:10:31 --> Input Class Initialized
DEBUG - 2011-05-22 01:10:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 01:10:31 --> Language Class Initialized
DEBUG - 2011-05-22 01:10:31 --> Loader Class Initialized
DEBUG - 2011-05-22 01:10:31 --> Controller Class Initialized
DEBUG - 2011-05-22 01:10:31 --> Final output sent to browser
DEBUG - 2011-05-22 01:10:31 --> Total execution time: 0.1190
DEBUG - 2011-05-22 01:11:44 --> Config Class Initialized
DEBUG - 2011-05-22 01:11:44 --> Hooks Class Initialized
DEBUG - 2011-05-22 01:11:44 --> Utf8 Class Initialized
DEBUG - 2011-05-22 01:11:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 01:11:44 --> URI Class Initialized
DEBUG - 2011-05-22 01:11:44 --> Router Class Initialized
DEBUG - 2011-05-22 01:11:44 --> Output Class Initialized
DEBUG - 2011-05-22 01:11:44 --> Security Class Initialized
DEBUG - 2011-05-22 01:11:44 --> Input Class Initialized
DEBUG - 2011-05-22 01:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 01:11:44 --> Language Class Initialized
DEBUG - 2011-05-22 01:11:44 --> Loader Class Initialized
DEBUG - 2011-05-22 01:11:44 --> Controller Class Initialized
DEBUG - 2011-05-22 01:11:44 --> Final output sent to browser
DEBUG - 2011-05-22 01:11:44 --> Total execution time: 0.1190
DEBUG - 2011-05-22 01:13:21 --> Config Class Initialized
DEBUG - 2011-05-22 01:13:21 --> Hooks Class Initialized
DEBUG - 2011-05-22 01:13:21 --> Utf8 Class Initialized
DEBUG - 2011-05-22 01:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 01:13:21 --> URI Class Initialized
DEBUG - 2011-05-22 01:13:21 --> Router Class Initialized
DEBUG - 2011-05-22 01:13:21 --> Output Class Initialized
DEBUG - 2011-05-22 01:13:21 --> Security Class Initialized
DEBUG - 2011-05-22 01:13:21 --> Input Class Initialized
DEBUG - 2011-05-22 01:13:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 01:13:21 --> Language Class Initialized
DEBUG - 2011-05-22 01:13:21 --> Loader Class Initialized
DEBUG - 2011-05-22 01:13:21 --> Controller Class Initialized
DEBUG - 2011-05-22 01:13:21 --> Final output sent to browser
DEBUG - 2011-05-22 01:13:21 --> Total execution time: 0.1195
DEBUG - 2011-05-22 01:34:34 --> Config Class Initialized
DEBUG - 2011-05-22 01:34:34 --> Hooks Class Initialized
DEBUG - 2011-05-22 01:34:34 --> Utf8 Class Initialized
DEBUG - 2011-05-22 01:34:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 01:34:34 --> URI Class Initialized
DEBUG - 2011-05-22 01:34:34 --> Router Class Initialized
ERROR - 2011-05-22 01:34:34 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 02:08:30 --> Config Class Initialized
DEBUG - 2011-05-22 02:08:30 --> Hooks Class Initialized
DEBUG - 2011-05-22 02:08:30 --> Utf8 Class Initialized
DEBUG - 2011-05-22 02:08:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 02:08:30 --> URI Class Initialized
DEBUG - 2011-05-22 02:08:30 --> Router Class Initialized
DEBUG - 2011-05-22 02:08:30 --> Output Class Initialized
DEBUG - 2011-05-22 02:08:30 --> Security Class Initialized
DEBUG - 2011-05-22 02:08:30 --> Input Class Initialized
DEBUG - 2011-05-22 02:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 02:08:30 --> Language Class Initialized
DEBUG - 2011-05-22 02:08:30 --> Loader Class Initialized
DEBUG - 2011-05-22 02:08:30 --> Controller Class Initialized
DEBUG - 2011-05-22 02:08:30 --> Final output sent to browser
DEBUG - 2011-05-22 02:08:30 --> Total execution time: 0.1195
DEBUG - 2011-05-22 02:08:36 --> Config Class Initialized
DEBUG - 2011-05-22 02:08:36 --> Hooks Class Initialized
DEBUG - 2011-05-22 02:08:36 --> Utf8 Class Initialized
DEBUG - 2011-05-22 02:08:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 02:08:36 --> URI Class Initialized
DEBUG - 2011-05-22 02:08:36 --> Router Class Initialized
DEBUG - 2011-05-22 02:08:36 --> Output Class Initialized
DEBUG - 2011-05-22 02:08:36 --> Security Class Initialized
DEBUG - 2011-05-22 02:08:36 --> Input Class Initialized
DEBUG - 2011-05-22 02:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 02:08:36 --> Language Class Initialized
DEBUG - 2011-05-22 02:08:36 --> Loader Class Initialized
DEBUG - 2011-05-22 02:08:36 --> Controller Class Initialized
DEBUG - 2011-05-22 02:08:36 --> Final output sent to browser
DEBUG - 2011-05-22 02:08:36 --> Total execution time: 0.1275
DEBUG - 2011-05-22 02:08:55 --> Config Class Initialized
DEBUG - 2011-05-22 02:08:55 --> Hooks Class Initialized
DEBUG - 2011-05-22 02:08:55 --> Utf8 Class Initialized
DEBUG - 2011-05-22 02:08:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 02:08:55 --> URI Class Initialized
DEBUG - 2011-05-22 02:08:55 --> Router Class Initialized
DEBUG - 2011-05-22 02:08:55 --> Output Class Initialized
DEBUG - 2011-05-22 02:08:55 --> Security Class Initialized
DEBUG - 2011-05-22 02:08:55 --> Input Class Initialized
DEBUG - 2011-05-22 02:08:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 02:08:55 --> Language Class Initialized
DEBUG - 2011-05-22 02:08:55 --> Loader Class Initialized
DEBUG - 2011-05-22 02:08:55 --> Controller Class Initialized
DEBUG - 2011-05-22 02:08:55 --> Final output sent to browser
DEBUG - 2011-05-22 02:08:55 --> Total execution time: 0.1189
DEBUG - 2011-05-22 02:08:56 --> Config Class Initialized
DEBUG - 2011-05-22 02:08:56 --> Hooks Class Initialized
DEBUG - 2011-05-22 02:08:56 --> Utf8 Class Initialized
DEBUG - 2011-05-22 02:08:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 02:08:56 --> URI Class Initialized
DEBUG - 2011-05-22 02:08:56 --> Router Class Initialized
DEBUG - 2011-05-22 02:08:56 --> Output Class Initialized
DEBUG - 2011-05-22 02:08:56 --> Security Class Initialized
DEBUG - 2011-05-22 02:08:56 --> Input Class Initialized
DEBUG - 2011-05-22 02:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 02:08:56 --> Language Class Initialized
DEBUG - 2011-05-22 02:08:56 --> Loader Class Initialized
DEBUG - 2011-05-22 02:08:56 --> Controller Class Initialized
DEBUG - 2011-05-22 02:08:56 --> Final output sent to browser
DEBUG - 2011-05-22 02:08:56 --> Total execution time: 0.1190
DEBUG - 2011-05-22 02:10:17 --> Config Class Initialized
DEBUG - 2011-05-22 02:10:17 --> Hooks Class Initialized
DEBUG - 2011-05-22 02:10:17 --> Utf8 Class Initialized
DEBUG - 2011-05-22 02:10:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 02:10:17 --> URI Class Initialized
DEBUG - 2011-05-22 02:10:17 --> Router Class Initialized
DEBUG - 2011-05-22 02:10:17 --> Output Class Initialized
DEBUG - 2011-05-22 02:10:17 --> Security Class Initialized
DEBUG - 2011-05-22 02:10:17 --> Input Class Initialized
DEBUG - 2011-05-22 02:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 02:10:17 --> Language Class Initialized
DEBUG - 2011-05-22 02:10:17 --> Loader Class Initialized
DEBUG - 2011-05-22 02:10:17 --> Controller Class Initialized
DEBUG - 2011-05-22 02:10:17 --> Final output sent to browser
DEBUG - 2011-05-22 02:10:17 --> Total execution time: 0.1299
DEBUG - 2011-05-22 02:11:04 --> Config Class Initialized
DEBUG - 2011-05-22 02:11:04 --> Hooks Class Initialized
DEBUG - 2011-05-22 02:11:04 --> Utf8 Class Initialized
DEBUG - 2011-05-22 02:11:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 02:11:04 --> URI Class Initialized
DEBUG - 2011-05-22 02:11:04 --> Router Class Initialized
DEBUG - 2011-05-22 02:11:04 --> Output Class Initialized
DEBUG - 2011-05-22 02:11:04 --> Security Class Initialized
DEBUG - 2011-05-22 02:11:04 --> Input Class Initialized
DEBUG - 2011-05-22 02:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 02:11:04 --> Language Class Initialized
DEBUG - 2011-05-22 02:11:04 --> Loader Class Initialized
DEBUG - 2011-05-22 02:11:04 --> Controller Class Initialized
DEBUG - 2011-05-22 02:11:04 --> Final output sent to browser
DEBUG - 2011-05-22 02:11:04 --> Total execution time: 0.1189
DEBUG - 2011-05-22 02:29:54 --> Config Class Initialized
DEBUG - 2011-05-22 02:29:54 --> Hooks Class Initialized
DEBUG - 2011-05-22 02:29:54 --> Utf8 Class Initialized
DEBUG - 2011-05-22 02:29:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 02:29:54 --> URI Class Initialized
DEBUG - 2011-05-22 02:29:54 --> Router Class Initialized
ERROR - 2011-05-22 02:29:54 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 02:29:57 --> Config Class Initialized
DEBUG - 2011-05-22 02:29:57 --> Hooks Class Initialized
DEBUG - 2011-05-22 02:29:57 --> Utf8 Class Initialized
DEBUG - 2011-05-22 02:29:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 02:29:57 --> URI Class Initialized
DEBUG - 2011-05-22 02:29:57 --> Router Class Initialized
ERROR - 2011-05-22 02:29:57 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 02:34:34 --> Config Class Initialized
DEBUG - 2011-05-22 02:34:34 --> Hooks Class Initialized
DEBUG - 2011-05-22 02:34:34 --> Utf8 Class Initialized
DEBUG - 2011-05-22 02:34:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 02:34:34 --> URI Class Initialized
DEBUG - 2011-05-22 02:34:34 --> Router Class Initialized
ERROR - 2011-05-22 02:34:34 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 03:12:44 --> Config Class Initialized
DEBUG - 2011-05-22 03:12:44 --> Hooks Class Initialized
DEBUG - 2011-05-22 03:12:44 --> Utf8 Class Initialized
DEBUG - 2011-05-22 03:12:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 03:12:44 --> URI Class Initialized
DEBUG - 2011-05-22 03:12:44 --> Router Class Initialized
ERROR - 2011-05-22 03:12:44 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 03:14:17 --> Config Class Initialized
DEBUG - 2011-05-22 03:14:17 --> Hooks Class Initialized
DEBUG - 2011-05-22 03:14:17 --> Utf8 Class Initialized
DEBUG - 2011-05-22 03:14:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 03:14:17 --> URI Class Initialized
DEBUG - 2011-05-22 03:14:17 --> Router Class Initialized
ERROR - 2011-05-22 03:14:17 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 03:18:20 --> Config Class Initialized
DEBUG - 2011-05-22 03:18:20 --> Hooks Class Initialized
DEBUG - 2011-05-22 03:18:20 --> Utf8 Class Initialized
DEBUG - 2011-05-22 03:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 03:18:20 --> URI Class Initialized
DEBUG - 2011-05-22 03:18:20 --> Router Class Initialized
ERROR - 2011-05-22 03:18:20 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 03:18:24 --> Config Class Initialized
DEBUG - 2011-05-22 03:18:24 --> Hooks Class Initialized
DEBUG - 2011-05-22 03:18:24 --> Utf8 Class Initialized
DEBUG - 2011-05-22 03:18:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 03:18:24 --> URI Class Initialized
DEBUG - 2011-05-22 03:18:24 --> Router Class Initialized
ERROR - 2011-05-22 03:18:24 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 03:18:42 --> Config Class Initialized
DEBUG - 2011-05-22 03:18:42 --> Hooks Class Initialized
DEBUG - 2011-05-22 03:18:42 --> Utf8 Class Initialized
DEBUG - 2011-05-22 03:18:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 03:18:42 --> URI Class Initialized
DEBUG - 2011-05-22 03:18:42 --> Router Class Initialized
ERROR - 2011-05-22 03:18:42 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 03:32:10 --> Config Class Initialized
DEBUG - 2011-05-22 03:32:10 --> Hooks Class Initialized
DEBUG - 2011-05-22 03:32:10 --> Utf8 Class Initialized
DEBUG - 2011-05-22 03:32:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 03:32:10 --> URI Class Initialized
DEBUG - 2011-05-22 03:32:10 --> Router Class Initialized
ERROR - 2011-05-22 03:32:10 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 03:32:11 --> Config Class Initialized
DEBUG - 2011-05-22 03:32:11 --> Hooks Class Initialized
DEBUG - 2011-05-22 03:32:11 --> Utf8 Class Initialized
DEBUG - 2011-05-22 03:32:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 03:32:11 --> URI Class Initialized
DEBUG - 2011-05-22 03:32:11 --> Router Class Initialized
ERROR - 2011-05-22 03:32:11 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 03:32:11 --> Config Class Initialized
DEBUG - 2011-05-22 03:32:11 --> Hooks Class Initialized
DEBUG - 2011-05-22 03:32:11 --> Utf8 Class Initialized
DEBUG - 2011-05-22 03:32:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 03:32:11 --> URI Class Initialized
DEBUG - 2011-05-22 03:32:11 --> Router Class Initialized
ERROR - 2011-05-22 03:32:11 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 03:32:11 --> Config Class Initialized
DEBUG - 2011-05-22 03:32:11 --> Hooks Class Initialized
DEBUG - 2011-05-22 03:32:11 --> Utf8 Class Initialized
DEBUG - 2011-05-22 03:32:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 03:32:11 --> URI Class Initialized
DEBUG - 2011-05-22 03:32:11 --> Router Class Initialized
ERROR - 2011-05-22 03:32:11 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 03:32:11 --> Config Class Initialized
DEBUG - 2011-05-22 03:32:11 --> Hooks Class Initialized
DEBUG - 2011-05-22 03:32:11 --> Utf8 Class Initialized
DEBUG - 2011-05-22 03:32:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 03:32:11 --> URI Class Initialized
DEBUG - 2011-05-22 03:32:11 --> Router Class Initialized
ERROR - 2011-05-22 03:32:11 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 03:32:11 --> Config Class Initialized
DEBUG - 2011-05-22 03:32:11 --> Hooks Class Initialized
DEBUG - 2011-05-22 03:32:11 --> Utf8 Class Initialized
DEBUG - 2011-05-22 03:32:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 03:32:11 --> URI Class Initialized
DEBUG - 2011-05-22 03:32:11 --> Router Class Initialized
ERROR - 2011-05-22 03:32:11 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 03:34:33 --> Config Class Initialized
DEBUG - 2011-05-22 03:34:33 --> Hooks Class Initialized
DEBUG - 2011-05-22 03:34:33 --> Utf8 Class Initialized
DEBUG - 2011-05-22 03:34:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 03:34:33 --> URI Class Initialized
DEBUG - 2011-05-22 03:34:33 --> Router Class Initialized
ERROR - 2011-05-22 03:34:33 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 03:34:51 --> Config Class Initialized
DEBUG - 2011-05-22 03:34:51 --> Hooks Class Initialized
DEBUG - 2011-05-22 03:34:51 --> Utf8 Class Initialized
DEBUG - 2011-05-22 03:34:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 03:34:51 --> URI Class Initialized
DEBUG - 2011-05-22 03:34:51 --> Router Class Initialized
DEBUG - 2011-05-22 03:34:51 --> No URI present. Default controller set.
DEBUG - 2011-05-22 03:34:51 --> Output Class Initialized
DEBUG - 2011-05-22 03:34:51 --> Security Class Initialized
DEBUG - 2011-05-22 03:34:51 --> Input Class Initialized
DEBUG - 2011-05-22 03:34:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 03:34:51 --> Language Class Initialized
DEBUG - 2011-05-22 03:34:51 --> Loader Class Initialized
DEBUG - 2011-05-22 03:34:51 --> Controller Class Initialized
DEBUG - 2011-05-22 03:34:51 --> File loaded: application/views/welcome_message.php
DEBUG - 2011-05-22 03:34:51 --> Final output sent to browser
DEBUG - 2011-05-22 03:34:51 --> Total execution time: 0.1021
DEBUG - 2011-05-22 03:41:37 --> Config Class Initialized
DEBUG - 2011-05-22 03:41:37 --> Hooks Class Initialized
DEBUG - 2011-05-22 03:41:37 --> Utf8 Class Initialized
DEBUG - 2011-05-22 03:41:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 03:41:37 --> URI Class Initialized
DEBUG - 2011-05-22 03:41:37 --> Router Class Initialized
ERROR - 2011-05-22 03:41:37 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 19:00:39 --> Config Class Initialized
DEBUG - 2011-05-22 19:00:39 --> Hooks Class Initialized
DEBUG - 2011-05-22 19:00:39 --> Config Class Initialized
DEBUG - 2011-05-22 19:00:39 --> Config Class Initialized
DEBUG - 2011-05-22 19:00:39 --> Hooks Class Initialized
DEBUG - 2011-05-22 19:00:39 --> Config Class Initialized
DEBUG - 2011-05-22 19:00:39 --> Hooks Class Initialized
DEBUG - 2011-05-22 19:00:39 --> Utf8 Class Initialized
DEBUG - 2011-05-22 19:00:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 19:00:39 --> Utf8 Class Initialized
DEBUG - 2011-05-22 19:00:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 19:00:39 --> URI Class Initialized
DEBUG - 2011-05-22 19:00:39 --> URI Class Initialized
DEBUG - 2011-05-22 19:00:39 --> Router Class Initialized
DEBUG - 2011-05-22 19:00:39 --> Router Class Initialized
ERROR - 2011-05-22 19:00:39 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 19:00:39 --> Utf8 Class Initialized
DEBUG - 2011-05-22 19:00:39 --> UTF-8 Support Enabled
ERROR - 2011-05-22 19:00:39 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 19:00:39 --> Hooks Class Initialized
DEBUG - 2011-05-22 19:00:39 --> URI Class Initialized
DEBUG - 2011-05-22 19:00:39 --> Router Class Initialized
DEBUG - 2011-05-22 19:00:39 --> Utf8 Class Initialized
DEBUG - 2011-05-22 19:00:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 19:00:39 --> URI Class Initialized
DEBUG - 2011-05-22 19:00:39 --> Router Class Initialized
ERROR - 2011-05-22 19:00:39 --> 404 Page Not Found --> wpad.dat
ERROR - 2011-05-22 19:00:39 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 19:00:39 --> Config Class Initialized
DEBUG - 2011-05-22 19:00:39 --> Hooks Class Initialized
DEBUG - 2011-05-22 19:00:39 --> Utf8 Class Initialized
DEBUG - 2011-05-22 19:00:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 19:00:39 --> URI Class Initialized
DEBUG - 2011-05-22 19:00:39 --> Router Class Initialized
ERROR - 2011-05-22 19:00:39 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-22 19:00:44 --> Config Class Initialized
DEBUG - 2011-05-22 19:00:44 --> Hooks Class Initialized
DEBUG - 2011-05-22 19:00:44 --> Utf8 Class Initialized
DEBUG - 2011-05-22 19:00:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 19:00:44 --> URI Class Initialized
DEBUG - 2011-05-22 19:00:44 --> Router Class Initialized
ERROR - 2011-05-22 19:00:44 --> 404 Page Not Found --> wpad.dat
