<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mvc extends CI_Controller {

	public function index()
	{
		//database 라이브러리 로딩
		$this->load->database();

		//model 로딩 및 데이터 가져오기
		$this->load->model('model_m');
		$data['result'] = $this->model_m->table_get('board');

		//view
		$this->load->view('list_v', $data);

	}
}