<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-27 23:05:36 --> Config Class Initialized
DEBUG - 2011-05-27 23:05:36 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:05:36 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:05:36 --> Config Class Initialized
DEBUG - 2011-05-27 23:05:36 --> Config Class Initialized
DEBUG - 2011-05-27 23:05:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:05:36 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:05:36 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:05:36 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:05:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:05:36 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:05:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:05:36 --> URI Class Initialized
DEBUG - 2011-05-27 23:05:36 --> URI Class Initialized
DEBUG - 2011-05-27 23:05:36 --> Router Class Initialized
DEBUG - 2011-05-27 23:05:36 --> Router Class Initialized
DEBUG - 2011-05-27 23:05:36 --> URI Class Initialized
ERROR - 2011-05-27 23:05:36 --> 404 Page Not Found --> wpad.dat
ERROR - 2011-05-27 23:05:36 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:05:36 --> Router Class Initialized
ERROR - 2011-05-27 23:05:36 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:05:57 --> Config Class Initialized
DEBUG - 2011-05-27 23:05:57 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:05:57 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:05:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:05:57 --> URI Class Initialized
DEBUG - 2011-05-27 23:05:57 --> Router Class Initialized
ERROR - 2011-05-27 23:05:57 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:06:01 --> Config Class Initialized
DEBUG - 2011-05-27 23:06:01 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:06:01 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:06:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:06:01 --> URI Class Initialized
DEBUG - 2011-05-27 23:06:01 --> Router Class Initialized
ERROR - 2011-05-27 23:06:01 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:06:53 --> Config Class Initialized
DEBUG - 2011-05-27 23:06:53 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:06:53 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:06:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:06:53 --> URI Class Initialized
DEBUG - 2011-05-27 23:06:53 --> Router Class Initialized
ERROR - 2011-05-27 23:06:53 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:06:53 --> Config Class Initialized
DEBUG - 2011-05-27 23:06:53 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:06:53 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:06:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:06:53 --> URI Class Initialized
DEBUG - 2011-05-27 23:06:53 --> Router Class Initialized
ERROR - 2011-05-27 23:06:53 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:06:53 --> Config Class Initialized
DEBUG - 2011-05-27 23:06:53 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:06:53 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:06:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:06:53 --> URI Class Initialized
DEBUG - 2011-05-27 23:06:53 --> Router Class Initialized
ERROR - 2011-05-27 23:06:53 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:07:46 --> Config Class Initialized
DEBUG - 2011-05-27 23:07:46 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:07:46 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:07:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:07:46 --> URI Class Initialized
DEBUG - 2011-05-27 23:07:46 --> Router Class Initialized
ERROR - 2011-05-27 23:07:46 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:07:52 --> Config Class Initialized
DEBUG - 2011-05-27 23:07:52 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:07:52 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:07:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:07:52 --> URI Class Initialized
DEBUG - 2011-05-27 23:07:52 --> Router Class Initialized
ERROR - 2011-05-27 23:07:52 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:07:55 --> Config Class Initialized
DEBUG - 2011-05-27 23:07:55 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:07:55 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:07:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:07:55 --> URI Class Initialized
DEBUG - 2011-05-27 23:07:55 --> Router Class Initialized
ERROR - 2011-05-27 23:07:55 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:08:40 --> Config Class Initialized
DEBUG - 2011-05-27 23:08:40 --> Config Class Initialized
DEBUG - 2011-05-27 23:08:40 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:08:40 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:08:40 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:08:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:08:40 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:08:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:08:40 --> URI Class Initialized
DEBUG - 2011-05-27 23:08:40 --> URI Class Initialized
DEBUG - 2011-05-27 23:08:40 --> Router Class Initialized
DEBUG - 2011-05-27 23:08:40 --> Router Class Initialized
ERROR - 2011-05-27 23:08:40 --> 404 Page Not Found --> wpad.dat
ERROR - 2011-05-27 23:08:40 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:08:40 --> Config Class Initialized
DEBUG - 2011-05-27 23:08:40 --> Config Class Initialized
DEBUG - 2011-05-27 23:08:40 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:08:40 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:08:40 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:08:40 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:08:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:08:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:08:40 --> URI Class Initialized
DEBUG - 2011-05-27 23:08:40 --> URI Class Initialized
DEBUG - 2011-05-27 23:08:40 --> Router Class Initialized
DEBUG - 2011-05-27 23:08:40 --> Router Class Initialized
ERROR - 2011-05-27 23:08:40 --> 404 Page Not Found --> wpad.dat
ERROR - 2011-05-27 23:08:40 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:08:40 --> Config Class Initialized
DEBUG - 2011-05-27 23:08:40 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:08:40 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:08:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:08:40 --> URI Class Initialized
DEBUG - 2011-05-27 23:08:40 --> Router Class Initialized
ERROR - 2011-05-27 23:08:40 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:08:41 --> Config Class Initialized
DEBUG - 2011-05-27 23:08:41 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:08:41 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:08:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:08:41 --> URI Class Initialized
DEBUG - 2011-05-27 23:08:41 --> Router Class Initialized
ERROR - 2011-05-27 23:08:41 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:08:46 --> Config Class Initialized
DEBUG - 2011-05-27 23:08:46 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:08:46 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:08:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:08:46 --> URI Class Initialized
DEBUG - 2011-05-27 23:08:46 --> Router Class Initialized
ERROR - 2011-05-27 23:08:46 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:09:11 --> Config Class Initialized
DEBUG - 2011-05-27 23:09:11 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:09:11 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:09:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:09:11 --> URI Class Initialized
DEBUG - 2011-05-27 23:09:11 --> Router Class Initialized
ERROR - 2011-05-27 23:09:11 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:09:11 --> Config Class Initialized
DEBUG - 2011-05-27 23:09:11 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:09:11 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:09:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:09:11 --> URI Class Initialized
DEBUG - 2011-05-27 23:09:11 --> Router Class Initialized
ERROR - 2011-05-27 23:09:11 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:09:18 --> Config Class Initialized
DEBUG - 2011-05-27 23:09:18 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:09:18 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:09:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:09:18 --> URI Class Initialized
DEBUG - 2011-05-27 23:09:18 --> Router Class Initialized
ERROR - 2011-05-27 23:09:18 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:09:28 --> Config Class Initialized
DEBUG - 2011-05-27 23:09:28 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:09:28 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:09:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:09:28 --> URI Class Initialized
DEBUG - 2011-05-27 23:09:28 --> Router Class Initialized
ERROR - 2011-05-27 23:09:28 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:09:48 --> Config Class Initialized
DEBUG - 2011-05-27 23:09:48 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:09:48 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:09:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:09:48 --> URI Class Initialized
DEBUG - 2011-05-27 23:09:48 --> Router Class Initialized
ERROR - 2011-05-27 23:09:48 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:10:46 --> Config Class Initialized
DEBUG - 2011-05-27 23:10:46 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:10:46 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:10:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:10:46 --> URI Class Initialized
DEBUG - 2011-05-27 23:10:46 --> Router Class Initialized
ERROR - 2011-05-27 23:10:46 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:11:48 --> Config Class Initialized
DEBUG - 2011-05-27 23:11:48 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:11:48 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:11:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:11:48 --> URI Class Initialized
DEBUG - 2011-05-27 23:11:48 --> Router Class Initialized
ERROR - 2011-05-27 23:11:48 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:17:25 --> Config Class Initialized
DEBUG - 2011-05-27 23:17:25 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:17:25 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:17:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:17:26 --> URI Class Initialized
DEBUG - 2011-05-27 23:17:26 --> Config Class Initialized
DEBUG - 2011-05-27 23:17:26 --> Router Class Initialized
DEBUG - 2011-05-27 23:17:26 --> Hooks Class Initialized
ERROR - 2011-05-27 23:17:26 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:17:26 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:17:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:17:26 --> URI Class Initialized
DEBUG - 2011-05-27 23:17:26 --> Router Class Initialized
ERROR - 2011-05-27 23:17:26 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:17:26 --> Config Class Initialized
DEBUG - 2011-05-27 23:17:26 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:17:26 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:17:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:17:26 --> URI Class Initialized
DEBUG - 2011-05-27 23:17:26 --> Router Class Initialized
DEBUG - 2011-05-27 23:17:26 --> Config Class Initialized
DEBUG - 2011-05-27 23:17:26 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:17:26 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:17:26 --> UTF-8 Support Enabled
ERROR - 2011-05-27 23:17:26 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:17:26 --> URI Class Initialized
DEBUG - 2011-05-27 23:17:26 --> Router Class Initialized
ERROR - 2011-05-27 23:17:26 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:18:00 --> Config Class Initialized
DEBUG - 2011-05-27 23:18:00 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:18:00 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:18:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:18:00 --> URI Class Initialized
DEBUG - 2011-05-27 23:18:00 --> Router Class Initialized
DEBUG - 2011-05-27 23:18:00 --> Output Class Initialized
DEBUG - 2011-05-27 23:18:00 --> Security Class Initialized
DEBUG - 2011-05-27 23:18:00 --> Input Class Initialized
DEBUG - 2011-05-27 23:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 23:18:00 --> Language Class Initialized
DEBUG - 2011-05-27 23:18:00 --> Loader Class Initialized
DEBUG - 2011-05-27 23:18:00 --> Controller Class Initialized
DEBUG - 2011-05-27 23:18:00 --> Final output sent to browser
DEBUG - 2011-05-27 23:18:00 --> Total execution time: 0.2342
DEBUG - 2011-05-27 23:18:00 --> Config Class Initialized
DEBUG - 2011-05-27 23:18:00 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:18:00 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:18:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:18:00 --> URI Class Initialized
DEBUG - 2011-05-27 23:18:00 --> Router Class Initialized
ERROR - 2011-05-27 23:18:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-27 23:18:30 --> Config Class Initialized
DEBUG - 2011-05-27 23:18:30 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:18:30 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:18:30 --> URI Class Initialized
DEBUG - 2011-05-27 23:18:30 --> Router Class Initialized
DEBUG - 2011-05-27 23:18:30 --> Output Class Initialized
DEBUG - 2011-05-27 23:18:30 --> Security Class Initialized
DEBUG - 2011-05-27 23:18:30 --> Input Class Initialized
DEBUG - 2011-05-27 23:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-27 23:18:30 --> Language Class Initialized
DEBUG - 2011-05-27 23:18:31 --> Loader Class Initialized
DEBUG - 2011-05-27 23:18:31 --> Controller Class Initialized
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_ID - assumed 'MENU_ID' C:\work_php\ci202\application\controllers\board.php 10
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_NAME - assumed 'MENU_NAME' C:\work_php\ci202\application\controllers\board.php 11
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_NAME_EN - assumed 'MENU_NAME_EN' C:\work_php\ci202\application\controllers\board.php 12
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_DETAIL_XML - assumed 'MENU_DETAIL_XML' C:\work_php\ci202\application\controllers\board.php 13
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_PLUGIN_NO - assumed 'MENU_PLUGIN_NO' C:\work_php\ci202\application\controllers\board.php 14
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_NO - assumed 'MENU_SKIN_NO' C:\work_php\ci202\application\controllers\board.php 15
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_NAME - assumed 'MENU_BOARD_NAME' C:\work_php\ci202\application\controllers\board.php 16
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_NAME_EN - assumed 'MENU_BOARD_NAME_EN' C:\work_php\ci202\application\controllers\board.php 17
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_PERM - assumed 'MENU_BOARD_PERM' C:\work_php\ci202\application\controllers\board.php 18
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_DETAIL_SETTING - assumed 'MENU_BOARD_DETAIL_SETTING' C:\work_php\ci202\application\controllers\board.php 19
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_TYPE - assumed 'MENU_CONNECT_TYPE' C:\work_php\ci202\application\controllers\board.php 20
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_TYPE_CONTENTS - assumed 'MENU_CONNECT_TYPE_CONTENTS' C:\work_php\ci202\application\controllers\board.php 21
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_HTML - assumed 'MENU_CONNECT_HTML' C:\work_php\ci202\application\controllers\board.php 22
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_PLUGIN_NO - assumed 'MENU_CONNECT_PLUGIN_NO' C:\work_php\ci202\application\controllers\board.php 23
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_BOARD_NO - assumed 'MENU_CONNECT_BOARD_NO' C:\work_php\ci202\application\controllers\board.php 24
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_LAYOUT_TYPE - assumed 'MENU_CONNECT_LAYOUT_TYPE' C:\work_php\ci202\application\controllers\board.php 25
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_PERMISSION - assumed 'MENU_PERMISSION' C:\work_php\ci202\application\controllers\board.php 26
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_NAME - assumed 'MENU_MODULE_NAME' C:\work_php\ci202\application\controllers\board.php 27
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_TYPE - assumed 'MENU_MODULE_TYPE' C:\work_php\ci202\application\controllers\board.php 28
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_DIRECTORY - assumed 'MENU_MODULE_DIRECTORY' C:\work_php\ci202\application\controllers\board.php 29
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_DEFAULT_SKIN_NO - assumed 'MENU_DEFAULT_SKIN_NO' C:\work_php\ci202\application\controllers\board.php 30
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_DIRECTORY - assumed 'MENU_SKIN_DIRECTORY' C:\work_php\ci202\application\controllers\board.php 31
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_OPTIONS - assumed 'MENU_SKIN_OPTIONS' C:\work_php\ci202\application\controllers\board.php 32
ERROR - 2011-05-27 23:18:31 --> Severity: Notice  --> Use of undefined constant MENU_PARENT_NAME_EN - assumed 'MENU_PARENT_NAME_EN' C:\work_php\ci202\application\controllers\board.php 33
DEBUG - 2011-05-27 23:18:31 --> Final output sent to browser
DEBUG - 2011-05-27 23:18:31 --> Total execution time: 0.2460
DEBUG - 2011-05-27 23:18:31 --> Config Class Initialized
DEBUG - 2011-05-27 23:18:31 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:18:31 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:18:31 --> URI Class Initialized
DEBUG - 2011-05-27 23:18:31 --> Router Class Initialized
ERROR - 2011-05-27 23:18:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-27 23:19:13 --> Config Class Initialized
DEBUG - 2011-05-27 23:19:13 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:19:13 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:19:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:19:13 --> URI Class Initialized
DEBUG - 2011-05-27 23:19:13 --> Router Class Initialized
ERROR - 2011-05-27 23:19:13 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:19:13 --> Config Class Initialized
DEBUG - 2011-05-27 23:19:13 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:19:13 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:19:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:19:13 --> URI Class Initialized
DEBUG - 2011-05-27 23:19:13 --> Router Class Initialized
ERROR - 2011-05-27 23:19:13 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:19:13 --> Config Class Initialized
DEBUG - 2011-05-27 23:19:13 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:19:13 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:19:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:19:13 --> URI Class Initialized
DEBUG - 2011-05-27 23:19:13 --> Router Class Initialized
ERROR - 2011-05-27 23:19:13 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:19:38 --> Config Class Initialized
DEBUG - 2011-05-27 23:19:38 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:19:38 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:19:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:19:38 --> URI Class Initialized
DEBUG - 2011-05-27 23:19:38 --> Router Class Initialized
ERROR - 2011-05-27 23:19:38 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:20:32 --> Config Class Initialized
DEBUG - 2011-05-27 23:20:32 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:20:32 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:20:32 --> URI Class Initialized
DEBUG - 2011-05-27 23:20:32 --> Router Class Initialized
ERROR - 2011-05-27 23:20:32 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:20:32 --> Config Class Initialized
DEBUG - 2011-05-27 23:20:32 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:20:32 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:20:32 --> URI Class Initialized
DEBUG - 2011-05-27 23:20:32 --> Router Class Initialized
ERROR - 2011-05-27 23:20:32 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:20:43 --> Config Class Initialized
DEBUG - 2011-05-27 23:20:43 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:20:43 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:20:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:20:43 --> URI Class Initialized
DEBUG - 2011-05-27 23:20:43 --> Router Class Initialized
ERROR - 2011-05-27 23:20:43 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:20:44 --> Config Class Initialized
DEBUG - 2011-05-27 23:20:44 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:20:44 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:20:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:20:44 --> URI Class Initialized
DEBUG - 2011-05-27 23:20:44 --> Router Class Initialized
ERROR - 2011-05-27 23:20:44 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:20:44 --> Config Class Initialized
DEBUG - 2011-05-27 23:20:44 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:20:44 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:20:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:20:44 --> URI Class Initialized
DEBUG - 2011-05-27 23:20:44 --> Router Class Initialized
ERROR - 2011-05-27 23:20:44 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:20:44 --> Config Class Initialized
DEBUG - 2011-05-27 23:20:44 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:20:44 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:20:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:20:44 --> URI Class Initialized
DEBUG - 2011-05-27 23:20:44 --> Router Class Initialized
ERROR - 2011-05-27 23:20:44 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:21:13 --> Config Class Initialized
DEBUG - 2011-05-27 23:21:13 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:21:13 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:21:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:21:13 --> URI Class Initialized
DEBUG - 2011-05-27 23:21:13 --> Router Class Initialized
ERROR - 2011-05-27 23:21:13 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:21:13 --> Config Class Initialized
DEBUG - 2011-05-27 23:21:13 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:21:13 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:21:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:21:13 --> URI Class Initialized
DEBUG - 2011-05-27 23:21:13 --> Router Class Initialized
ERROR - 2011-05-27 23:21:13 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:21:17 --> Config Class Initialized
DEBUG - 2011-05-27 23:21:17 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:21:17 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:21:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:21:17 --> URI Class Initialized
DEBUG - 2011-05-27 23:21:17 --> Router Class Initialized
ERROR - 2011-05-27 23:21:17 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-27 23:22:19 --> Config Class Initialized
DEBUG - 2011-05-27 23:22:19 --> Hooks Class Initialized
DEBUG - 2011-05-27 23:22:19 --> Utf8 Class Initialized
DEBUG - 2011-05-27 23:22:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-27 23:22:19 --> URI Class Initialized
DEBUG - 2011-05-27 23:22:19 --> Router Class Initialized
ERROR - 2011-05-27 23:22:19 --> 404 Page Not Found --> wpad.dat
