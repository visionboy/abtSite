<?php
function read() {
	/**
	* url(segment(1), segment(2))과 매칭되는 menu 설정값 상수로 선언.
	*/
	$CI =& get_instance();

	if ($CI->uri->segment(1) == 'board') {

		$xmlfile = "data/menu_config.xml";
		$xml = @simplexml_load_file($xmlfile);
		if($xml) {

			foreach($xPath = $xml->xpath("//menu") as $item) {
				$row = simplexml_load_string($item->asXML());
				$query="//name_en[.='".$CI->uri->segment(2)."']/parent::*";
				$v = $row->xpath($query);
				if($v[0]){
					$m_name = unserialize($item->detail_xml);

					define('MENU_ID', $item->id);
					define('MENU_NAME', $item->name);
					define('MENU_NAME_EN', $item->name_en);
					define('MENU_DETAIL_XML', $item->detail_xml);
					define('MENU_PLUGIN_NO', $item->connect_plugin_no);
					define('MENU_SKIN_NO', $item->skin_no);
					define('MENU_BOARD_NAME', $item->board_name);
					define('MENU_BOARD_NAME_EN', $item->board_name_en);
					define('MENU_BOARD_PERM', $item->board_perm);
					define('MENU_CATEGORY_WORD', $item->category_word);
                    define('MENU_TOP_USE', $item->top_use);
                    define('MENU_BOTTOM_USE', $item->bottom_use);
					define('MENU_HEADER_HTML', $item->header_html);
					define('MENU_FOOTER_HTML', $item->footer_html);
					define('MENU_HEADER', $item->header);
					define('MENU_FOOTER', $item->footer);
					define('MENU_DETAIL_SETTING', $item->detail_setting);
					define('MENU_BOARD_DETAIL_SETTING', $item->board_detail_setting);
					define('MENU_LOAD_CONFIG', $item->load_config);
					define('MENU_CONNECT_TYPE', $item->connect_type);
					define('MENU_CONNECT_TYPE_CONTENTS', $item->connect_type_contents);
					define('MENU_CONNECT_HTML', $item->connect_html);
					define('MENU_CONNECT_LINK', $item->connect_link);
					define('MENU_CONNECT_PLUGIN_NO', $item->connect_plugin_no);
					define('MENU_CONNECT_BOARD_NO', $item->connect_board_no);
					define('MENU_CONNECT_LAYOUT_TYPE', $item->connect_layout_type);
					define('MENU_CONNECT_LAYOUT', $item->connect_layout);
					define('MENU_PERMISSION', $item->permission);
					define('MENU_MODULE_NAME', $item->module_name);
					define('MENU_MODULE_NAME_EN', $m_name['controller_name']);
					define('MENU_MODULE_TYPE', $item->module_type);
					define('MENU_MODULE_DIRECTORY', $item->module_directory);
					define('MENU_DEFAULT_SKIN_NO', $item->default_skin_no);
					define('MENU_SKIN_DIRECTORY', $item->skin_directory);
					define('MENU_SKIN_OPTIONS', $item->skin_options);
                    define('MENU_PLUGIN_SKIN_DIRECTORY', $item->p_skin_directory);
					define('MENU_PLUGIN_SKIN_OPTIONS', $item->p_skin_options);
					define('MENU_PARENT_NAME_EN', $item->parent_name_en);
				}
			}
		}
	}
}

?>