<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Board extends CI_Controller {

	public function index()
	{
		echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
		//Hook에서 선언한 게시판용 상수

		echo "MENU_ID : ".MENU_ID."<br><br>";
		echo "MENU_NAME : ".MENU_NAME."<br><br>";
		echo "MENU_NAME_EN : ".MENU_NAME_EN."<br><br>";
		echo "MENU_DETAIL_XML : ".MENU_DETAIL_XML."<br><br>";
		echo "MENU_PLUGIN_NO : ".MENU_PLUGIN_NO."<br><br>";
		echo "MENU_SKIN_NO : ".MENU_SKIN_NO."<br><br>";
		echo "MENU_BOARD_NAME : ".MENU_BOARD_NAME."<br><br>";
		echo "MENU_BOARD_NAME_EN : ".MENU_BOARD_NAME_EN."<br><br>";
		echo "MENU_BOARD_PERM : ".MENU_BOARD_PERM."<br><br>";
		echo "MENU_BOARD_DETAIL_SETTING : ".MENU_BOARD_DETAIL_SETTING."<br><br>";
		echo "MENU_CONNECT_TYPE : ".MENU_CONNECT_TYPE."<br><br>";
		echo "MENU_CONNECT_TYPE_CONTENTS : ".MENU_CONNECT_TYPE_CONTENTS."<br><br>";
		echo "MENU_CONNECT_HTML : ".MENU_CONNECT_HTML."<br><br>";
		echo "MENU_CONNECT_PLUGIN_NO : ".MENU_CONNECT_PLUGIN_NO."<br><br>";
		echo "MENU_CONNECT_BOARD_NO : ".MENU_CONNECT_BOARD_NO."<br><br>";
		echo "MENU_CONNECT_LAYOUT_TYPE : ".MENU_CONNECT_LAYOUT_TYPE."<br><br>";
		echo "MENU_PERMISSION : ".MENU_PERMISSION."<br><br>";
		echo "MENU_MODULE_NAME : ".MENU_MODULE_NAME."<br><br>";
		echo "MENU_MODULE_TYPE : ".MENU_MODULE_TYPE."<br><br>";
		echo "MENU_MODULE_DIRECTORY : ".MENU_MODULE_DIRECTORY."<br><br>";
		echo "MENU_DEFAULT_SKIN_NO : ".MENU_DEFAULT_SKIN_NO."<br><br>";
		echo "MENU_SKIN_DIRECTORY : ".MENU_SKIN_DIRECTORY."<br><br>";
		echo "MENU_SKIN_OPTIONS : ".MENU_SKIN_OPTIONS."<br><br>";
		echo "MENU_PARENT_NAME_EN : ".MENU_PARENT_NAME_EN."<br><br>";

		if($this->uri->segment(3)) {
			echo "<BR><BR>한글값 : ".urldecode($this->uri->segment(3));
		}

	}
}