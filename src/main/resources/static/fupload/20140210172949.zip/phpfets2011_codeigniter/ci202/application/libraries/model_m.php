<?php
class Model_m extends CI_Model {

	function __construct() {
		parent::__construct();
	}

	function table_get($table) {

		//db에서 데이터 가져오기
		$this->db->order_by('board_idx', 'desc');
		$query = $this->db->get($table);

		$result = $query->result_array();

		return $result;
	}
}
?>