<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-28 00:11:46 --> Config Class Initialized
DEBUG - 2011-05-28 00:11:46 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:11:46 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:11:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:11:46 --> URI Class Initialized
DEBUG - 2011-05-28 00:11:46 --> Router Class Initialized
ERROR - 2011-05-28 00:11:46 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:25:25 --> Config Class Initialized
DEBUG - 2011-05-28 00:25:25 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:25:25 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:25:25 --> Config Class Initialized
DEBUG - 2011-05-28 00:25:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:25:25 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:25:25 --> URI Class Initialized
DEBUG - 2011-05-28 00:25:25 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:25:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:25:25 --> Router Class Initialized
DEBUG - 2011-05-28 00:25:25 --> URI Class Initialized
ERROR - 2011-05-28 00:25:25 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:25:25 --> Router Class Initialized
ERROR - 2011-05-28 00:25:25 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:25:26 --> Config Class Initialized
DEBUG - 2011-05-28 00:25:26 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:25:26 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:25:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:25:26 --> URI Class Initialized
DEBUG - 2011-05-28 00:25:26 --> Router Class Initialized
ERROR - 2011-05-28 00:25:26 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:25:26 --> Config Class Initialized
DEBUG - 2011-05-28 00:25:26 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:25:26 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:25:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:25:26 --> URI Class Initialized
DEBUG - 2011-05-28 00:25:26 --> Router Class Initialized
ERROR - 2011-05-28 00:25:26 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:25:48 --> Config Class Initialized
DEBUG - 2011-05-28 00:25:48 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:25:48 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:25:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:25:49 --> URI Class Initialized
DEBUG - 2011-05-28 00:25:49 --> Router Class Initialized
ERROR - 2011-05-28 00:25:49 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:25:58 --> Config Class Initialized
DEBUG - 2011-05-28 00:25:58 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:25:58 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:25:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:25:58 --> URI Class Initialized
DEBUG - 2011-05-28 00:25:58 --> Router Class Initialized
ERROR - 2011-05-28 00:25:58 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:25:58 --> Config Class Initialized
DEBUG - 2011-05-28 00:25:58 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:25:58 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:25:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:25:58 --> URI Class Initialized
DEBUG - 2011-05-28 00:25:58 --> Router Class Initialized
ERROR - 2011-05-28 00:25:58 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:25:58 --> Config Class Initialized
DEBUG - 2011-05-28 00:25:58 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:25:58 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:25:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:25:58 --> URI Class Initialized
DEBUG - 2011-05-28 00:25:58 --> Router Class Initialized
ERROR - 2011-05-28 00:25:58 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:25:58 --> Config Class Initialized
DEBUG - 2011-05-28 00:25:58 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:25:58 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:25:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:25:58 --> URI Class Initialized
DEBUG - 2011-05-28 00:25:58 --> Router Class Initialized
ERROR - 2011-05-28 00:25:58 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:25:58 --> Config Class Initialized
DEBUG - 2011-05-28 00:25:58 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:25:59 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:25:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:25:59 --> URI Class Initialized
DEBUG - 2011-05-28 00:25:59 --> Router Class Initialized
ERROR - 2011-05-28 00:25:59 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:25:59 --> Config Class Initialized
DEBUG - 2011-05-28 00:25:59 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:25:59 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:25:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:25:59 --> URI Class Initialized
DEBUG - 2011-05-28 00:25:59 --> Router Class Initialized
ERROR - 2011-05-28 00:25:59 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:25:59 --> Config Class Initialized
DEBUG - 2011-05-28 00:25:59 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:25:59 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:25:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:25:59 --> URI Class Initialized
DEBUG - 2011-05-28 00:25:59 --> Router Class Initialized
ERROR - 2011-05-28 00:25:59 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:25:59 --> Config Class Initialized
DEBUG - 2011-05-28 00:25:59 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:25:59 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:25:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:25:59 --> URI Class Initialized
DEBUG - 2011-05-28 00:25:59 --> Router Class Initialized
ERROR - 2011-05-28 00:25:59 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:25:59 --> Config Class Initialized
DEBUG - 2011-05-28 00:25:59 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:25:59 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:25:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:25:59 --> URI Class Initialized
DEBUG - 2011-05-28 00:25:59 --> Router Class Initialized
ERROR - 2011-05-28 00:25:59 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:25:59 --> Config Class Initialized
DEBUG - 2011-05-28 00:25:59 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:25:59 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:25:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:25:59 --> URI Class Initialized
DEBUG - 2011-05-28 00:25:59 --> Router Class Initialized
ERROR - 2011-05-28 00:25:59 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:31:39 --> Config Class Initialized
DEBUG - 2011-05-28 00:31:39 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:31:39 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:31:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:31:39 --> URI Class Initialized
DEBUG - 2011-05-28 00:31:39 --> Router Class Initialized
ERROR - 2011-05-28 00:31:39 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:31:39 --> Config Class Initialized
DEBUG - 2011-05-28 00:31:39 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:31:39 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:31:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:31:39 --> URI Class Initialized
DEBUG - 2011-05-28 00:31:39 --> Router Class Initialized
ERROR - 2011-05-28 00:31:39 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:33:56 --> Config Class Initialized
DEBUG - 2011-05-28 00:33:56 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:33:56 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:33:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:33:56 --> URI Class Initialized
DEBUG - 2011-05-28 00:33:56 --> Router Class Initialized
ERROR - 2011-05-28 00:33:56 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:38:16 --> Config Class Initialized
DEBUG - 2011-05-28 00:38:16 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:38:16 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:38:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:38:16 --> URI Class Initialized
DEBUG - 2011-05-28 00:38:16 --> Router Class Initialized
ERROR - 2011-05-28 00:38:17 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 00:38:18 --> Config Class Initialized
DEBUG - 2011-05-28 00:38:18 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:38:18 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:38:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:38:18 --> URI Class Initialized
DEBUG - 2011-05-28 00:38:18 --> Router Class Initialized
DEBUG - 2011-05-28 00:38:18 --> Output Class Initialized
DEBUG - 2011-05-28 00:38:18 --> Security Class Initialized
DEBUG - 2011-05-28 00:38:18 --> Input Class Initialized
DEBUG - 2011-05-28 00:38:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 00:38:18 --> Language Class Initialized
DEBUG - 2011-05-28 00:38:18 --> Loader Class Initialized
DEBUG - 2011-05-28 00:38:18 --> Controller Class Initialized
DEBUG - 2011-05-28 00:38:19 --> Database Driver Class Initialized
DEBUG - 2011-05-28 00:38:19 --> Final output sent to browser
DEBUG - 2011-05-28 00:38:19 --> Total execution time: 0.1713
DEBUG - 2011-05-28 00:38:26 --> Config Class Initialized
DEBUG - 2011-05-28 00:38:26 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:38:26 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:38:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:38:26 --> URI Class Initialized
DEBUG - 2011-05-28 00:38:26 --> Router Class Initialized
DEBUG - 2011-05-28 00:38:26 --> Output Class Initialized
DEBUG - 2011-05-28 00:38:26 --> Security Class Initialized
DEBUG - 2011-05-28 00:38:26 --> Input Class Initialized
DEBUG - 2011-05-28 00:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 00:38:26 --> Language Class Initialized
DEBUG - 2011-05-28 00:38:26 --> Loader Class Initialized
DEBUG - 2011-05-28 00:38:26 --> Controller Class Initialized
DEBUG - 2011-05-28 00:38:26 --> Database Driver Class Initialized
DEBUG - 2011-05-28 00:38:26 --> Model Class Initialized
DEBUG - 2011-05-28 00:38:26 --> Model Class Initialized
DEBUG - 2011-05-28 00:38:26 --> File loaded: application/views/list_v.php
DEBUG - 2011-05-28 00:38:26 --> Final output sent to browser
DEBUG - 2011-05-28 00:38:26 --> Total execution time: 0.1558
DEBUG - 2011-05-28 00:59:05 --> Config Class Initialized
DEBUG - 2011-05-28 00:59:05 --> Hooks Class Initialized
DEBUG - 2011-05-28 00:59:05 --> Utf8 Class Initialized
DEBUG - 2011-05-28 00:59:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 00:59:05 --> URI Class Initialized
DEBUG - 2011-05-28 00:59:05 --> Router Class Initialized
DEBUG - 2011-05-28 00:59:05 --> Output Class Initialized
DEBUG - 2011-05-28 00:59:05 --> Security Class Initialized
DEBUG - 2011-05-28 00:59:05 --> Input Class Initialized
DEBUG - 2011-05-28 00:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 00:59:05 --> Language Class Initialized
DEBUG - 2011-05-28 00:59:05 --> Loader Class Initialized
DEBUG - 2011-05-28 00:59:05 --> Controller Class Initialized
DEBUG - 2011-05-28 00:59:05 --> Final output sent to browser
DEBUG - 2011-05-28 00:59:05 --> Total execution time: 0.1133
DEBUG - 2011-05-28 01:04:48 --> Config Class Initialized
DEBUG - 2011-05-28 01:04:48 --> Hooks Class Initialized
DEBUG - 2011-05-28 01:04:48 --> Utf8 Class Initialized
DEBUG - 2011-05-28 01:04:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 01:04:48 --> URI Class Initialized
DEBUG - 2011-05-28 01:04:48 --> Router Class Initialized
ERROR - 2011-05-28 01:04:48 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 01:11:46 --> Config Class Initialized
DEBUG - 2011-05-28 01:11:46 --> Hooks Class Initialized
DEBUG - 2011-05-28 01:11:46 --> Utf8 Class Initialized
DEBUG - 2011-05-28 01:11:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 01:11:46 --> URI Class Initialized
DEBUG - 2011-05-28 01:11:46 --> Router Class Initialized
ERROR - 2011-05-28 01:11:46 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 01:25:57 --> Config Class Initialized
DEBUG - 2011-05-28 01:25:57 --> Hooks Class Initialized
DEBUG - 2011-05-28 01:25:57 --> Utf8 Class Initialized
DEBUG - 2011-05-28 01:25:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 01:25:57 --> URI Class Initialized
DEBUG - 2011-05-28 01:25:57 --> Router Class Initialized
ERROR - 2011-05-28 01:25:57 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 01:26:28 --> Config Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Hooks Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Utf8 Class Initialized
DEBUG - 2011-05-28 01:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 01:26:28 --> URI Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Router Class Initialized
ERROR - 2011-05-28 01:26:28 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 01:26:28 --> Config Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Hooks Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Utf8 Class Initialized
DEBUG - 2011-05-28 01:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 01:26:28 --> URI Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Router Class Initialized
ERROR - 2011-05-28 01:26:28 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 01:26:28 --> Config Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Hooks Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Utf8 Class Initialized
DEBUG - 2011-05-28 01:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 01:26:28 --> URI Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Router Class Initialized
ERROR - 2011-05-28 01:26:28 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 01:26:28 --> Config Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Hooks Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Utf8 Class Initialized
DEBUG - 2011-05-28 01:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 01:26:28 --> URI Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Router Class Initialized
ERROR - 2011-05-28 01:26:28 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 01:26:28 --> Config Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Hooks Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Utf8 Class Initialized
DEBUG - 2011-05-28 01:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 01:26:28 --> URI Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Router Class Initialized
ERROR - 2011-05-28 01:26:28 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 01:26:28 --> Config Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Hooks Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Utf8 Class Initialized
DEBUG - 2011-05-28 01:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 01:26:28 --> URI Class Initialized
DEBUG - 2011-05-28 01:26:28 --> Router Class Initialized
ERROR - 2011-05-28 01:26:28 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 10:19:41 --> Config Class Initialized
DEBUG - 2011-05-28 10:19:41 --> Hooks Class Initialized
DEBUG - 2011-05-28 10:19:41 --> Utf8 Class Initialized
DEBUG - 2011-05-28 10:19:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 10:19:41 --> URI Class Initialized
DEBUG - 2011-05-28 10:19:41 --> Router Class Initialized
DEBUG - 2011-05-28 10:19:41 --> Output Class Initialized
DEBUG - 2011-05-28 10:19:41 --> Security Class Initialized
DEBUG - 2011-05-28 10:19:41 --> Input Class Initialized
DEBUG - 2011-05-28 10:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 10:19:41 --> Language Class Initialized
DEBUG - 2011-05-28 10:19:41 --> Loader Class Initialized
DEBUG - 2011-05-28 10:19:41 --> Controller Class Initialized
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_ID - assumed 'MENU_ID' C:\work_php\ci202\application\controllers\board.php 10
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_NAME - assumed 'MENU_NAME' C:\work_php\ci202\application\controllers\board.php 11
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_NAME_EN - assumed 'MENU_NAME_EN' C:\work_php\ci202\application\controllers\board.php 12
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_DETAIL_XML - assumed 'MENU_DETAIL_XML' C:\work_php\ci202\application\controllers\board.php 13
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_PLUGIN_NO - assumed 'MENU_PLUGIN_NO' C:\work_php\ci202\application\controllers\board.php 14
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_NO - assumed 'MENU_SKIN_NO' C:\work_php\ci202\application\controllers\board.php 15
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_NAME - assumed 'MENU_BOARD_NAME' C:\work_php\ci202\application\controllers\board.php 16
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_NAME_EN - assumed 'MENU_BOARD_NAME_EN' C:\work_php\ci202\application\controllers\board.php 17
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_PERM - assumed 'MENU_BOARD_PERM' C:\work_php\ci202\application\controllers\board.php 18
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_DETAIL_SETTING - assumed 'MENU_BOARD_DETAIL_SETTING' C:\work_php\ci202\application\controllers\board.php 19
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_TYPE - assumed 'MENU_CONNECT_TYPE' C:\work_php\ci202\application\controllers\board.php 20
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_TYPE_CONTENTS - assumed 'MENU_CONNECT_TYPE_CONTENTS' C:\work_php\ci202\application\controllers\board.php 21
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_HTML - assumed 'MENU_CONNECT_HTML' C:\work_php\ci202\application\controllers\board.php 22
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_PLUGIN_NO - assumed 'MENU_CONNECT_PLUGIN_NO' C:\work_php\ci202\application\controllers\board.php 23
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_BOARD_NO - assumed 'MENU_CONNECT_BOARD_NO' C:\work_php\ci202\application\controllers\board.php 24
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_LAYOUT_TYPE - assumed 'MENU_CONNECT_LAYOUT_TYPE' C:\work_php\ci202\application\controllers\board.php 25
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_PERMISSION - assumed 'MENU_PERMISSION' C:\work_php\ci202\application\controllers\board.php 26
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_NAME - assumed 'MENU_MODULE_NAME' C:\work_php\ci202\application\controllers\board.php 27
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_TYPE - assumed 'MENU_MODULE_TYPE' C:\work_php\ci202\application\controllers\board.php 28
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_DIRECTORY - assumed 'MENU_MODULE_DIRECTORY' C:\work_php\ci202\application\controllers\board.php 29
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_DEFAULT_SKIN_NO - assumed 'MENU_DEFAULT_SKIN_NO' C:\work_php\ci202\application\controllers\board.php 30
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_DIRECTORY - assumed 'MENU_SKIN_DIRECTORY' C:\work_php\ci202\application\controllers\board.php 31
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_OPTIONS - assumed 'MENU_SKIN_OPTIONS' C:\work_php\ci202\application\controllers\board.php 32
ERROR - 2011-05-28 10:19:41 --> Severity: Notice  --> Use of undefined constant MENU_PARENT_NAME_EN - assumed 'MENU_PARENT_NAME_EN' C:\work_php\ci202\application\controllers\board.php 33
DEBUG - 2011-05-28 10:19:41 --> Final output sent to browser
DEBUG - 2011-05-28 10:19:41 --> Total execution time: 0.3724
DEBUG - 2011-05-28 10:40:37 --> Config Class Initialized
DEBUG - 2011-05-28 10:40:37 --> Hooks Class Initialized
DEBUG - 2011-05-28 10:40:37 --> Utf8 Class Initialized
DEBUG - 2011-05-28 10:40:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 10:40:37 --> URI Class Initialized
DEBUG - 2011-05-28 10:40:37 --> Router Class Initialized
ERROR - 2011-05-28 10:40:37 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 10:41:03 --> Config Class Initialized
DEBUG - 2011-05-28 10:41:03 --> Hooks Class Initialized
DEBUG - 2011-05-28 10:41:03 --> Utf8 Class Initialized
DEBUG - 2011-05-28 10:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 10:41:03 --> URI Class Initialized
DEBUG - 2011-05-28 10:41:03 --> Router Class Initialized
ERROR - 2011-05-28 10:41:03 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 10:41:14 --> Config Class Initialized
DEBUG - 2011-05-28 10:41:14 --> Hooks Class Initialized
DEBUG - 2011-05-28 10:41:14 --> Utf8 Class Initialized
DEBUG - 2011-05-28 10:41:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 10:41:14 --> URI Class Initialized
DEBUG - 2011-05-28 10:41:14 --> Router Class Initialized
ERROR - 2011-05-28 10:41:14 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 10:41:34 --> Config Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Config Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Hooks Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Utf8 Class Initialized
DEBUG - 2011-05-28 10:41:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 10:41:34 --> URI Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Router Class Initialized
ERROR - 2011-05-28 10:41:34 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 10:41:34 --> Hooks Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Utf8 Class Initialized
DEBUG - 2011-05-28 10:41:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 10:41:34 --> URI Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Router Class Initialized
ERROR - 2011-05-28 10:41:34 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 10:41:34 --> Config Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Hooks Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Utf8 Class Initialized
DEBUG - 2011-05-28 10:41:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 10:41:34 --> URI Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Router Class Initialized
ERROR - 2011-05-28 10:41:34 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 10:41:34 --> Config Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Hooks Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Config Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Hooks Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Utf8 Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Config Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Utf8 Class Initialized
DEBUG - 2011-05-28 10:41:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 10:41:34 --> Config Class Initialized
DEBUG - 2011-05-28 10:41:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 10:41:34 --> URI Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Hooks Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Router Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Utf8 Class Initialized
DEBUG - 2011-05-28 10:41:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 10:41:34 --> URI Class Initialized
ERROR - 2011-05-28 10:41:34 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 10:41:34 --> Router Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Hooks Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Utf8 Class Initialized
DEBUG - 2011-05-28 10:41:34 --> UTF-8 Support Enabled
ERROR - 2011-05-28 10:41:34 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 10:41:34 --> URI Class Initialized
DEBUG - 2011-05-28 10:41:34 --> URI Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Router Class Initialized
DEBUG - 2011-05-28 10:41:34 --> Router Class Initialized
ERROR - 2011-05-28 10:41:34 --> 404 Page Not Found --> wpad.dat
ERROR - 2011-05-28 10:41:34 --> 404 Page Not Found --> wpad.dat
DEBUG - 2011-05-28 10:41:35 --> Config Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Hooks Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Utf8 Class Initialized
DEBUG - 2011-05-28 10:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 10:41:35 --> URI Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Router Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Output Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Security Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Input Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 10:41:35 --> Language Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Loader Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Controller Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Database Driver Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Config Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Hooks Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Utf8 Class Initialized
DEBUG - 2011-05-28 10:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 10:41:35 --> URI Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Model Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Router Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Output Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Security Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Input Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 10:41:35 --> Language Class Initialized
DEBUG - 2011-05-28 10:41:35 --> Model Class Initialized
DEBUG - 2011-05-28 10:41:35 --> File loaded: application/views/list_v.php
DEBUG - 2011-05-28 10:41:35 --> Final output sent to browser
DEBUG - 2011-05-28 10:41:35 --> Total execution time: 0.4596
DEBUG - 2011-05-28 10:41:36 --> Loader Class Initialized
DEBUG - 2011-05-28 10:41:36 --> Controller Class Initialized
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_ID - assumed 'MENU_ID' C:\work_php\ci202\application\controllers\board.php 10
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_NAME - assumed 'MENU_NAME' C:\work_php\ci202\application\controllers\board.php 11
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_NAME_EN - assumed 'MENU_NAME_EN' C:\work_php\ci202\application\controllers\board.php 12
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_DETAIL_XML - assumed 'MENU_DETAIL_XML' C:\work_php\ci202\application\controllers\board.php 13
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_PLUGIN_NO - assumed 'MENU_PLUGIN_NO' C:\work_php\ci202\application\controllers\board.php 14
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_NO - assumed 'MENU_SKIN_NO' C:\work_php\ci202\application\controllers\board.php 15
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_NAME - assumed 'MENU_BOARD_NAME' C:\work_php\ci202\application\controllers\board.php 16
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_NAME_EN - assumed 'MENU_BOARD_NAME_EN' C:\work_php\ci202\application\controllers\board.php 17
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_PERM - assumed 'MENU_BOARD_PERM' C:\work_php\ci202\application\controllers\board.php 18
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_BOARD_DETAIL_SETTING - assumed 'MENU_BOARD_DETAIL_SETTING' C:\work_php\ci202\application\controllers\board.php 19
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_TYPE - assumed 'MENU_CONNECT_TYPE' C:\work_php\ci202\application\controllers\board.php 20
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_TYPE_CONTENTS - assumed 'MENU_CONNECT_TYPE_CONTENTS' C:\work_php\ci202\application\controllers\board.php 21
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_HTML - assumed 'MENU_CONNECT_HTML' C:\work_php\ci202\application\controllers\board.php 22
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_PLUGIN_NO - assumed 'MENU_CONNECT_PLUGIN_NO' C:\work_php\ci202\application\controllers\board.php 23
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_BOARD_NO - assumed 'MENU_CONNECT_BOARD_NO' C:\work_php\ci202\application\controllers\board.php 24
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_CONNECT_LAYOUT_TYPE - assumed 'MENU_CONNECT_LAYOUT_TYPE' C:\work_php\ci202\application\controllers\board.php 25
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_PERMISSION - assumed 'MENU_PERMISSION' C:\work_php\ci202\application\controllers\board.php 26
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_NAME - assumed 'MENU_MODULE_NAME' C:\work_php\ci202\application\controllers\board.php 27
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_TYPE - assumed 'MENU_MODULE_TYPE' C:\work_php\ci202\application\controllers\board.php 28
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_MODULE_DIRECTORY - assumed 'MENU_MODULE_DIRECTORY' C:\work_php\ci202\application\controllers\board.php 29
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_DEFAULT_SKIN_NO - assumed 'MENU_DEFAULT_SKIN_NO' C:\work_php\ci202\application\controllers\board.php 30
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_DIRECTORY - assumed 'MENU_SKIN_DIRECTORY' C:\work_php\ci202\application\controllers\board.php 31
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_SKIN_OPTIONS - assumed 'MENU_SKIN_OPTIONS' C:\work_php\ci202\application\controllers\board.php 32
ERROR - 2011-05-28 10:41:36 --> Severity: Notice  --> Use of undefined constant MENU_PARENT_NAME_EN - assumed 'MENU_PARENT_NAME_EN' C:\work_php\ci202\application\controllers\board.php 33
DEBUG - 2011-05-28 10:41:36 --> Final output sent to browser
DEBUG - 2011-05-28 10:41:36 --> Total execution time: 0.4281
DEBUG - 2011-05-28 12:39:44 --> Config Class Initialized
DEBUG - 2011-05-28 12:39:44 --> Hooks Class Initialized
DEBUG - 2011-05-28 12:39:44 --> Utf8 Class Initialized
DEBUG - 2011-05-28 12:39:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 12:39:44 --> URI Class Initialized
DEBUG - 2011-05-28 12:39:44 --> Router Class Initialized
DEBUG - 2011-05-28 12:39:44 --> Output Class Initialized
DEBUG - 2011-05-28 12:39:44 --> Security Class Initialized
DEBUG - 2011-05-28 12:39:44 --> Input Class Initialized
DEBUG - 2011-05-28 12:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 12:39:44 --> Language Class Initialized
DEBUG - 2011-05-28 12:39:44 --> Loader Class Initialized
DEBUG - 2011-05-28 12:39:44 --> Controller Class Initialized
DEBUG - 2011-05-28 12:39:44 --> Database Driver Class Initialized
DEBUG - 2011-05-28 12:39:44 --> Model Class Initialized
DEBUG - 2011-05-28 12:39:44 --> Model Class Initialized
DEBUG - 2011-05-28 12:39:44 --> File loaded: application/views/list_v.php
DEBUG - 2011-05-28 12:39:44 --> Final output sent to browser
DEBUG - 2011-05-28 12:39:44 --> Total execution time: 0.3178
DEBUG - 2011-05-28 13:28:27 --> Config Class Initialized
DEBUG - 2011-05-28 13:28:27 --> Hooks Class Initialized
DEBUG - 2011-05-28 13:28:27 --> Utf8 Class Initialized
DEBUG - 2011-05-28 13:28:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 13:28:27 --> URI Class Initialized
DEBUG - 2011-05-28 13:28:27 --> Router Class Initialized
DEBUG - 2011-05-28 13:28:27 --> Output Class Initialized
DEBUG - 2011-05-28 13:28:27 --> Security Class Initialized
DEBUG - 2011-05-28 13:28:27 --> Input Class Initialized
DEBUG - 2011-05-28 13:28:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 13:28:27 --> Language Class Initialized
DEBUG - 2011-05-28 13:28:27 --> Loader Class Initialized
DEBUG - 2011-05-28 13:28:27 --> Controller Class Initialized
DEBUG - 2011-05-28 13:28:27 --> Database Driver Class Initialized
DEBUG - 2011-05-28 13:28:27 --> Final output sent to browser
DEBUG - 2011-05-28 13:28:27 --> Total execution time: 0.2928
DEBUG - 2011-05-28 13:32:48 --> Config Class Initialized
DEBUG - 2011-05-28 13:32:48 --> Hooks Class Initialized
DEBUG - 2011-05-28 13:32:48 --> Utf8 Class Initialized
DEBUG - 2011-05-28 13:32:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 13:32:48 --> URI Class Initialized
DEBUG - 2011-05-28 13:32:48 --> Router Class Initialized
DEBUG - 2011-05-28 13:32:48 --> Output Class Initialized
DEBUG - 2011-05-28 13:32:48 --> Security Class Initialized
DEBUG - 2011-05-28 13:32:48 --> Input Class Initialized
DEBUG - 2011-05-28 13:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 13:32:48 --> Language Class Initialized
DEBUG - 2011-05-28 13:32:48 --> Loader Class Initialized
DEBUG - 2011-05-28 13:32:48 --> Controller Class Initialized
DEBUG - 2011-05-28 13:32:48 --> Database Driver Class Initialized
DEBUG - 2011-05-28 13:32:48 --> Model Class Initialized
DEBUG - 2011-05-28 13:32:48 --> Model Class Initialized
DEBUG - 2011-05-28 13:32:48 --> File loaded: application/views/list_v.php
DEBUG - 2011-05-28 13:32:48 --> Final output sent to browser
DEBUG - 2011-05-28 13:32:48 --> Total execution time: 0.3346
DEBUG - 2011-05-28 14:03:02 --> Config Class Initialized
DEBUG - 2011-05-28 14:03:02 --> Hooks Class Initialized
DEBUG - 2011-05-28 14:03:02 --> Utf8 Class Initialized
DEBUG - 2011-05-28 14:03:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-28 14:03:02 --> URI Class Initialized
DEBUG - 2011-05-28 14:03:02 --> Router Class Initialized
DEBUG - 2011-05-28 14:03:02 --> Output Class Initialized
DEBUG - 2011-05-28 14:03:02 --> Security Class Initialized
DEBUG - 2011-05-28 14:03:02 --> Input Class Initialized
DEBUG - 2011-05-28 14:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-28 14:03:02 --> Language Class Initialized
DEBUG - 2011-05-28 14:03:02 --> Loader Class Initialized
DEBUG - 2011-05-28 14:03:02 --> Controller Class Initialized
DEBUG - 2011-05-28 14:03:02 --> Final output sent to browser
DEBUG - 2011-05-28 14:03:02 --> Total execution time: 0.2363
