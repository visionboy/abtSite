<?php
/* MySQL server에 접속 */
$link = mysqli_connect(
'localhost', /* The host to connect to */
'root', /* The user to connect as */
'apmsetup', /* The password to use */
'board'); /* The default table to query */

mysqli_query($link,"set names utf8");

if (!$link) {
printf("Can't connect to MySQL Server. Errorcode: %s\n", mysqli_connect_error());
exit;
}
/* 쿼리문을 서버에 보낸다 */
if ($result = mysqli_query($link, ' select * from su_admin ')) 
{
	while( $row = mysqli_fetch_assoc($result) )
	{
		printf("%s (%s)\n", $row['name'], $row['pw']);
	}
	mysqli_free_result($result);
}
/* 접속 닫기 */
mysqli_close($link);
?>
