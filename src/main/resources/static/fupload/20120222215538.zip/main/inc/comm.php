<?php
	date_Default_TimeZone_set("Asia/Seoul");	// 시간세팅
	define('ROOTPATH', dirname(__FILE__));		
	require('inc/smarty_config.php');			// 스마티 프램웍 연결고리
	require('inc/lib.php');						// 공통 사용자 function 모음
	//require('inc/sqlinjection.php');	
	extract($_POST);
	extract($_GET);

/*  데이타베이스 연결 설정 */
	$host	="localhost";							// 호스트
	$user	="root";								// 사용자
	$pwd	="apmsetup";							// 비밀번호
	$db	="board";							// Database name
	$my_db = new mysqli($host,$user,$pwd,$db);

	mysqli_query($my_db,"set names utf8");
	if ( mysqli_connect_errno() ) {
		echo mysqli_connect_error();
		exit;
	}
?>
