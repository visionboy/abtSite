<?php
	session_start();
	require('inc/comm.php');

	// html로부터 받은 값
	$mo = ($no) ? "o" : "";
	$smarty->assign("mo",$mo);
	
	

	// 삭제
	if ($no && $de=="o")
	{

		echo "삭제";
		$stmt = $my_db->prepare("delete from member where no = ? ");
		$stmt->bind_param("s", $no);
		$stmt->execute();

		printf("%d Row inserted.\n", $stmt->affected_rows);
		$stmt->close();
		$my_db->close();

		alert("삭제처리되었습니다.. ^^","mem_list.php");
	}

	if ($no)
	{
		$smarty->assign("no",$no);
		// 씸플 SELECT
		$rs = mysqli_query($my_db, " select id,pw,name,email from member where no = '$no' ");
		while($data = mysqli_fetch_array($rs)){
			$smarty->assign("id",$data['id']);
			$smarty->assign("pw",$data['pw']);
			$smarty->assign("name",$data['name']);
			$smarty->assign("email",$data['email']);
		}
	}

	

	if ($uname && $uid && $upwd && $uemail && $gmo=="o" && $gno)
	{
		echo "수정";
		$stmt = $my_db->prepare("update member set id = ? ,pw = ?,name = ?,email = ? where no = ? ");
		$stmt->bind_param("sssss", $uid,$upwd,$uname,$uemail,$gno);
		/* 미리준비된 문장 실행하기 */
		$stmt->execute();

		printf("%d Row inserted.\n", $stmt->affected_rows);
		$stmt->close();
		$my_db->close();

		alert("회원정보가 수정되었습니다. ^^","mem_list.php");
	}
	elseif ($uname && $uid && $upwd && $uemail)
	{
		echo "입력";
// 입력
		$stmt = $my_db->prepare("INSERT INTO member (id,pw,name,email) VALUES (?, ?, ?, ?) ");
		$stmt->bind_param("ssss", $uid,$upwd,$uname,$uemail);
		/* 미리준비된 문장 실행하기 */
		$stmt->execute();

		printf("%d Row inserted.\n", $stmt->affected_rows);
		$stmt->close();
		$my_db->close();

		alert("회원가입되었습니다. ^^","mem_list.php");
		
	}
	


	$smarty->display('join.html');
?>