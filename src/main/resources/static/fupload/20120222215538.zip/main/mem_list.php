<?php
	session_start();
	require('inc/comm.php');

	// 씸플 SELECT
	$rs = mysqli_query($my_db, " select no,id,pw,name,email from member ");
	while($data = mysqli_fetch_array($rs)){
	// echo "아이디:".$data['id']." 비밀번호:".$data['id']." 이름:".$data['name']." 이메일:".$data['email']."<br>";

	 $array[]= array("no"=>$data['no'],"id"=>$data['id'],"name"=>$data['name'],"email"=>$data['email']);
	 $smarty->assign("mem_list",$array);
	}
	
//	$albert = array("멍청아","테스트");
//	echo $albert[0].$albert[1];

	$smarty->display('mem_list.html');
?>