<?php
	session_start();
	require('inc/common.php');
	echo $_SESSION["uid"];
	if (trim($_SESSION["uid"]))
	echo "<script>location.href='../main/board.php';</script>";
	if ($user_id && $pw)
	{
		$getpwd=substr(md5($pw),8,16);
		$mbsql = "select id,name from su_admin where id = ? and pw = ? ";

		$stmt = $mysqli->prepare($mbsql);
		$stmt->bind_param('id', $user_id, "pw" ,$pw);


		/* execute prepared statement */
//		$resualt = $stmt->execute();

		$cnt=$DB->num_rows($mysqli->query($mbsql));
		
		echo $cnt;



//		$cnt=$DB->num_rows($DB->query($mbsql));

		if ($cnt == 1)
		{
			include 'inc/treutf8.php';
			$result=$DB->query($mbsql);
			$_SESSION["uid"] = $user_id;
			while($row = mysql_fetch_row($result))
			{
				$_SESSION["uname"] = $row[1];
			}

			echo "<script>location.href='board.php';</script>";
		}
		else
		{
		//	alert('정확한 정보를 입력하여주세요!');
		}
	}
	$smarty->display('login.html');
?>
