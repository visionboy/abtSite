<?php /* Smarty version 2.6.26, created on 2012-02-22 20:26:31
         compiled from mem_list.html */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko" lang="ko">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<title> 회원가입 </title>
</head>

<body>
<table border="1" width="100%">
<thead>
<tr>
	<th>번호</th>
	<th>아이디</th>
	<th>이름</th>
	<th>이메일</th>
</tr>
</thead>
<tbody>
<?php unset($this->_sections['memlist']);
$this->_sections['memlist']['name'] = 'memlist';
$this->_sections['memlist']['loop'] = is_array($_loop=$this->_tpl_vars['mem_list']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['memlist']['show'] = true;
$this->_sections['memlist']['max'] = $this->_sections['memlist']['loop'];
$this->_sections['memlist']['step'] = 1;
$this->_sections['memlist']['start'] = $this->_sections['memlist']['step'] > 0 ? 0 : $this->_sections['memlist']['loop']-1;
if ($this->_sections['memlist']['show']) {
    $this->_sections['memlist']['total'] = $this->_sections['memlist']['loop'];
    if ($this->_sections['memlist']['total'] == 0)
        $this->_sections['memlist']['show'] = false;
} else
    $this->_sections['memlist']['total'] = 0;
if ($this->_sections['memlist']['show']):

            for ($this->_sections['memlist']['index'] = $this->_sections['memlist']['start'], $this->_sections['memlist']['iteration'] = 1;
                 $this->_sections['memlist']['iteration'] <= $this->_sections['memlist']['total'];
                 $this->_sections['memlist']['index'] += $this->_sections['memlist']['step'], $this->_sections['memlist']['iteration']++):
$this->_sections['memlist']['rownum'] = $this->_sections['memlist']['iteration'];
$this->_sections['memlist']['index_prev'] = $this->_sections['memlist']['index'] - $this->_sections['memlist']['step'];
$this->_sections['memlist']['index_next'] = $this->_sections['memlist']['index'] + $this->_sections['memlist']['step'];
$this->_sections['memlist']['first']      = ($this->_sections['memlist']['iteration'] == 1);
$this->_sections['memlist']['last']       = ($this->_sections['memlist']['iteration'] == $this->_sections['memlist']['total']);
?>
<tr>
	<td>4</td>
	<td><a href="join.php?no=<?php echo $this->_tpl_vars['mem_list'][$this->_sections['memlist']['index']]['no']; ?>
"><?php echo $this->_tpl_vars['mem_list'][$this->_sections['memlist']['index']]['id']; ?>
</a></td>
	<td><?php echo $this->_tpl_vars['mem_list'][$this->_sections['memlist']['index']]['name']; ?>
</td>
	<td><?php echo $this->_tpl_vars['mem_list'][$this->_sections['memlist']['index']]['email']; ?>
</td>
	
</tr>
<?php endfor; endif; ?>
</tbody>
</table>
<a href="join.php">회원추가</a>
</body>
</html>