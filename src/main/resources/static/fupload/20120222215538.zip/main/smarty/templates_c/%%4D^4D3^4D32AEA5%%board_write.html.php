<?php /* Smarty version 2.6.26, created on 2012-02-22 21:41:38
         compiled from board_write.html */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="ko">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=7">
<title> 글쓰기 </title>
<link rel="stylesheet" type="text/css" href="css/layout.css">
</head>

<body>
<div id="wrap">

	<div id="header">
		상단영역
	</div><!-- //header -->

	<div id="container">

		<div id="sidebar">
			<h2>Title</h2>
		</div><!-- //sidebar -->

		<div id="content">
			<div id="location">
				HOME &gt; 경로 &gt; 해당페이지
			</div><!-- //location -->

			<h2>Tilte</h2>

<!-- 글쓰기부분 -->
<form name="frm" action="board.html">

<table cellpadding="0" cellspacing="0" border="1" summary="작성자,날짜,파일,내용의 정보를 입력하는 표입니다." class="bbswrite">
<caption>글쓰기</caption>
<thead>
	<tr class="first">
		<th scope="row" style="width:10%"><span>작성자 : </span></th>
		<td style="width:90%">
			<label for="author" class="hidden">작성자입력</label>
			<input type="text" name="uname" id="author" class="inp" style="width:100%">
		</td>
	</tr>
	<tr>
		<th scope="row"><span>이름 : </span></th>
		<td>
			<label for="author" class="hidden">이름입력</label>
			<input type="text" name="uname" id="author" class="inp" style="width:140px">
		</td>
	</tr>
	<tr class="last">
		<th scope="row"><span>첨부파일 : </span></th>
		<td>
			<label for="file" class="hidden">파일등록</label>
			<input type="file" name="file" id="file" class="inp" style="width:100%">
		</td>
	</tr>
	<tr class="subject">
		<td colspan="2">
			<label for="content1" class="hidden">내용입력</label>
			<textarea name="content1" id="content1" cols="70" rows="9" style="width:100%;height:300px"></textarea>
		</td>
	</tr>
</tbody>
</table>

<!-- 버튼 -->
<div class="bbsbtn" style="text-align:center">
	<input type="image" src="images/common/btn/btn_confirm.gif" alt="등록">
	<a href="board.html"><img src="images/common/btn/btn_cancel.gif" alt="취소"></a>
</div>

</form>

		</div><!-- //content -->
	</div><!-- //container -->

	<div id="footer">
		하단영역
	</div><!-- //footer -->

</div><!-- //wrap -->
</body>
</html>