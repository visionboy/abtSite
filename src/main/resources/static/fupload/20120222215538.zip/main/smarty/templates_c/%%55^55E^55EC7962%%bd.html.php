<?php /* Smarty version 2.6.26, created on 2012-01-05 09:00:10
         compiled from bd.html */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/header.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<!-- 리스트부분 -->
<table cellpadding="0" cellspacing="0" border="0" summary="번호,제목,작성자,날짜의 정보를 보여주는 표입니다." class="bbslist">
<caption>리스트</caption>
<thead>
	<tr>
		<th scope="col" class="first" style="width:10%"><span>번호</span></th>
		<th scope="col" style="width:40%"><span>제목</span></th>
		<th scope="col" style="width:10%"><span>작성자</span></th>
		<th scope="col" class="last" style="width:10%"><span>날짜</span></th>
	</tr>
</thead>
<tbody>
	<!-- 내용이 없을때 -->
	<?php if ($this->_tpl_vars['totalnum'] == 0): ?>
	<tr>
		<td colspan="4" class="text_c" >등록된 글이 없습니다.</td>
	</tr>
	<?php else: ?>
	<!-- 내용이 있을때 -->
	<?php unset($this->_sections['loop']);
$this->_sections['loop']['name'] = 'loop';
$this->_sections['loop']['loop'] = is_array($_loop=$this->_tpl_vars['rsc_list']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['loop']['show'] = true;
$this->_sections['loop']['max'] = $this->_sections['loop']['loop'];
$this->_sections['loop']['step'] = 1;
$this->_sections['loop']['start'] = $this->_sections['loop']['step'] > 0 ? 0 : $this->_sections['loop']['loop']-1;
if ($this->_sections['loop']['show']) {
    $this->_sections['loop']['total'] = $this->_sections['loop']['loop'];
    if ($this->_sections['loop']['total'] == 0)
        $this->_sections['loop']['show'] = false;
} else
    $this->_sections['loop']['total'] = 0;
if ($this->_sections['loop']['show']):

            for ($this->_sections['loop']['index'] = $this->_sections['loop']['start'], $this->_sections['loop']['iteration'] = 1;
                 $this->_sections['loop']['iteration'] <= $this->_sections['loop']['total'];
                 $this->_sections['loop']['index'] += $this->_sections['loop']['step'], $this->_sections['loop']['iteration']++):
$this->_sections['loop']['rownum'] = $this->_sections['loop']['iteration'];
$this->_sections['loop']['index_prev'] = $this->_sections['loop']['index'] - $this->_sections['loop']['step'];
$this->_sections['loop']['index_next'] = $this->_sections['loop']['index'] + $this->_sections['loop']['step'];
$this->_sections['loop']['first']      = ($this->_sections['loop']['iteration'] == 1);
$this->_sections['loop']['last']       = ($this->_sections['loop']['iteration'] == $this->_sections['loop']['total']);
?>
	<tr>
		<td><?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['noi']; ?>
</td>
		<td class="text_l"><a href="bd_view.php?no=<?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['no']; ?>
<?php echo $this->_tpl_vars['urlpage']; ?>
"><?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['subject']; ?>
</a><?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['getnew']; ?>
</td>
		<td><?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['name']; ?>
</td>
		<td><?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['date']; ?>
</td>
	</tr>
	<?php endfor; endif; ?>
	<?php endif; ?>
</tbody>
</table>
<div class="paging"><?php echo $this->_tpl_vars['pagelist']; ?>
</div>

<!-- 버튼 -->
<?php if ($this->_tpl_vars['ckadm'] == 'o'): ?>
<?php endif; ?>
<div class="bbsbtn" style="text-align:right">
	<a href="bd_write.php?tb_id=<?php echo $this->_tpl_vars['tb_id']; ?>
"><img src="images/common/btn/btn_write.gif" alt="글쓰기"></a>
</div>

<!-- 검색부분 -->
<form name="schform"  action="bd.php"  method="post" onsubmit="return sc_submt()">
<div class="bbssearch">
	<label for="search" class="hidden">검색어 선택</label>
	<select id="search" name = "search">
		<option value="subject" <?php if ($this->_tpl_vars['search'] == 'subject'): ?>  selected="selected" <?php endif; ?>>SUBJECT</option>
		<option value="content" <?php if ($this->_tpl_vars['search'] == 'content'): ?>  selected="selected" <?php endif; ?>>CONTENT</option>
	</select>
	<label for="searinp" class="hidden">검색어 입력</label>
	<input type = "hidden" name="tb_id" value="<?php echo $this->_tpl_vars['tb_id']; ?>
">
	<input type="text" name="searinp" id="searinp" class="inp" style="width:50%" value="<?php echo $this->_tpl_vars['searinp']; ?>
">
	<input type="image" src="images/common/btn/btn_search.gif" alt="검색" >
</div><!-- //bbssearch -->
</form>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/footer.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>