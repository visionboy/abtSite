<?php
	session_start();
	require('inc/comm.php');

	// 씸플 SELECT
	$rs = mysqli_query($my_db, " SELECT a.no,a.subject,a.userid,date(a.pub_date) as newdate,b.name FROM board as a left join member as b on a.userid = b.id ");
	while($data = mysqli_fetch_array($rs)){

	 $array[]= array("no"=>$data['no'],"subject"=>$data['subject'],"newdate"=>$data['newdate'],"name"=>$data['name']);
	 $smarty->assign("board_list",$array);
	}
	
//	$albert = array("멍청아","테스트");
//	echo $albert[0].$albert[1];

	$smarty->display('board_list.html');
?>