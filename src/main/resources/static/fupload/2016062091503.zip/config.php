<?php

// database information
$dbname = "scormvars";
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "28246252";

?>