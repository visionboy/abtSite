  package ch08.simpleBean;

  /**
 * @author Administrator
 *
 */
public class SimpleBean {
 
    private String msgs ;
    private String name ;

    public String getMsg() {
      return msgs;
    }

    public String getMsgs() {
		return msgs;
	}  

	public void setMsgs(String msgs) {
		this.msgs = msgs;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setMsg(String msg) {
      this.msgs = msg;
    }
  }
