package com.example.mysite;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import org.apache.cordova.*;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.webkit.DownloadListener;
import android.os.Bundle;
import android.view.Menu;



public class MainActivity extends DroidGap {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.loadUrl("http://visionboy.me");
        appView.setDownloadListener(new DownloadListener(){
        	public void onDownloadStart(String url,String userAgent,String contentDisposition,String mimeType,long size) {
        		Intent viewIntent = new Intent(Intent.ACTION_VIEW);
        		viewIntent.setDataAndType(Uri.parse(url),mimeType);
        		try{
        			startActivity(viewIntent);
        		} 
        		catch(ActivityNotFoundException ex) {
        			Log.w("Your logtag","Mime������ ã���� �����ϴ�."+mimeType);
        		}
        	}
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
