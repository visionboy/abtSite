/** Automatically generated file. DO NOT MODIFY */
package whdghks913.tistory.examplepreference;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}