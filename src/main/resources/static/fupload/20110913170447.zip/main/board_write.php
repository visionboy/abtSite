<?php
	session_start();
	require('inc/common.php');
	$user_id = $_SESSION["uid"];
	$ckadm = (trim($user_id)!='admin') ? "x" : "o";
	$tb_id = (trim($tb_id)=='') ? "bd" : $tb_id;
	$smarty->assign("tb_id",$tb_id);


	if ($ckadm=='x') 
	alert('�����ڸ� �ش� �Խ��ǿ� ���� �ø��� �ֽ��ϴ�.','board.php');  
	if ($mo && $no)
	{
		$sql = "SELECT no, subject, content FROM inun_board WHERE no = '$no'";
		include 'inc/treuckr.php';
		$result=$DB->query($sql);
		while ($row=$DB->fetch_row($result))
			 {
				$smarty->assign("no",$row['no']);   
				$smarty->assign("subject",$row['subject']);  
				$smarty->assign("content",$row['content']);  
			 }
			$smarty->assign("eview",$array);
			$smarty->assign("mo",$mo);
			$smarty->assign("gno",$no);
	}
	elseif ($title && $content1 )
	{
		
		$csql = "select max(no)+1 as mx from inun_board";
		$resulta=$DB->query($csql);
		while ($row2=$DB->fetch_row($resulta))
		{
			$numcnt = $row2['mx'];
		}
		if(!$numcnt)
		{
			$numcnt = 1;
		}

		$ip= $_SERVER["REMOTE_ADDR"] ;

		$pub_date = date("Y-m-d G:i:s");

		$syear = substr($pub_date,0,4);
		$sdate = substr($pub_date,5,2);
		$sday = substr($pub_date,8,2);
		$sh = substr($pub_date,11,2);
		$sm = substr($pub_date,14,2);
		$smi = substr($pub_date,17,2);
		
		//���� ���ε� ����
		if ($ufile)
		{
		$type = $_FILES['ufile']['type'];
		$name = $_FILES['ufile']['name'];
		$pinfo=pathinfo($_FILES['ufile']["name"]);
		$ext = $pinfo[extension];
		$size = $_FILES['ufile']['size'];
		$error = $_FILES['ufile']['error'];
		$tmp_name = $_FILES['ufile']['tmp_name'];
		$targetname = $syear.$sdate.$sday.$sh.$sm.$smi.".".$ext;
		$upload_dir = "fupload/";

		uploadfile($type,$name,$ext,$size,$error,$tmp_name,$targetname,$upload_dir);
		}
		
		//���Ͼ��ε� ����

		if($mo)
		{
			if ($ufile)
			{
				$sql="update  inun_board set subject = '$title',content = '$content1',ip='$ip',last_edite_date = '$pub_date',imgname = '$name',imgname2='$targetname' where no='$gno'";
			}
			else
			{
				$sql="update  inun_board set subject = '$title',content = '$content1',ip='$ip',last_edite_date = '$pub_date' where no='$gno'";
			}
		}
		else
		{
			if ($ufile)
			{
				$sql="insert  inun_board (no,subject,content,hit,pub_date,writer_id,ip,comment,table_id,imgname,imgname2)
				values
				('$numcnt','$title','$content1',0,'$pub_date','$user_id','$ip',0,'$tb_id','$name','$targetname')";
			}
			else
			{
				$sql="insert  inun_board (no,subject,content,hit,pub_date,writer_id,ip,comment,table_id)
				values
				('$numcnt','$title','$content1',0,'$pub_date','$user_id','$ip',0,'$tb_id')";
			}
		}
		include 'inc/treuckr.php';
		$result=$DB->query($sql);
		
		$gurl = "board.php?tb_id=$tb_id";
		echo $gurl;
		alert('���ó�� �Ϸ�Ǿ����ϴ�.',$gurl);
	}
	$smarty->display('board_write.html');
?>
