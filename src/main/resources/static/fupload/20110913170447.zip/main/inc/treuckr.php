<?
		mysql_query("set names euckr");
		mysql_query("SET CHARACTER SET euckr");
		mysql_query("SET CHARACTER_SET_RESULTS=euckr");
?>