<?php session_start();?>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<?php
//session_unset;
session_destroy();
echo "<script>alert('�α׾ƿ��Ǿ����ϴ�.');location.href='slogin.php';</script>";
 ?>