<form method="post" action="test_ok.php">
<img src="auth_code.php"  style="border:1px solid #dddddd"/><br>
<input type=text name="authcode" size="15" maxlength="20"> <input type="submit" value="����">
</form>