<table>
<?
	$connect = mysql_connect("localhost","root","1234");
	mysql_select_db("chat",$connect);

	$sql = "SELECT * FROM messages order by message_id desc";

	$result = mysql_query($sql, $connect);

	while($row = mysql_fetch_array($result)){?>
		<tr><td><? echo($row[1]) ?></td>
		<td><? echo($row[2]) ?></td></tr>
<?	}
?>
</table>
