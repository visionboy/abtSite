<?
	session_start();
	
	$connect = mysql_connect("localhost","root","1234");
	mysql_select_db("chat",$connect);

	$sql = "INSERT INTO messages VALUES (null, '$_SESSION[user]', '$_POST[message]')";
	mysql_query($sql, $connect);
?>
<table>
<?
	$sql = "SELECT * FROM messages";
	$result = mysql_query($sql, $connect);

	while($row = mysql_fetch_array($result)){?>
		<tr><td><? echo($row[1]) ?></td>
		<td><? echo($row[2]) ?></td></tr>
<?	}
?>
</table>
