<?php /* Smarty version 2.6.26, created on 2012-01-05 09:00:14
         compiled from bd_write.html */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/header.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>


<!-- 글쓰기부분 -->
<form name="board_frm" action="bd_write.php" method="post" enctype="multipart/form-data" onsubmit="return board_post()">

<table cellpadding="0" cellspacing="0" border="1" summary="작성자,날짜,파일,내용의 정보를 입력하는 표입니다." class="bbswrite">
<caption>글쓰기</caption>
<tbody>
	<tr class="first">
		<th scope="row" style="width:10%"><span>제목 : </span></th>
		<td style="width:90%">
			<label for="title" class="hidden">제목입력</label>
			<input type="text" name="title" id="title" class="inp" style="width:100%" value="<?php echo $this->_tpl_vars['subject']; ?>
">
		</td>
	</tr>
<!--이름은 자동 로그인에 따라서 입력되는 원인으로인하여잠시 주석처리 되었습니다.-->
<!--
	<tr>
		<th scope="row"><span>이름 : </span></th>
		<td>
			<label for="author" class="hidden">이름입력</label>
			<input type="text" name="uname" id="author" class="inp" style="width:140px">
		</td>
	</tr>
-->
	<tr class="last">
		<th scope="row"><span>첨부파일 : </span></th>
		<td>
			<?php if ($this->_tpl_vars['imgname'] == 'n' || $this->_tpl_vars['imgname'] == ''): ?>
			<p>
			<label for="ufile" class="hidden">파일등록</label>
			<input type="file" name="ufile" id="ufile" class="inp" style="width:100%">
			</p>
			<?php else: ?>
			<p style="margin-top:10px"><img src="images/common/ico/ico_file.gif" alt="파일"> <?php echo $this->_tpl_vars['imgname']; ?>
 <a href="#del" onclick="de('<?php echo $this->_tpl_vars['lkdefile']; ?>
'); return false;">[삭제]</a></p>
			<?php endif; ?>
		</td>
	</tr>
	<tr class="subject">
		<td colspan="2">
			<label for="content1" class="hidden">내용입력</label>
			<textarea name="content1" id="content1" cols="70" rows="9" style="width:100%;height:300px;display:none"><?php echo $this->_tpl_vars['content']; ?>
</textarea>
			<input type="hidden" name="mo" value="<?php echo $this->_tpl_vars['mo']; ?>
">
			<input type="hidden" name="gno" value="<?php echo $this->_tpl_vars['gno']; ?>
">
			<input type="hidden" name="tb_id" value="<?php echo $this->_tpl_vars['tb_id']; ?>
">
		</td>
	</tr>
</tbody>
</table>

<!-- 버튼 -->
<div class="bbsbtn" style="text-align:center">
	<input type="image" src="images/common/btn/btn_confirm.gif" alt="등록">
	<a href="bd.php" ><img src="images/common/btn/btn_cancel.gif" alt="취소"></a>
</div>

</form>
<script type="text/javascript">
	var oEditors = [];
	nhn.husky.EZCreator.createInIFrame({
	oAppRef: oEditors,
	elPlaceHolder: "content1",
	sSkinURI: "SEditorSkin.html",
	fCreator: "createSEditorInIFrame"
	});

	function pasteHTMLDemo(){
		sHTML = "<span style='color:#ff0000'>이미지 등도 이렇게 삽입하면 됩니다.</span>";
		oEditors.getById["content1"].exec("PASTE_HTML", [sHTML]);
		}

	function showHTML(){
		alert(oEditors.getById["content1"].getIR());
		}

	function _onSubmit(elClicked){
		oEditors.getById["content1"].exec("UPDATE_IR_FIELD", []);
									
		// 에디터의 내용에 대한 값 검증은 이곳에서 document.getElementById("content1").value를 이용해서 처리하면 됩니다.

		try{
			elClicked.form.submit();
		}catch(e){}
	}
</script>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/footer.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>