<?php /* Smarty version 2.6.26, created on 2012-01-05 09:00:07
         compiled from inc/footer.html */ ?>
<div id="lgiwrap" style="display:none">
	<ol>
		<li>※ 아이디와 비밀번호를 입력하여 주세요. ^__^ </li>
	</ol>
	<div id="lgicontent">
		<form name="loginform"  method="post" action = "slogin.php" onsubmit="return login()">
			<ul>
				<li><label for="uid">아이디</label><span><input type="text" name="user_id" id="uid"></span></li>
				<li><label for="upw">비밀번호</label><span><input type="password" name="pw" onKeyDown="if (event.keyCode == 13) login();" id="upw"></span></li>
			</ul>
			<p><input type="image" src="images/common/btn/btn_alogin.png" alt="Login"></p>
		</form>
	<p style="margin:-82px 0px 0px 0px;height:20px;text-align:right"><a href="#close" id="close" onclick="return false;">닫기</a></p>
	</div><!-- //content -->
</div><!-- //wrap -->

</body>
</html>