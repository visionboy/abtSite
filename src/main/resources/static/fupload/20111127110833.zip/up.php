<?php 
//공통함수
function func_message($fdir, $maxsize, $cont){
	define('MUILTI_FILE_UPLOAD', $cont); //동시에 업로드할수있는 파일수
	define('MAX_SIZE_FILE_UPLOAD', $maxsize); //업로드 최대크기5MB
	define('FILE_UPLOAD_DIR', $fdir); //업로드할 파일경로
	//근지된 파일명
	$array_extention_interdite = array( '.php' , '.php3' , '.php4' , '.exe' , '.msi' , '.htaccess' , '.gz' ); //

	//업로드프로세스 처리부분
	$action = (isset($_POST['action'])) ? $_POST['action'] :'' ;
	$file = (isset($_POST['file'])) ? $_POST['file'] :''  ;
	if($file != '') {
		$file = $file.'/';
	}
	$message_true = '';
	$message_false = '';

	switch($action){
	case 'upload' :    
	//chmod(FILE_UPLOAD_DIR,0777);    
	for($nb = 1 ; $nb <= MUILTI_FILE_UPLOAD ; $nb ++ ){     
			if( $_FILES['file_'.$nb]['size'] >= 10 ){  
			  if ($_FILES['file_'.$nb]['size'] <= MAX_SIZE_FILE_UPLOAD ){ 
			if (!in_array(ereg_replace('^[[:alnum:]]([-_.]?[[:alnum:]])*\.' ,'.', $_FILES['file_'.$nb]['name'] ) , $array_extention_interdite) ){ 
			if($_POST['file_name_'.$nb] !=''){ 
				$file_name_final = $_POST['file_name_'.$nb].$extension ;
			}else {
				$file_name_final = $_FILES['file_'.$nb]['name'] ;
			}
			//파일의 수정부분
			$file_name_final = strtr($file_name_final, 'aaaaaa',                                               'AAAAAACEEEEIIIIOOOOOUUUUYaaaaaaceeeeiiiioooooouuuuyy'); 
			$file_name_final = preg_replace('/([^.a-z0-1]+)/i', '_', $file_name_final ); 
			
			$_FILES['file_'.$nb]['name'] = $file_name_final;        
			move_uploaded_file( $_FILES['file_'.$nb]['tmp_name'] , FILE_UPLOAD_DIR.$file . $file_name_final );

				$message_true .= '업로드된 파일 : '.$_FILES['file_'.$nb]['name'] .'<br>'; 
			}else{
				$message_false .= '업로드실패한 파일 : '.$_FILES['file_'.$nb]['name'] .' <br>'; 
			}
			}else{
				$message_false .= '최대업로드 파일을 초과하였습니다.'.MAX_SIZE_FILE_UPLOAD/1000 . 'KB : "                               '.$_FILES['file_'.$nb]['tmp_name'].'" <br>';}
			}
		}//end for
		break;
	}
}
	func_message("upload/", "500000", 3);
?>
<html>
 <head>
  <title> New Document </title>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
 </head>
<body>
<form name="form" enctype="multipart/form-data" method="post" action="<?php echo $_SERVER['PHP_SELF'] ; ?>">
<input type="hidden" name="action" value="upload">
<table  border="0" cellspacing="1" cellpadding="0" align="center" class="border">
<tr> 
<td>

<table width="100%" border="0" cellspacing="5" cellpadding="2" align="center" class="box">
<?php 
for($nb = 1 ; $nb <= MUILTI_FILE_UPLOAD ; $nb ++ ){  
?>
<tr class="text"> 
<td>업로드파일<?php echo $nb; ?>： </td> <td><input type="file" name="file_<?php echo $nb; ?>"></td>
<td></td>
</tr>
<?php } ?>
<tr> 
<td colspan="2" align="right" class="text">
</td>
<td colspan="2" align="right"><input type="submit" value="업로드"></td>
</tr>
</table>
</td>
</tr>
</table>
</form>    
</body>
</html>

