(function(exports) {
	var FtpUIFooter = function(opts) {
		_.extend(this, new MvvmUI(opts.id));
	}
	
	exports.FtpUIFooter = FtpUIFooter;
})(window);