<?php /* Smarty version 2.6.26, created on 2012-01-05 09:00:07
         compiled from inc/header.html */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="ko">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=7">
<title><?php echo $this->_tpl_vars['viewtitle']; ?>
 Welcome to albert board ^^ </title>
<meta name="keywords" content="<?php echo $this->_tpl_vars['viewtitle']; ?>
,visionboy,VISIONBOY,이성,리성,ALBERT,Abert,웹프로그래밍,웹표준,웹접근성,oracle" >
<meta name="description" content="이성(visionboy) 개인홈페이지 입니다." >
<link rel="stylesheet" type="text/css" href="css/layout.css">
<link rel="stylesheet" type="text/css" href="css/default.css">
<script type="text/javascript" src="js/comm.js" charset="utf-8"></script>
<script type="text/javascript" src="js/flashinside.js"></script>
<script type="text/javascript" src="js/jquery-1.4.min.js" charset="utf-8"></script>
<script type="text/javascript" src="js/HuskyEZCreator.js" charset="utf-8"></script>
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript">
$(document).ready(function(){
  $("#showbox").click(function(){
	document.getElementById('uid').value = "";
	document.getElementById('upw').value = "";
	$("#lgiwrap").css("display","block");
	document.getElementById('uid').focus();
  });

  $("#close").click(function(){
	$("#lgiwrap").css("display","none");
  });
});

function gNaviCtl(t) {
	var target = "sNavi0" + t;
	for(var i=1; i<=3; i++) {
		var a = "sNavi0" + i;
			if (document.getElementById(a) != null)
			{
				document.getElementById(a).style.display='none';
				document.getElementById('mNaviImg0'+i).src='images/gnb0'+i+'.png';
			}
		}
	document.getElementById(target).style.display='block';
	document.getElementById('mNaviImg0'+t).src='images/gnb0'+t+'_on.png';
}
</script>

<!--[if IE 6]>
<link rel="stylesheet" type="text/css" href="css/ie6.css">
<script type="text/javascript" src="js/DD_belatedPNG_0.0.7a-min.js"></script>
<script type="text/javascript">DD_belatedPNG.fix('body, h1, h2, h3, h4, h5, h6, div, p, ul, ol, dl, dt, dd, li, a, span, strong, img');</script>
<![endif]-->
<!--[if IE 7]><link rel="stylesheet" type="text/css" href="css/ie7.css"><![endif]-->
<!--[if IE 8]><link rel="stylesheet" type="text/css" href="css/ie8.css"><![endif]-->

</head>

<body>
<!--<a href="#back" onclick="hstry_back();return false;">이전</a>
<a href="#back" onclick="hstry_go();return false;">다음</a>-->
<!--
<div style="widht:100%;height:30px;text-align:left">
		<?php if ($this->_tpl_vars['ckadm'] == 'o'): ?>
		<a href="slogout.php">로그아웃</a>
		<?php else: ?>
		<a href="#login" id="showbox" onclick="return false;">로그인</a>
		<?php endif; ?>
</div>
-->