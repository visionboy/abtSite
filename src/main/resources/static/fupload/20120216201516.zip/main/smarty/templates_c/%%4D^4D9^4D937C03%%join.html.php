<?php /* Smarty version 2.6.26, created on 2012-02-01 21:05:15
         compiled from join.html */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko" lang="ko">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<title> 회원가입 </title>
</head>

<body>
<form name="frm" action="join.php" method="post">
<table border="1" width="100%">
<caption>회원가입</caption>
<tbody>
	<tr>
		<th scope="row" width="15%">이름</th>
		<td width="85%"><input type="text" name="uname" id="uname" /></td>
	</tr>
	<tr>
		<th scope="row">아이디</th>
		<td><input type="text" name="uid" id="uid" /></td>
	</tr>
	<tr>
		<th scope="row">비밀번호</th>
		<td><input type="password" name="upwd" id="upwd" /></td>
	</tr>
	<tr>
		<th scope="row">이메일</th>
		<td><input type="text" name="uemail" id="uemail" /></td>
	</tr>
	<tr>
		<th scope="row">연락처</th>
		<td><input type="text" name="utel" id="utel" /></td>
	</tr>
</tbody>
</table>
<div style="text-align:center">
	<input type="submit" value="등록" />
</div>
</form>
</body>
</html>