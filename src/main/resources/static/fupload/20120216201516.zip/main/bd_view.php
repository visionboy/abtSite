<?php
	session_start();
	require('inc/comm.php');

	$ckadm = $_SESSION["uid"];
	$ckadm = (trim($ckadm)!='admin') ? "x" : "o";
	$tb_id = (trim($tb_id)=='') ? "bd" : $tb_id;
	$smarty->assign("ckadm",$ckadm);
	$smarty->assign("tb_id",$tb_id);


	if ($no)
	{
		$url2 = "?no=".$no."&amp;page=".$page."&amp;tb_id=".$tb_id;
		$smarty->assign("url2",$url2);

// 조회수변경
		$stmt = $my_db->prepare("update su_board set hit = hit+1  where no = ? ");
		$stmt->bind_param("s", $no );
		$no = $no;

		/* 미리준비된 문장 실행하기 */
		$stmt->execute();
		$stmt->close();
		$noa = $no - 1;
		$nob = $no + 1;

// 내용출력
		$rs = mysqli_query($my_db, "select no,subject,content,hit,date(pub_date) as date,imgname,imgname2 from su_board where no = $no");
		while($data = mysqli_fetch_array($rs)){
			$fileox = ($data['imgname'] =='' || $data['imgname'] =='n') ? "x" : 'o'; //파일 있는지 없는지 확인

			$downurl = "fdown.php?nfile=".urlencode($data['imgname'])."&ofile=".$data['imgname2'];
			$content = str_replace("#","'",$data['content']);
			$array[]= array("no"=>$data['no'],"subject"=>$data['subject'],"content"=>$content,"hit"=>$data['hit'],"date"=>$data['date'],"noa"=>$noa,"nob"=>$nob,"imgname"=>$data['imgname'],"imgname2"=>$data['imgname2'],"nofile"=>$nofile,"ckadm"=>$ckadm,"fileox"=>$fileox,"downurl"=>$downurl);
			$smarty->assign("viewctt",$array);
			$viewtitle = $data['subject'];
		}

//	이전
		$rs2 = mysqli_query($my_db, "SELECT no,subject,pub_date as date FROM su_board WHERE no <$no and table_id = '$tb_id' and status ='o' ORDER BY no LIMIT 0 , 1 ");
		while($row2 = mysqli_fetch_array($rs2))
		{
			$smarty->assign("preno",$row2['no']);
			$smarty->assign("presubject",$row2['subject']);
			$smarty->assign("predate",$row2['date']);
		}

//	다음
		$rs3 = mysqli_query($my_db, "SELECT no,subject,pub_date as date FROM su_board WHERE no >$no and table_id = '$tb_id' and status ='o' ORDER BY no LIMIT 0 , 1 ");
		while($row3 = mysqli_fetch_array($rs3))
		{
			$smarty->assign("nextno",$row3['no']);
			$smarty->assign("nextsubject",$row3['subject']);
			$smarty->assign("nextdate",$row3['date']);
			$cknext = $row3['no'];
		}
// 페이지링크 만들기
		if ($page)
		{
			$urlpage = "&amp;page=".$page;
			$urllist = "?page=".$page."&amp;tb_id=".$tb_id;
			$smarty->assign("urlpage",$urlpage);
			$smarty->assign("urllist",$urllist);
		}
	}
	else
	{
		alert('열람할자격이 없습니다.','bd.php');
	}

	//삭제내역
	if( $no && $de)
	{
		// 삭제하기
		$stmt = $my_db->prepare("update su_board set status = 'x'  where no = ? and table_id = ? ");
		$stmt->bind_param("ss", $no,$tb_id );
		$no = $no;
		$tb_id = $tb_id;
		$stmt->execute();
		$stmt->close();

		$gourl = "bd.php?tb_id=$tb_id";
		goto_url($gourl);
	}
	

	/* 문장과 접속 닫기 */
	$smarty->assign("viewtitle",$viewtitle."visionboy이성");
	$smarty->display('bd_view.html');
?>
