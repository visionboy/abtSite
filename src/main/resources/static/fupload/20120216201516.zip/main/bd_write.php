<?php
	session_start();
	require('inc/comm.php');

	/* 기본설정부분 */
	$user_id = $_SESSION["uid"];
	$ckadm = (trim($user_id)!='admin') ? "x" : "o";
	$smarty->assign("ckadm",$ckadm);
	$tb_id = (trim($tb_id)=='') ? "bd" : $tb_id;
	$smarty->assign("tb_id",$tb_id);

	/* 입력 수정 프로세스부분 */
	if ($mo && $no)
	{
		$rs = mysqli_query($my_db, "SELECT no, subject, content,imgname,imgname2 FROM su_board WHERE no = '$no' ");
		while($data = mysqli_fetch_array($rs)){
			$filename = $data['imgname2'];
			$lkdefile = "bd_write.php?no=$no&page=$page&mo=o&defile=$filename";
			$alerturl = "bd_write.php?no=$no&page=$page&mo=o";
			$content = str_replace("#","'",$data['content']);
			$smarty->assign("no",$data['no']);   
			$smarty->assign("subject",$data['subject']);  
			$smarty->assign("content",$content);  
			$smarty->assign("lkdefile",$lkdefile);
			$smarty->assign("imgname",$data['imgname']);  
			$smarty->assign("imgname2",$data['imgname2']);
		}

		if ($defile && $alerturl)
		{
			$sql="update  su_board set imgname = 'n', imgname2 = 'n' where no = ? ";
			$stmt = $my_db->prepare($sql);
			$stmt->bind_param("s", $no);
			$stmt->execute();
			$stmt->close();
			unlink ( "fupload/".$defile);
			alert('해당파일이 정상적으로 삭제처리완료되었습니다.',$alerturl);
		}

		$smarty->assign("mo",$mo);
		$smarty->assign("gno",$no);
	}
	elseif ($title && $content1 )
	{
		$ip= $_SERVER["REMOTE_ADDR"] ;
		$pub_date = date("Y-m-d G:i:s");
		$tgname = date("YmdGis");
		
		/*파일 업로드 시작*/
		$ckfile = $_FILES['ufile']['name'];

		if ($ckfile)
		{
		$type = $_FILES['ufile']['type'];
		$rname = $_FILES['ufile']['name'];
		$rname = str_replace("'","",$rname);
		$rname = str_replace("\"","",$rname);

		$pinfo=pathinfo($_FILES['ufile']["name"]);
		$ext = $pinfo[extension];
		$size = $_FILES['ufile']['size'];
		$error = $_FILES['ufile']['error'];
		$tmp_name = $_FILES['ufile']['tmp_name'];
		$targetname = $tgname.".".$ext;
		$upload_dir = "fupload/";
		
		uploadfile($type,$rname,$ext,$size,$error,$tmp_name,$targetname,$upload_dir);
		}
		
		/*파일업로드 종료*/

		$content1 = str_replace("'","#",$content1);
		if($mo)
		{
			if ($ckfile)
			{
		//		$sql="update  su_board set subject = '$title',content = '$content1',ip='$ip',last_edite_date = '$pub_date',imgname = '$name',imgname2='$targetname' where no='$gno'";
				$sql="update  su_board set subject = ?,content = ?,ip= ?,last_edite_date = ?,imgname = ?,imgname2=? where no = ? ";
				$stmt = $my_db->prepare($sql);
				$stmt->bind_param("sssssss", $subject, $content, $ip, $pub_date,$rname,$targetname,$gno);
			}
			else
			{
		//		$sql="update  su_board set subject = '$title',content = '$content1',ip='$ip',last_edite_date = '$pub_date' where no='$gno'";
				$sql="update  su_board set subject = ?,content = ?,ip= ?,last_edite_date = ? where no = ? ";
				$stmt = $my_db->prepare($sql);
				$stmt->bind_param("sssss", $subject, $content, $ip, $pub_date,$gno);
			}
			$msg = "수정처리완료되었습니다.";
		}
		else
		{
			$sql = "INSERT INTO su_board (subject,content,pub_date,writer_id,ip,table_id,imgname,imgname2) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
			$stmt = $my_db->prepare($sql);
			$stmt->bind_param("ssssssss", $subject, $content,$pub_date,$writer_id,$ip,$table_id,$rname,$targetname);
			$gurl = "bd.php?tb_id=$tb_id";
			$msg = "등록처리 완료되었습니다";
		}


		/* 공용 파라미터 값 세팅 */

		$subject = $title;
		$content = $content1;
		$pub_date = $pub_date;
		$writer_id = ($user_id) ? trim($user_id) : "noid";
		$rname = ($rname) ? trim($rname) : "n";
		$targetname = ($targetname) ? trim($targetname) : "n";
		$ip = $ip;
		$table_id = $tb_id;

		/* 미리준비된 문장 실행하기 */
		$stmt->execute();
		/* 문장과 접속 닫기 */
		$stmt->close();

		alert($msg,$gurl);
	}

	$my_db->close();
	$smarty->assign("viewtitle","자료실 글쓰기 수정페이지");
	$smarty->display('bd_write.html');
?>
