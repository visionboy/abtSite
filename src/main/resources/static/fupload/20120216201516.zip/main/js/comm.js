<!--start addboard js-->
function add_board()
{
	var frm = document.addboard;
	if (frm.boardname.value.length < 2)
					{
						alert("게시판명을 입력하세요!");
						frm.boardname.value = "";
						frm.boardname.focus();
						return;
					}
	if (frm.bo_skin.value.length == '')
					{
						alert("사용하실 스킨을 선택하여 주세요!");
						frm.bo_skin.focus();
						return;
					}
	document.addboard.action= "admin_action.php"; 
	document.addboard.submit(); 
}
<!--End end board js-->


<!--start add_member js-->
function EnNumCheck(word)
			{
			var str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
			for (i=0; i< word.length; i++)
			{
			idcheck = word.charAt(i);
			for (j = 0; j < str.length; j++)
			{
			if (idcheck == str.charAt(j)) break;
			if (j+1 == str.length)
			{
			return false;
			}
			}
			}
			return true;
			}
			
function isNumber( s ){  
			var regu = "^[0-9]+$";
			var re = new RegExp(regu);
			if (s.search(re) != -1) {
			return true;
			} else {
			return false;
			}
			}
			
function keyCheck(){
			if(event.keyCode < 48 || event.keyCode > 57)
				{
					alert("키값이은 48~57사이만 가능합니다.");
					event.returnValue= false;
				}
			}
		
function checkEmail(strEmail) {
			//var emailReg = /^[_a-z0-9]+@([_a-z0-9]+\.)+[a-z0-9]{2,3}$/;
			var emailReg = /^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/;
			if( emailReg.test(strEmail) ){
			return true;
			}else{
			return false;
			}
			}

function   go(){ 
			var frm = document.goform;
					
					if ((frm.user_id.value.length == 0) || (frm.user_id.value.length < 4) )
					{
						alert("4자이상의 아이디를 입력하여주세요");
						frm.user_id.select();
						frm.user_id.focus();
						return false; 
					}
					else if ( EnNumCheck(frm.user_id.value) == false)
					{
						alert("아이디는 4자이상의 영문 숫자만 가능합니다.");
						frm.user_id.focus();
						return false; 
					}
							
		
					if (frm.name.value.length == 0)
					{
						alert("이름을 입력하여주세요");
						frm.name.value = "";
						frm.name.focus();
						return false; 
					}
					
					
					if (frm.pw.value.replace(/ /g, '') == "" )
					{
						alert("비밀번호를 입력하여주세요");
						frm.pw.focus();
						return false; 
					}
					if (frm.email.value.replace(/ /g, '') == "" )
					{
						alert("이메일정보를 입력하여주세요");
						frm.email.focus();
						return false; 
					}
					
					
		  document.goform.action= "adm_edite.php?update=o "; 
		  document.goform.submit(); 
		}
	
<!--End end add_member js-->

<!--Start login js-->
function   login(){ 
			var frm = document.loginform;
					
					if ((frm.user_id.value.length == 0) || (frm.user_id.value.length < 4) )
					{
						alert("4자이상의 아이디를 입력하여주세요");
						frm.user_id.select();
						frm.user_id.focus();
						return false; 
					}
					else if ( EnNumCheck(frm.user_id.value) == false)
					{
						alert("아이디는 4자이상의 영문 숫자만 가능합니다.");
						frm.user_id.focus();
						return false; 
					}
							
											
					if (frm.pw.value.replace(/ /g, '') == "" )
					{
						alert("비밀번호를 입력하여주세요");
						frm.pw.focus();
						return false; 
					}
				  return true; 
		}
<!--End login js-->

<!--Start login js-->
function   zipg(){ 
			var frm = document.zipsc;
									
					if (frm.sc.value.replace(/ /g, '') == "" )
					{
						alert("검색할 내용을 입력하여 주세요!");
						frm.sc.focus();
						return false; 
					}
		}
<!--End login js-->

// 우편번호 창

function win_open(url, name, option)
    {
        var popup = window.open(url, name, option);
        popup.focus();
    }

function win_zip(frm_name, frm_zip1, frm_zip2, frm_addr1, frm_addr2)
{
    url = "post.php?frm_name="+frm_name+"&frm_zip1="+frm_zip1+"&frm_zip2="+frm_zip2+"&frm_addr1="+frm_addr1+"&frm_addr2="+frm_addr2;
    win_open(url, "winZip", "left=50,top=50,width=508,height=508,scrollbars=no");
}

// 이메일 선택
function go_page(url) {
	    var frm = document.fregisterfrm;
	    frm.umail.value = url;
	    frm.umail.focus();
}

function go_page1(url) {
	    var frm = document.fregisterfrm;
	    frm.sbtmail1.value = url;
	    frm.sbtmail1.focus();
}

function go_page2(url) {
	    var frm = document.fregisterfrm;
	    frm.sbtmail2.value = url;
	    frm.sbtmail2.focus();
}

// 접수 체크
function   rcp_post(){ 
		var frm = document.fregisterfrm;
		var email = frm.umail1.value + "@" +frm.umail.value;
//		alert(frm.chkJumin.value);
		var showid = frm.showteam.value;
//	alert(showid);
// 실서버에서 실제로 체크시 사용
			//	if (frm.chkJumin.value != 'Y')
				if (frm.chkJumin.value != '')
				{
					alert("실명인증을 하신후 접수하기 버튼을 클릭하시길바랍니다.");
					frm.ju.focus();
					return false; 
				}
				if (showid == 1 || showid == 3)
				{
//					if (frm.chkJumin1.value != 'Y')
					if (frm.chkJumin1.value != '')
					{
						alert("실명인증을 하신후 접수하기 버튼을 클릭하시길바랍니다.");
						frm.sbju1.focus();
						return false; 
					}
					var email1 = frm.sbomail1.value + "@" +frm.sbtmail1.value;
					if (frm.sbname1.value.replace(/ /g, '') == "" )
					{
						alert("이름을 입력하여주세요!");
						frm.sbname1.focus();
						return false; 
					}

					if ((frm.sbju1.value.length != 6)  || (frm.sbtju1.value.length != 7))
					{
						alert("정확한 주밍등록번호를 입력하여 주세요!1 ");
						frm.sbju1.focus();
						return false; 
					}
					else if ((isNumber(frm.sbju1.value) == false) || (isNumber(frm.sbtju1.value) == false))
					{
						alert("정확한 주밍등록번호를 입력하여 주세요!1");
						frm.sbju1.focus();
						return false; 
					}

					if ((frm.sbaddr1.value.length == 0) || (frm.sbaddr1.value.length < 5))
					{
						alert("정확한 주소명을 입력하여 주세요!");
						frm.sbaddr1.focus();
						return false; 
					}

					if ((frm.sbp1.value.length == 0) || (frm.sbop1.value.length == 0) || (frm.sbtp1.value.length == 0))
					{
						alert("핸드폰 정보를 입력하여 주시길바랍니다.");
						frm.sbop1.focus();
						return false; 
					}
					else if ((isNumber(frm.sbp1.value) == false) || (isNumber(frm.sbop1.value) == false) || (isNumber(frm.sbtp1.value) == false))
					{
						alert("핸드폰 정보를 입력하여 주시길바랍니다!");
						frm.sbop1.focus();
						return false; 
					}
					
					if ((frm.sbt1.value.length == 0) || (frm.sbot1.value.length == 0) || (frm.sbtt1.value.length == 0))
					{
						alert("집전화 정보를 입력하여 주시길바랍니다.");
						frm.sbot1.focus();
						return false; 
					}
					else if ((isNumber(frm.sbt1.value) == false) || (isNumber(frm.sbot1.value) == false) || (isNumber(frm.sbtt1.value) == false))
					{
						alert("집전화 정보를 입력하여 주시길바랍니다!");
						frm.sbot1.focus();
						return false; 
					}
					
					if ((frm.sbomail1.value.length == 0) || (frm.sbtmail1.value.length == 0) || (checkEmail(email1) == false))
					{
						alert("정확한 이메일 정보를 입력하여 주세요!");
						frm.sbomail1.focus();
						return false; 
					}

					if ((frm.sbss1.value.length == 0) || (frm.sbss1.value.length < 2))
					{
						alert("정확한 소속정보(대학)를 입력하여 주세요!");
						frm.sbss1.focus();
						return false; 
					}
					if ((frm.sbst1.value.length == 0) || (frm.sbst1.value.length < 2))
					{
						alert("정확한 소속정보(학부)를 입력하여 주세요!");
						frm.sbst1.focus();
						return false; 
					}

				}
				if (showid == 2 || showid == 3)
				{
//					if (frm.chkJumin2.value != 'Y')
					if (frm.chkJumin2.value != '')
					{
						alert("실명인증을 하신후 접수하기 버튼을 클릭하시길바랍니다.");
						frm.sbju2.focus();
						return false; 
					}
					var email2 = frm.sbomail2.value + "@" +frm.sbtmail2.value;
					if (frm.sbname2.value.replace(/ /g, '') == "" )
					{
						alert("이름을 입력하여주세요!");
						frm.sbname2.focus();
						return false; 
					}

					if ((frm.sbju2.value.length != 6) || (frm.sbtju2.value.length != 7))
					{
						alert("정확한 주밍등록번호를 입력하여 주세요!2 ");
						frm.sbju2.focus();
						return false; 
					}
					else if ((isNumber(frm.sbju2.value) == false) || (isNumber(frm.sbtju2.value) == false))
					{
						alert("정확한 주밍등록번호를 입력하여 주세요!2");
						frm.sbju2.focus();
						return false; 
					}

					if ((frm.sbaddr2.value.length == 0) || (frm.sbaddr2.value.length < 5))
					{
						alert("정확한 주소명을 입력하여 주세요!");
						frm.sbaddr2.focus();
						return false; 
					}

					if ((frm.sbp2.value.length == 0) || (frm.sbop2.value.length == 0) || (frm.sbtp2.value.length == 0))
					{
						alert("핸드폰 정보를 입력하여 주시길바랍니다.");
						frm.sbop2.focus();
						return false; 
					}
					else if ((isNumber(frm.sbp2.value) == false) || (isNumber(frm.sbop2.value) == false) || (isNumber(frm.sbtp2.value) == false))
					{
						alert("핸드폰 정보를 입력하여 주시길바랍니다!");
						frm.sbop2.focus();
						return false; 
					}
					
					if ((frm.sbt2.value.length == 0) || (frm.sbot2.value.length == 0) || (frm.sbtt2.value.length == 0))
					{
						alert("집전화 정보를 입력하여 주시길바랍니다.");
						frm.sbot2.focus();
						return false; 
					}
					else if ((isNumber(frm.sbt2.value) == false) || (isNumber(frm.sbot2.value) == false) || (isNumber(frm.sbtt2.value) == false))
					{
						alert("집전화 정보를 입력하여 주시길바랍니다!");
						frm.sbot2.focus();
						return false; 
					}
					
					if ((frm.sbomail2.value.length == 0) || (frm.sbtmail2.value.length == 0) || (checkEmail(email2) == false))
					{
						alert("정확한 이메일 정보를 입력하여 주세요!");
						frm.sbomail2.focus();
						return false; 
					}

					if ((frm.sbss2.value.length == 0) || (frm.sbss2.value.length < 2))
					{
						alert("정확한 소속정보(대학)를 입력하여 주세요!");
						frm.sbss2.focus();
						return false; 
					}
					if ((frm.sbst2.value.length == 0) || (frm.sbst2.value.length < 2))
					{
						alert("정확한 소속정보(학부)를 입력하여 주세요!");
						frm.sbst2.focus();
						return false; 
					}
				}

				if (frm.uname.value.replace(/ /g, '') == "" )
				{
					alert("이름을 입력하여주세요!");
					frm.uname.focus();
					return false; 
				}

//				if ((frm.year.value.length == 0) || (frm.month.value.length == 0) || (frm.day.value.length == 0) )
//					{
//					alert("생년월일을 입력하여주세요");
//					frm.year.focus();
//					return;
//				}
//				else if ((isNumber(frm.year.value) == false) || (isNumber(frm.month.value) == false) || (isNumber(frm.day.value) == false))
//				{
//					alert("정확한 생년월일정보를 입력하여 주세요!");
//					frm.year.focus();
//					return;
//				}

				if ((frm.mb_zip1.value.length == 0) || (frm.mb_zip2.value.length == 0) || (frm.mb_addr1.value.length == 0) || (frm.mb_addr2.value.length == 0) )
					{
					alert("상세한 주소내역을 전부 입력하여 주시길바랍니다.");
					frm.mb_addr2.focus();
					return false; 
				}

				if ((frm.phone.value.length == 0) || (frm.phone1.value.length == 0) || (frm.phone2.value.length == 0))
					{
					alert("핸드폰 정보를 입력하여 주시길바랍니다.");
					frm.phone1.focus();
					return false; 
				}
				else if ((isNumber(frm.phone.value) == false) || (isNumber(frm.phone1.value) == false) || (isNumber(frm.phone2.value) == false))
				{
					alert("핸드폰 정보를 입력하여 주시길바랍니다!");
					frm.phone1.focus();
					return false; 
				}

				if ((frm.ju.value.length != 6) || (frm.ju1.value.length != 7))
					{
					alert("정확한 주밍등록번호를 입력하여 주세요!3 ");
					frm.ju.focus();
					return false; 
				}
				else if ((isNumber(frm.ju.value) == false) || (isNumber(frm.ju1.value) == false))
				{
					alert("정확한 주밍등록번호를 입력하여 주세요!3");
					frm.ju.focus();
					return false; 
				}

				if ((frm.tel.value.length == 0) || (frm.tel1.value.length == 0) || (frm.tel2.value.length == 0))
					{
					alert("집전화 정보를 입력하여 주시길바랍니다.");
					frm.tel1.focus();
					return false; 
				}
				else if ((isNumber(frm.tel.value) == false) || (isNumber(frm.tel1.value) == false) || (isNumber(frm.tel2.value) == false))
				{
					alert("집전화 정보를 입력하여 주시길바랍니다!");
					frm.tel1.focus();
					return false; 
				}
				
				if ((frm.umail1.value.length == 0) || (frm.umail.value.length == 0) || (checkEmail(email) == false))
				{
					alert("정확한 이메일 정보를 입력하여 주세요!");
					frm.umail1.focus();
					return false; 
				}

				if ((frm.school.value.length == 0) )
				{
					alert("정확한 소속 정보(대학)를 입력하여 주세요!");
					frm.school.focus();
					return false; 
				}
				if ((frm.ban.value.length == 0) )
				{
					alert("정확한 소속 정보(학부)를 입력하여 주세요!");
					frm.ban.focus();
					return false; 
				}

				if ((frm.subject.value.length == 0) || (frm.subject.value.length < 2))
				{
					alert("정확한 작품제목을 입력하여 주세요!");
					frm.subject.focus();
					return false; 
				}
				
	//			if (frm.ckps.value == '2')
	//			{
				if (frm.ufile.value.length == 0)
				{
					alert("작품파일을 첨부하여 주세요!");
					frm.ufile.focus();
					return false; 
				}
	//			}
				
				if (frm.jctt.value.length == 0)
				{
					alert("출품작 설명을 입력하여 주세요!");
					frm.jctt.focus();
					return false; 
				}
return true;
}
function   rcp_cf(){ 
			var frm = document.rc_cf;
									
				if (frm.uname.value.length == 0)
				{
					alert("성명 정보를 입력하여주세요!");
					frm.uname.focus();
					return false; 
				}

				if (frm.jumin.value.length == 0)
				{
					alert("정확한 주민번호 정보를 입력하여주세요!");
					frm.jumin.focus();
					return false; 
				}

				if (frm.jumin1.value.length == 0)
				{
					alert("정확한 주민번호 정보를 입력하여주세요!");
					frm.jumin1.focus();
					return false; 
				}
				return true;
}

//공지사항 체크
function   ntc_post(){ 
			var frm = document.ntc_frm;
					
				if (frm.title.value.length == 0)
				{
					alert("제목을 입력하여주세요!");
					frm.title.focus();
					return;
				}

				if ((oEditors.getById["content1"].getIR()).length < 5)
				{
					alert("4자 이상의 내용을 입력하여주세요!");
					return;
				}
				else
				{
					//alert('ok');
					frm.content1.value = (oEditors.getById["content1"].getIR());
				}

					
		  document.ntc_frm.action= "notice_write.php"; 
		  document.ntc_frm.submit(); 
}

//자료실 체크
function   board_post(){ 
			var frm = document.board_frm;

				if (frm.title.value.length == 0)
				{
					alert("제목을 입력하여주세요!");
					frm.title.focus();
					return false;
				}

				if ((oEditors.getById["content1"].getIR()).length < 5)
				{
					alert("4자 이상의 내용을 입력하여주세요!");
					return false;
				}
				else
				{
					//alert('ok');
					frm.content1.value = (oEditors.getById["content1"].getIR());
				}
}

//Faq 체크
function   faq_post(){ 
			var frm = document.faq_frm;

				if (frm.title.value.length == 0)
				{
					alert("질문내용을 입력 하여주세요!");
					frm.title.focus();
					return false;
				}

				if (frm.content1.value.length < 5)
				{
					alert("4자 이상의 내용을 입력하여주세요!");
					frm.content1.focus();
					return false;
				}
}

//게시판 검색시 사용되는 판단스크립트
function   sc_submt(){ 
			var frm = document.schform;
									
					if (frm.searinp.value.replace(/ /g, '') == "" )
					{
						alert("검색할 내용을 입력하여 주세요!");
						frm.searinp.focus();
						return false;
					}
}

//Q&A 체크
// 접수 체크
function   qna_post(ck){ 
		var frm = document.qa_frm;

				if (frm.title.value.length == 0)
				{
					alert("제목을 입력하여주세요!");
					frm.title.focus();
					return false;
				}

				if ((frm.uname.value.length == 0) || (frm.uname.value.length < 2))
				{
					alert("정확한 이름정보를 입력하여 주세요!");
					frm.uname.focus();
					return false;
				}
				
				if ((oEditors.getById["content1"].getIR()).length < 5)
				{
					alert("4자 이상의 내용을 입력하여주세요!");
					return false;
				}
				else
				{
					//alert('ok');
					frm.content1.value = (oEditors.getById["content1"].getIR());
				}

				if ((frm.upw.value.length == 0) && (ck == 'ad'))
				{
					alert("비밀번호정보를 입력하여 주시길바랍니다.!");
					frm.upw.focus();
					return false;
				}
				return true;
				
}

//질문게시판 답변 체크
function   ans_post(url){ 
			var frm = document.answer_frm;
									
				if ((frm.actt.value.length == 0) || (frm.actt.value.length < 2))
				{
					alert("답변내용을 입력하여 주세요!");
					frm.actt.focus();
					return;
				}

		  document.answer_frm.action= url; 
		  document.answer_frm.submit(); 
}

//삭제시 사용되는 스크립트
function de(url){
		if (!confirm("해당내역에 관하여 삭제하시겠습니까?")) return;	

		location.href=url;
}

//수정시 사용되는 스크립트
function mo(url){
		location.href=url;
}

//질문 수정시 사용되는 스크립트
function   qa_post2(){ 
		var frm = document.qa_frm;

				if (frm.title.value.replace(/ /g, '') == "" )
				{
					alert("제목을 입력하여주세요!");
					frm.title.focus();
					return; 
				}


				if ((frm.uname.value.length == 0) || (frm.uname.value.length < 2))
				{
					alert("정확한 이름정보를 입력하여 주세요!");
					frm.uname.focus();
					return;
				}

				if ((frm.cntt.value.length == 0) || (frm.cntt.value.length < 2))
				{
					alert("내용정보를 입력하여 주세요!");
					frm.cntt.focus();
					return;
				}
		  document.qa_frm.action= "qa_write.php"; 
		  document.qa_frm.submit(); 
}

// 질문답변 비밀번호 체크
//자료실 체크
function   pw_post(){ 
			
			var frm = document.pwform;
					
				if ((frm.upwd.value.length == 0) || (frm.upwd.value.length < 2) )
				{
					alert("정확한 비밀번호를 입력하여주세요");
					frm.upwd.select();
					frm.upwd.focus();
					return;
				}
					
		  document.pwform.action= "qa_pw.php"; 
		  document.pwform.submit(); 
}

function   pw_read(url,ckadmin,url2){
			if (ckadmin == 'o')
			{
				location.href=url2;
			}
			else
			{
				location.href=url;
			}
}

// 팝업띄우기
	function openPopup1(url, width, height, option)
	{
		var op = '';
		op += 'width=' + width + ',height=' + height + ',top=' + ((screen.availHeight - height - 50) / 2) + ', left=' + ((screen.availWidth - width-10) / 2) + ' ,';
		if(typeof option == 'undefined') op += 'status=yes, menubar=no, scrollbars=no, resizable=no, toolbar=no';
		else if(option == 'scroll') op += 'status=no, menubar=no, scrollbars=yes, resizable=no, toolbar=no';
		else op += option;
		window.open(url, '', op);
	}
// 주민등록번호 체크 시작
//maxlength 만큼 옮기면 다음으로 이동하기....


	function nextFocus(sFormName,sNow,sNext)
	{
		var sForm = 'document.'+ sFormName +'.'
		var oNow = eval(sForm + sNow);
	
		if (typeof oNow == 'object')
		{
			if ( oNow.value.length == oNow.maxLength)
			{
				var oNext = eval(sForm + sNext);
	
				if ((typeof oNext) == 'object')
					oNext.focus();
			}
		}
	}
	
	function juSubmit()
	{
		var frm = document.fregisterfrm;
//		alert(frm.uname.value);
//		alert(frm.ju.value);
//		alert(frm.ju1.value);
		var una = frm.uname.value;
		var uju = frm.ju.value;
		var uju1 = frm.ju1.value;
		if ((frm.uname.value.length == 0))
		{
			alert("정확한 이름정보를 입력하여 주세요!");
			frm.uname.focus();
			return;
		}

		if ((frm.ju.value.length != 6))
		{
			alert("정확한 주민번호를 확인하여 주세요!");
			frm.ju.focus();
			return;
		}

		if ((frm.ju1.value.length != 7))
		{
			alert("정확한 주민번호를 확인하여 주세요!");
			frm.ju1.focus();
			return;
		}
		
		var url = 'nc_p.php?ju=' + uju + '&ju1=' + uju1 + '&uname=' + una + '&mcnt=100&jutype=main';
		document.getElementById('main_proc').src = url;
	//	openPopup1(url, 0, 0);

}
// 주민등록번호 체크 종료

// 팀1 주민등록번호 체크 시작
function juSubmit1()
	{
		var frm = document.fregisterfrm;

		var una = frm.sbname1.value;
		var uju = frm.sbju1.value;
		var uju1 = frm.sbtju1.value;
		if ((frm.sbname1.value.length == 0))
		{
			alert("정확한 이름정보를 입력하여 주세요!");
			frm.sbname1.focus();
			return;
		}

		if ((frm.sbju1.value.length != 6))
		{
			alert("정확한 주민번호를 확인하여 주세요!");
			frm.sbju1.focus();
			return;
		}

		if ((frm.sbtju1.value.length != 7))
		{
			alert("정확한 주민번호를 확인하여 주세요!");
			frm.sbtju1.focus();
			return;
		}
		
		var url = 'nc_p.php?ju=' + uju + '&ju1=' + uju1 + '&uname=' + una + '&mcnt=100&jutype=sub1';
		document.getElementById('main_proc').src = url;

}

// 팀2 주민등록번호 체크 시작
function juSubmit2()
	{
		var frm = document.fregisterfrm;

		var una = frm.sbname2.value;
		var uju = frm.sbju2.value;
		var uju1 = frm.sbtju2.value;
		if ((frm.sbname2.value.length == 0))
		{
			alert("정확한 이름정보를 입력하여 주세요!");
			frm.sbname2.focus();
			return;
		}

		if ((frm.sbju2.value.length != 6))
		{
			alert("정확한 주민번호를 확인하여 주세요!");
			frm.sbju2.focus();
			return;
		}

		if ((frm.sbtju2.value.length != 7))
		{
			alert("정확한 주민번호를 확인하여 주세요!");
			frm.sbtju2.focus();
			return;
		}
		
		var url = 'nc_p.php?ju=' + uju + '&ju1=' + uju1 + '&uname=' + una + '&mcnt=100&jutype=sub2';
		document.getElementById('main_proc').src = url;
}
function closewin(){
		window.close();
}

// 질문과 답변 비밀번호 체크 스크립트
function showDetail(code) { 
//배경
  var bgObj=document.getElementById("bgDiv");
  bgObj.style.width = "1000px";
  bgObj.style.height = "220px";

  var frm = document.pwform;
  frm.no.value = code;
	

//튀어나오는창
  var msgObj=document.getElementById("msgDiv");
  msgObj.style.marginTop = 50 +  document.documentElement.scrollTop + "px";

//닫기
  document.getElementById("msgShut").onclick = function(){
  bgObj.style.display = msgObj.style.display = "none";
  }
  msgObj.style.display = bgObj.style.display = "block";
}

// 질문과 답변 비밀번호 체크 스크립트
