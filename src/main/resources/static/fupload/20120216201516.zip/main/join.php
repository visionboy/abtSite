<?php
	session_start();
	require('inc/comm.php');

	// html로부터 받은 값
	//echo $uname."<br>";
	//echo $uid."<br>";
	//echo $upwd."<br>";
	//echo $uemail."<br>";

	// 씸플 SELECT
	$rs = mysqli_query($my_db, " select id,pw,name,email from member ");
	while($data = mysqli_fetch_array($rs)){
	 echo "아이디:".$data['id']." 비밀번호:".$data['id']." 이름:".$data['name']." 이메일:".$data['email']."<br>";
	}

	if ($uname && $uid && $upwd && $uemail)
	{
	// 입력
		$stmt = $my_db->prepare("INSERT INTO member (id,pw,name,email) VALUES (?, ?, ?, ?) ");
		$stmt->bind_param("ssss", $uid,$upwd,$uname,$uemail);
		/* 미리준비된 문장 실행하기 */
		$stmt->execute();

		printf("%d Row inserted.\n", $stmt->affected_rows);
		$stmt->close();
		$my_db->close();

		alert("회원가입되었습니다. ^^","join.php");
	}
	


	$smarty->display('join.html');
?>