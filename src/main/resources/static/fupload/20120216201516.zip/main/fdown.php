<?php
	require('inc/comm.php');
	$ofile = "fupload/".$ofile;

	if(file_exists($ofile))
	{
		$nfile = iconv("UTF-8","euc-kr",urldecode($nfile));
		header('Content-Type: application/octet-stream');
		header("Content-Disposition: attachment; filename=".$nfile);
		header('Content-Length: '.filesize($ofile));
		readfile($ofile);
	}
	else
	{
		alertkr("������ ���������ʽ��ϴ�.");
	}



	

?>