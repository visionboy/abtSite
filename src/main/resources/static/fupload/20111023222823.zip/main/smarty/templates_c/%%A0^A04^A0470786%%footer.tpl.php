<?php /* Smarty version 2.6.26, created on 2011-10-21 11:31:03
         compiled from inc/footer.tpl */ ?>
 </body>
</html>