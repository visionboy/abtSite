<?php /* Smarty version 2.6.26, created on 2011-10-22 15:56:36
         compiled from login.html */ ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
 <head>
  <title> New Document </title>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  
  <script type="text/javascript" charset="utf-8">
  function cklogin()
  {
	var frm = document.login;
	if (frm.uid.value.length == 0)
	{
		alert("아이디를 입력하여 주세요");
		frm.uid.focus();
		return false;
	}
	if (frm.upw.value.length == 0)
	{
		alert("비밀번호를 입력하여 주세요");
		frm.upw.focus();
		return false;
	}
	if (frm.uname.value.length == 0)
	{
		alert("이름을 입력하여 주세요");
		frm.uname.focus();
		return false;
	}
  }
  </script>

 </head>

 <body>
  <form action="login.php" method="post" name="login" onsubmit="return cklogin()">
	<table>
		<tr>
			<td>
				아이디<input type="text" name="uid" >
			</td>
		</tr>
		<tr>
			<td>
				비밀번호<input type="password" name="upw" >
			</td>
		</tr>
		<tr>
			<td>
				이름<input type="text" name="uname" >
			</td>
		</tr>
		<tr>
			<td>
				<input type="submit" value="join" >
			</td>
		</tr>
	</table>

	<!-- 리스트 출력 -->
	<br>
	<table>
		<tr>
			<th>아이디</th>
			<th>비밀번호</th>
			<th>이름</th>
			<th> pro </th>
		</tr>
	<!-- 항목출력 시작 -->
		<?php unset($this->_sections['loop']);
$this->_sections['loop']['name'] = 'loop';
$this->_sections['loop']['loop'] = is_array($_loop=$this->_tpl_vars['memberlist']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['loop']['show'] = true;
$this->_sections['loop']['max'] = $this->_sections['loop']['loop'];
$this->_sections['loop']['step'] = 1;
$this->_sections['loop']['start'] = $this->_sections['loop']['step'] > 0 ? 0 : $this->_sections['loop']['loop']-1;
if ($this->_sections['loop']['show']) {
    $this->_sections['loop']['total'] = $this->_sections['loop']['loop'];
    if ($this->_sections['loop']['total'] == 0)
        $this->_sections['loop']['show'] = false;
} else
    $this->_sections['loop']['total'] = 0;
if ($this->_sections['loop']['show']):

            for ($this->_sections['loop']['index'] = $this->_sections['loop']['start'], $this->_sections['loop']['iteration'] = 1;
                 $this->_sections['loop']['iteration'] <= $this->_sections['loop']['total'];
                 $this->_sections['loop']['index'] += $this->_sections['loop']['step'], $this->_sections['loop']['iteration']++):
$this->_sections['loop']['rownum'] = $this->_sections['loop']['iteration'];
$this->_sections['loop']['index_prev'] = $this->_sections['loop']['index'] - $this->_sections['loop']['step'];
$this->_sections['loop']['index_next'] = $this->_sections['loop']['index'] + $this->_sections['loop']['step'];
$this->_sections['loop']['first']      = ($this->_sections['loop']['iteration'] == 1);
$this->_sections['loop']['last']       = ($this->_sections['loop']['iteration'] == $this->_sections['loop']['total']);
?>
		<tr>
			<td><?php echo $this->_tpl_vars['memberlist'][$this->_sections['loop']['index']]['id1']; ?>
</td>
			<td><?php echo $this->_tpl_vars['memberlist'][$this->_sections['loop']['index']]['pw1']; ?>
</td>
			<td><?php echo $this->_tpl_vars['memberlist'][$this->_sections['loop']['index']]['uname']; ?>
</td>
			<td><a href="login.php?no=<?php echo $this->_tpl_vars['memberlist'][$this->_sections['loop']['index']]['no']; ?>
">삭제</a></td>
		</tr>
		<?php endfor; endif; ?>
	</table>

	</form>
 </body>
</html>