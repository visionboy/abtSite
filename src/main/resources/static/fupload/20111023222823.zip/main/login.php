<?php
	session_start();
	require('inc/common.php'); 
	
//글입력
// 값이 비지않았을때만 테이블에 값입력	
	if ($uid && $upw && $uname) 
	{
		$sql = "insert into login (id,pw,name) values ('$uid','$upw','$uname')";
		include 'inc/trutf8.php';
		$DB->query($sql);

	// 메세지 출력
		alert("정상적으로 회원가입 되었습니다.","login.php");
	}
	

//리스트 출력
	$listsql = "SELECT  no,id,pw,name  FROM  login";
	include 'inc/trutf8.php';
	$result=$DB->query($listsql);
	
	while ($row=$DB->fetch_row($result))
	{
		$array[]= array("no"=>$row['no'],"id1"=>$row['id'],"pw1"=>$row['pw'],"uname"=>$row['name']);
	}

	echo $no;

//삭제시
	if ($no)
	{
		$desql = "DELETE  FROM  login WHERE  no = $no";
		//쿼리실행
		include 'inc/trutf8.php';
		$DB->query($desql);
		alert("정상적으로 삭제 되었습니다.","login.php");
	}


//출력값을 	memberlist 에 넣어준다
	$smarty->assign("memberlist",$array);
	
	$smarty->display('login.html');

?>
