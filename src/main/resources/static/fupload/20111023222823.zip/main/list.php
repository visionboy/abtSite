<meta http-equiv="content-type" content="text/html; charset=utf-8">

<?php
	
	$name = "스터디";

	echo $name;
	echo "<br>";

	$i = 0;

	if ($i == 0)
	{
		echo "ok";
	}
	elseif ($i == 1)
	{
		echo "1"; 
	}
	else
	{
		echo "other";
	}
	
	echo "<br>";

	require('inc/common.php');
	$smarty->display('list.html');
?>
