<?php
	$getcount = count($_GET);
	$postcount = count($_POST);
	if ($getcount!=0)
	{
		foreach($_GET as $key =>$value)
		{
			$key=$value;
			if (	sizeof(explode('CREATE', $key))>1 
					|| sizeof(explode('DROP', $key))>1 
					|| sizeof(explode('UPDATE', $key))>1 
					|| sizeof(explode('UNION', $key))>1 
					|| sizeof(explode("OR", $key))>1 
					|| sizeof(explode('SELECT', $key))>1 
					|| sizeof(explode('AND', $key))>1 
					|| sizeof(explode('EXEC', $key))>1 
					|| sizeof(explode('INSERT', $key))>1 
					|| sizeof(explode('DECLARE', $key))>1 
					|| sizeof(explode('DELETE', $key))>1 
					|| sizeof(explode('create', $key))>1 
					|| sizeof(explode('drop', $key))>1 
					|| sizeof(explode('update', $key))>1 
					|| sizeof(explode('union', $key))>1 
					|| sizeof(explode("or", $key))>1 
					|| sizeof(explode('select', $key))>1 
					|| sizeof(explode('and', $key))>1 
					|| sizeof(explode('exec', $key))>1 
					|| sizeof(explode('insert', $key))>1 
					|| sizeof(explode('declare', $key))>1 
					|| sizeof(explode('delete', $key))>1
					|| sizeof(explode('SCRIPT', $key))>1
					|| sizeof(explode('/SCRIPT', $key))>1
					|| sizeof(explode('META', $key))>1
					|| sizeof(explode('LINK', $key))>1
					|| sizeof(explode('BODYD', $key))>1
					|| sizeof(explode('FORM', $key))>1
					|| sizeof(explode('COOKIE', $key))>1
					|| sizeof(explode('DOCUMENT', $key))>1
					|| sizeof(explode('script', $key))>1
					|| sizeof(explode('/script', $key))>1
					|| sizeof(explode('meta', $key))>1
					|| sizeof(explode('link', $key))>1
					|| sizeof(explode('bodyd', $key))>1
					|| sizeof(explode('form', $key))>1
					|| sizeof(explode('cookie', $key))>1
					|| sizeof(explode('document', $key))>1
				) 
				{ 
				 echo "<script>alert('�������� ������� ����Ͽ��ֽñ�ٶ��ϴ�.')</script>;"; 
				}
		}
	}
	else
	{
		foreach($_POST as $key =>$value)
		{
			$key=$value;
			if (	sizeof(explode('CREATE', $key))>1 
					|| sizeof(explode('DROP', $key))>1 
					|| sizeof(explode('UPDATE', $key))>1 
					|| sizeof(explode('UNION', $key))>1 
					|| sizeof(explode("OR", $key))>1 
					|| sizeof(explode('SELECT', $key))>1 
					|| sizeof(explode('AND', $key))>1 
					|| sizeof(explode('EXEC', $key))>1 
					|| sizeof(explode('INSERT', $key))>1 
					|| sizeof(explode('DECLARE', $key))>1 
					|| sizeof(explode('DELETE', $key))>1 
					|| sizeof(explode('create', $key))>1 
					|| sizeof(explode('drop', $key))>1 
					|| sizeof(explode('update', $key))>1 
					|| sizeof(explode('union', $key))>1 
					|| sizeof(explode("or", $key))>1 
					|| sizeof(explode('select', $key))>1 
					|| sizeof(explode('and', $key))>1 
					|| sizeof(explode('exec', $key))>1 
					|| sizeof(explode('insert', $key))>1 
					|| sizeof(explode('declare', $key))>1 
					|| sizeof(explode('delete', $key))>1
					|| sizeof(explode('SCRIPT', $key))>1
					|| sizeof(explode('/SCRIPT', $key))>1
					|| sizeof(explode('META', $key))>1
					|| sizeof(explode('LINK', $key))>1
					|| sizeof(explode('BODYD', $key))>1
					|| sizeof(explode('FORM', $key))>1
					|| sizeof(explode('COOKIE', $key))>1
					|| sizeof(explode('DOCUMENT', $key))>1
					|| sizeof(explode('script', $key))>1
					|| sizeof(explode('/script', $key))>1
					|| sizeof(explode('meta', $key))>1
					|| sizeof(explode('link', $key))>1
					|| sizeof(explode('bodyd', $key))>1
					|| sizeof(explode('form', $key))>1
					|| sizeof(explode('cookie', $key))>1
					|| sizeof(explode('document', $key))>1
				) 

				{ 
				 echo "<script>alert('�������� ������� ����Ͽ��ֽñ�ٶ��ϴ�.')</script>"; 
				}
			}
	}
?>
