<?php
	date_Default_TimeZone_set("Asia/Seoul");
	define('ROOTPATH', dirname(__FILE__));
	require('inc/smarty_config.php');
	require('inc/conn.php');
	require('inc/lib.php');
	//require('inc/sqlinjection.php');
	extract($_POST);
	extract($_GET);
	$DB=new  mysql($host,$user,$pwd,$db);
?>
