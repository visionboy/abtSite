<?php
require('../libs/Smarty.class.php');
$smarty = new Smarty;
$smarty->left_delimiter	=	"<{";
$smarty->right_delimiter	=	"}>";
$smarty->template_dir	=	"smarty/templates/";
$smarty->compile_dir	= "smarty/templates_c/";
$smarty->caching	=	false;
$smarty->cache_dir	=	"smarty/cache/";
$smarty->cache_lifetime	=	40;//30;
$smarty->compile_check = true; 

?>