<?php
/** 아래 소스는 한글출력이 안됨!!! 한글 출력은 추후에.. 
	스타일시트도 안먹음!!!
	이미지도 안됨**/
include ('../inc/auth.php');
include($rootpath.'/inc/config.php');
require('../inc/html2pdf/html2fpdf.php');
$prm = $_REQUEST;
$con = dbopen();

$pdf = new HTML2FPDF();

$pdf->AddPage();
$pdf->SetMargins('10', '10', '10') ;
 
$pdf->Cell("*",10, 'LSI-Language Structure Intellegence' ,0,1,'C');
$pdf->Ln();

if($_SESSION["utype"] && $_SESSION["uid"] && $_SESSION["upwd"])
{
	$bidx		= $prm['bidx'];
	$level		= $prm['level'];
	$cidx		= $prm['cidx'];
	$stidx		= $prm['stidx'];
	$category	= $prm['category']; // lsi category (문자열일듯...)
	$scol		= $prm['scol'];//검색조건
	$sval		= $prm['sval'];//검색조건

	switch($_SESSION["utype"])
	{
		case TYPE_SCHOOL : 	
							$schidx = $_SESSION["uidx"];
							$param['uidx'] = $stidx; //학생seq
		break;
		case TYPE_TEACHER : 	
							$schidx = $_SESSION["schidx"];
							$param['uidx'] = $stidx; //학생seq
							$search_str = " and ( a.tutidx=".$_SESSION['uidx']." or  a.tutidx2=".$_SESSION['uidx'] .")";
		break;
		case TYPE_STUDENT : 	$schidx = $_SESSION["schidx"];$param['uidx'] = $_SESSION["uidx"]; //내seq
		break;
	}
	
	$param['bidx']	= $bidx;
	$param['level'] = $level;
	if($sval != "")
	{
		$param['scol']	= $scol;
		$param['sval']	= $sval;
	}

	if($param['uidx'] )
	{
		$lsi_list = getStoryTutorLSIList($param);
	}

	//view용 데이터 세팅
	if($lsi_list)
	{
		foreach($lsi_list as $key => $value)
		{
			if(!$tmp) { $tmp = strtolower(trim($value['ls'])); $tkey = $key; }
			if( strcmp($tmp , strtolower(trim($value['ls']))) == 0)
			{
				$i++;
				//if( $scol != '3' ) //
				//if( $scol =='')//검색이 아닐때만
				//{
					if($i <= 3 ) //3권만 뿌리도록 함 (교재검색을 제외하고)
						$list[$tkey]['rowspan']++; //rowspan 표시용
				/*}
				else
					$list[$tkey]['rowspan']++; //rowspan 표시용
				*/
				if($value['setdate'] != "") //학습한 기록이 있을때만 ++
					$list[$tkey]['totalcnt']++;//전체학습권수
			}
			else
			{
				//if( $scol != '3' )
				if( $scol =='')//검색이 아닐때만
				{
					if($i < 3 ) //3칸이 안되는 데이터는 삭제
					{
						if($i==1)
						{
							$list[$tkey]['totalcnt'] = 0;
							$list[$tkey]['rowspan'] = 0;
							$list[$key-1]['ls'] = "";
							$list[$tkey]['ls'] = "";
						}
						else if ($i==2)
						{
							$list[$tkey]['totalcnt'] = 0;
							$list[$tkey]['rowspan'] = 0;
							$list[$key-1]['ls'] = "";
							$list[$key-2]['ls'] = "";
							$list[$tkey]['ls'] = "";
						}
					}
				}

				$tmp = strtolower(trim($value['ls']));
				$tkey = $key;
				$i = 1;
				$list[$tkey]['rowspan'] = 1;
				if($value['setdate'] != "") 
					$list[$tkey]['totalcnt'] = 1;//전체학습권수
				else
					$list[$tkey]['totalcnt'] = 0;//전체학습권수
			}

			//if( $scol != '3' )
			//if( $scol =='')//검색이 아닐때만
			//{
				if($i <= 3 )//3권만 뿌리도록 함
				{
					$list[$key]['bookno'] = $i;//책순서
					$list[$key]['ls'] = $value['ls'];
					if($value['setdate'] != "") //학습한 기록이 있을때만
					{
						$list[$key]['booklevel'] = $value['booklevel'];
						$list[$key]['bookname'] = $value['bookname'];
						$list[$key]['date'] = $value['setdate'];
						$list[$key]['grl'] = $value['grl'];
						$list[$key]['sentence'] = $value['sentence'];
					}
				}
			/*}
			else
			{
				$list[$key]['bookno'] = $i;//책순서
				$list[$key]['ls'] = $value['ls'];
				if($value['setdate'] != "") //학습한 기록이 있을때만
				{
					$list[$key]['booklevel'] = $value['booklevel'];
					$list[$key]['bookname'] = $value['bookname'];
					$list[$key]['date'] = $value['setdate'];
					$list[$key]['grl'] = $value['grl'];
					$list[$key]['sentence'] = $value['sentence'];
				}
			}*/
		}
	}	

	$pdf->WriteHTML("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<html>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
<meta http-equiv='X-UA-Compatible' content='IE=Edge' />
<title>testMyPang</title>
<link rel='stylesheet' type='text/css' href='http://".$_SERVER['HTTP_HOST']."/css/default.css'/>
<body>

	<div class='lsi'>
			
			<div style='overflow-x: hidden; overflow-y: scroll:width:820px'>
				<table cellpadding='0' cellspacing='0' summary='LSI학습이력관리테이블입니다.' border='1' class='ta_lsi_list'>
					<caption>
						Language Structure Intellegence
					</caption>
					<colgroup>
						<col width='3%' />
						<col width='18%' />
						<col width='6%' />
						<col width='6%' />
						<col width='7%' />
						<col width='19%' />
						<col width='7%' />
						<col width='4%' />
						<col width='*' />
					</colgroup>
					<thead>
						<tr>
							<th>
								No.
							</th>
							<th>
								Language Structure
							</th>
							<th colspan=2>
								count / done
							</th>
							<th>
								mypang<br />
								Level
							</th>
							<th>
								Bookname
							</th>
							<th>
								Date
							</th>
							<th>
								GRL
							</th>
							<th>
								Sentence
							</th>
						</tr>
					</thead>
					
					<tbody>");

						if( count($list) > 0)
						{
							$i=0;
							foreach($list as $value)
							{
								if($value['ls'] !="")
								{
									$pdf->WriteHTML( "<tr>");
									if($value['rowspan'] > 0)
									{ 
										$i++; // line number
										//if($value['totalcnt']>3)
											$j = intval($value['totalcnt']); // 학습권수 
										//else
											//$j = intval($value['rowspan']); // 칸수

										$pdf->WriteHTML( "<td rowspan='".$value['rowspan']."' align='center' height='30' >".$i."</td>
												<td rowspan='".$value['rowspan']."' align='center' >".$value['ls']."</td>");
									}
									
									if($j>0)
										$pdf->WriteHTML( "<td align='center' height='20'>#".$j."</td>");
									else
										$pdf->WriteHTML( "<td align='center' height='20'></td>");

									if($value['rowspan'] > 0) //학습여부
									{ 
										if($value['totalcnt'] > 0) //로그가 있는 경우
										{
											$pdf->WriteHTML( "<td rowspan='".$value['rowspan']."' align='center' height='30' >".($value['totalcnt']>=3 ? "Done":"in progress")."</td>");
										}
										else //로그가 없는 경우
										{
											$pdf->WriteHTML( "<td rowspan='".$value['rowspan']."' align='center' height='30' >None</td>");
										}
									}
									$pdf->WriteHTML( "<td align='center'>".$value['booklevel']."</td>
										<td align='center'>".$value['bookname']."</td>
										<td align='center'>".substr($value['date'],2,8)."</td>
										<td align='center'>".$value['grl']."</td>
										<td align='center'>".$value['sentence']."</td>
									</tr>");
									$j--;
								}
							}
						} 
					$pdf->WriteHTML("</tbody>
				</table>
			</div>
			 <div class='lsi_b_bg'></div>
</body>
</html>");

$pdf->WriteHTML($cont);

$file .= 'lsi.pdf';
//Save PDF to file
$pdf->Output($file, 'F');
//Redirect
header('Location: '.$file);

}
else
{
	printError(ACCESS_DENY);
}
?>
