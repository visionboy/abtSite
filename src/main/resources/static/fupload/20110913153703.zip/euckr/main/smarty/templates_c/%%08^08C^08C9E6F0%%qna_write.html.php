<?php /* Smarty version 2.6.26, created on 2011-06-10 11:06:17
         compiled from qna_write.html */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

	<div id="container">

		<div id="sidebar">
			<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/snb04.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		</div><!-- //sidebar -->

		<div id="content">
			<div id="section">
				<div id="article">
					<div id="location">
						<span>HOME</span> &gt; Ŀ�´�Ƽ &gt; Q&amp;A
					</div><!-- //location -->

					<h2>Q&amp;A</h2>

<!-- �۾���κ� -->
<form id="qa_frm" name="qa_frm" action="qna_write.php" method="post" enctype="multipart/form-data" onsubmit="return qna_post('<?php echo $this->_tpl_vars['mntype']; ?>
');">

<table cellpadding="0" cellspacing="0" border="1" summary="�̸�,�н�����,����,������ ������ �Է��ϴ� ǥ�Դϴ�." class="bbswrite">
<caption>�۾���</caption>
<tbody>
	<tr class="first">
		<th scope="row" style="width:100px"><span>���� : </span></th>
		<td style="width:640px">
			<label for="title" class="hidden">�����Է�</label>
			<input type="text" name="title" id="title" class="inp" style="width:640px" maxlength="40" value="<?php echo $this->_tpl_vars['subject']; ?>
">
		</td>
	</tr>
	<tr>
		<th scope="row"><span>�̸� : </span></th>
		<td>
			<label for="uname" class="hidden">�̸��Է�</label>
			<input type="text" name="uname" id="uname" class="inp" style="width:140px" value="<?php echo $this->_tpl_vars['qa_name']; ?>
"  maxlength="15">
		</td>
	</tr>
	<!--�۾��� ȭ�鿡���� ���-->
	<?php if ($this->_tpl_vars['mo'] == '' && $this->_tpl_vars['no'] == ''): ?>
	<tr>
		<th scope="row"><span>�н����� : </span></th>
		<td>
			<label for="upw" class="hidden">�н������Է�</label>
			<input type="password" name="upw" id="upw" class="inp" style="width:140px">
		</td>
	</tr>
	<?php endif; ?>
	<tr class="last">
		<th scope="row"><span>÷������ : </span></th>
		<td>
			<label for="ufile" class="hidden">����÷��</label>
			<input type="file" name="ufile" id="ufile" class="inp" style="width:640px">
		</td>
	</tr>
	<tr class="subject">
		<td colspan="2">
			<label for="content1" class="hidden">�����Է�</label>
			<textarea name="content1" id="content1" cols="70" rows="9" style="width:748px;height:300px;display:none"><?php echo $this->_tpl_vars['content']; ?>
</textarea>
			<input type="hidden" name="mo" value="<?php echo $this->_tpl_vars['mo']; ?>
">
			<input type="hidden" name="gno" value="<?php echo $this->_tpl_vars['gno']; ?>
">
		</td>
	</tr>
</tbody>
</table>

<!-- ��ư -->
<div class="bbsbtn" style="text-align:center">
	<input type="image" src="images/common/btn/btn_confirm.gif" alt="���" onclick="return qna_post('<?php echo $this->_tpl_vars['mntype']; ?>
');">
</div>

</form>
<script type="text/javascript">
	var oEditors = [];
	nhn.husky.EZCreator.createInIFrame({
	oAppRef: oEditors,
	elPlaceHolder: "content1",
	sSkinURI: "SEditorSkin.html",
	fCreator: "createSEditorInIFrame"
	});

	function pasteHTMLDemo(){
		sHTML = "<span style='color:#ff0000'>�̹��� � �̷��� �����ϸ� �˴ϴ�.</span>";
		oEditors.getById["content1"].exec("PASTE_HTML", [sHTML]);
		}

	function showHTML(){
		alert(oEditors.getById["content1"].getIR());
		}

	function _onSubmit(elClicked){
		oEditors.getById["content1"].exec("UPDATE_IR_FIELD", []);
									
		// �������� ���뿡 ���� �� ������ �̰����� document.getElementById("content1").value�� �̿��ؼ� ó���ϸ� �˴ϴ�.

		try{
			elClicked.form.submit();
		}catch(e){}
	}
</script>

				</div><!-- //article -->
			</div><!-- //section -->
		</div><!-- //content -->
	</div><!-- //container -->

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>