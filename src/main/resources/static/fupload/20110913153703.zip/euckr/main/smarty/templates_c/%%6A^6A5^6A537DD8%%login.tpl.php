<?php /* Smarty version 2.6.26, created on 2011-09-13 15:04:30
         compiled from login.tpl */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="ko">
<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<meta http-equiv="X-UA-Compatible" content="IE=7">
<title> ������ �׽�Ʈ �α��� </title>
<link rel="stylesheet" type="text/css" href="css/common.css">
<style type="text/css">

/* layout */
#wrap{position:absolute;left:50%;top:50%;margin:-250px 0px 0px -250px;width:500px;height:372px;background:#fff;text-align:left;border:1px solid #f5f5f5}
#header{margin:17px auto;padding-top:32px;width:482px;height:70px;background:url(images/common/bg/bg_login_title.gif) no-repeat left top}
#header h1{margin:0px 0px 5px 112px;padding:0px;width:165px;height:28px;text-align:center}
#header p{margin-left:112px;width:350px;line-height:150%;text-align:left}
#header p span{color:#4f83af}
#content{margin:0px auto;padding-top:32px;width:482px;height:180px;background:url(images/common/bg/bg_login_form.gif) no-repeat left top}
dl{margin:0px auto 40px auto;width:260px;*zoom:1}
dl:after{content:"";clear:both;display:block}
dl dt{clear:both;margin-bottom:10px;width:80px;height:22px;float:left;font-weight:bold}
dl dd{margin-bottom:10px;width:176px;height:22px;float:right}
dl dd input{width:174px;height:20px;line-height:20px;border:1px solid #6d6d6d}
p{margin:0px auto;width:400px;text-align:center}
</style>
<script charset="utf-8" src="js/comm.js"></script>
</head>

<body>
<div id="wrap">
	<div id="header">
		<h1><img src="images/common/title_login.gif" alt="������ �α���"></h1>
		<p>������ <span>�׽�Ʈ ������ ������</span> �Դϴ�.</p>
	</div><!-- //header -->

	<div id="content">
	<form name="loginform"  method="post" action = "slogin.php" onsubmit="return login()">
		<dl>
			<dt><label for="uid"><img src="images/common/label_id.gif" alt="���̵�"></label></dt>
			<dd><input type="text" name="user_id" id="uid"></dd>
			<dt><label for="upw"><img src="images/common/label_pw.gif" alt="�н�����"></label></dt>
			<dd><input type="password" name="pw" onKeyDown="if (event.keyCode == 13) login();" id="upw"></dd>
		</dl>
		<p><input type="image" src="images/common/btn/btn_login.gif" alt="�α���"></p>
	</form>
	</div><!-- //content -->
</div><!-- //wrap -->
</body>
</html>
