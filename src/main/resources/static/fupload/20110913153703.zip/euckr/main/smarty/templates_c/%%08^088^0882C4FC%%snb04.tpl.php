<?php /* Smarty version 2.6.26, created on 2011-06-09 20:23:17
         compiled from inc/snb04.tpl */ ?>
<div class="snb04">
	<h2>Ŀ�´�Ƽ</h2>
	<ul>
		<li><a href="board.php">��������</a></li>
		<li><a href="qna.php">Q&amp;A</a></li>
	</ul>
</div>