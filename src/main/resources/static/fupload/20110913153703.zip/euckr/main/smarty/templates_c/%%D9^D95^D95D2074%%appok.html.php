<?php /* Smarty version 2.6.26, created on 2011-06-09 19:03:57
         compiled from appok.html */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

	<div id="container">

		<div id="sidebar">
			<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/snb03.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		</div><!-- //sidebar -->

		<div id="content">
			<div id="section">
				<div id="article">
					<div id="location">
						<span>HOME</span> &gt; ��ǰ���� �� Ȯ�� &gt; ����Ȯ��
					</div><!-- //location -->

					<h2>����Ȯ��</h2>

<!-- ����Ȯ�� -->
<form name="rc_cf" id ="rc_cf" action="appok.php"  method="post" onsubmit="return rcp_cf()">

<table cellpadding="0" cellspacing="0" border="1" class="bbsapp">
<tbody>
	<tr>
		<th scope="row" class="thtit">�� ��</th>
		<td>
			<input type="radio" name="sc" id="sc1" value="U" checked="checked"> <label for="sc1">UCC</label>
			<input type="radio" name="sc" id="sc2" value="P"> <label for="sc2">������</label>
			<input type="radio" name="sc" id="sc2" value="T"> <label for="sc3">ǥ��</label>
		</td>
	</tr>
	<tr>
		<th scope="row" class="thtit">��������</th>
		<td>
			<input type="radio" name="uposter" id="uposter1" value="A" checked="checked"> <label for="uposter1">�ʵ� ���г� ��(1~3�г�)</label>
			<input type="radio" name="uposter" id="uposter2" value="B"> <label for="uposter2">�ʵ� ���г� ��(4~6�г�)</label>
			<input type="radio" name="uposter" id="uposter3" value="C"> <label for="uposter3">�ߵ��</label>
		</td>
	</tr>
	<tr>
		<th scope="row" class="thtit">������</th>
		<td>
			<label for="uname" class="hidden">������ �Է�</label>
			<input type="text" name="uname" id="uname" maxlength="6" class="inp">
		</td>
	</tr>
	<tr>
		<th scope="row" class="thtit">E-mail</th>
		<td>
			<label for="umail1" class="hidden">���Ͼ��̵� �Է�</label>
			<input type="text" name="umail1" id="umail1" class="inp" style="width:80px" > @ 

			<label for="umail" class="hidden">�����ּ� �Է�</label>
			<input type="text" name="umail" id="umail" class="inp" style="width:104px">

			<label for="semail" class="hidden">�����ּ� ��������</label>
			<select style="width:150px" name="semail" id="semail" onChange="go_page(this.value)">
				<option value="" >�����Է�</option>
				<option value="dreamwiz.com">dreamwiz.com</option>
				<option value="empas.com">empas.com</option>
				<option value="freechal.com">freechal.com</option>
				<option value="gmail.com">gmail.com</option>
				<option value="hanafos.com">hanafos.com</option>
				<option value="hanmail.net">hanmail.net</option>
				<option value="hotmail.com">hotmail.com</option>
				<option value="korea.com">korea.com</option>
				<option value="lycos.com">lycos.com</option>
				<option value="msn.com">msn.com</option>
				<option value="nate.com">nate.com</option>
				<option value="naver.com">naver.com</option>
				<option value="paran.com">paran.com</option>
				<option value="sayclub.com">sayclub.com</option>
				<option value="yahoo.com">yahoo.com</option>
			</select>
		</td>
	</tr>
	<tr>
		<th scope="row" class="thtit">��ȣ</th>
		<td>
			<label for="upw" class="hidden">��ȣ�Է�</label>
			<input type="password" name="upw" id="upw" class="inp" style="width:100px">
		</td>
	</tr>
</tbody>
</table>

<!-- ��ư -->
<div class="bbsbtn" style="text-align:center">
	<input type="image" src="images/common/btn/btn_ok.gif" alt="��ȸ" >
</div>

</form>

				</div><!-- //article -->
			</div><!-- //section -->
		</div><!-- //content -->
	</div><!-- //container -->

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>