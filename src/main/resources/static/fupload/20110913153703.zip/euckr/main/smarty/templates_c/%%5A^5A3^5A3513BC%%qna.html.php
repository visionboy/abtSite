<?php /* Smarty version 2.6.26, created on 2011-06-09 19:32:27
         compiled from qna.html */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

	<div id="container">

		<div id="sidebar">
			<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/snb04.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		</div><!-- //sidebar -->

		<div id="content">
			<div id="section">
				<div id="article">
					<div id="location">
						<span>HOME</span> &gt; Ŀ�´�Ƽ &gt; Q&amp;A
					</div><!-- //location -->

					<h2>Q&amp;A</h2>

<!-- ����Ʈ�κ� -->
<table cellpadding="0" cellspacing="0" border="1" summary="��ȣ,����,�ۼ���,��¥,�亯������ ������ �����ִ� ǥ�Դϴ�." class="bbslist">
<caption>����Ʈ</caption>
<thead>
	<tr>
		<th scope="col" class="first" style="width:10%"><span>��ȣ</span></th>
		<th scope="col" style="width:30%"><span>����</span></th>
		<th scope="col" style="width:10%"><span>�ۼ���</span></th>
		<th scope="col" style="width:10%"><span>��¥</span></th>
		<th scope="col" class="last" style="width:10%"><span>�亯����</span></th>
	</tr>
</thead>
<tbody>
	<!--��ϵ� ���� ������-->
	<?php if ($this->_tpl_vars['totalnum'] == 0 && $this->_tpl_vars['totalnum2'] == 0): ?>
	<tr>
		<td colspan="5" class="text_c">��ϵ� ���� �����ϴ�.</td>
	</tr>
	<?php else: ?>
	<!--�����ڰ� �����Ͻ�-->
	<?php unset($this->_sections['loop2']);
$this->_sections['loop2']['name'] = 'loop2';
$this->_sections['loop2']['loop'] = is_array($_loop=$this->_tpl_vars['ntc_list']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['loop2']['show'] = true;
$this->_sections['loop2']['max'] = $this->_sections['loop2']['loop'];
$this->_sections['loop2']['step'] = 1;
$this->_sections['loop2']['start'] = $this->_sections['loop2']['step'] > 0 ? 0 : $this->_sections['loop2']['loop']-1;
if ($this->_sections['loop2']['show']) {
    $this->_sections['loop2']['total'] = $this->_sections['loop2']['loop'];
    if ($this->_sections['loop2']['total'] == 0)
        $this->_sections['loop2']['show'] = false;
} else
    $this->_sections['loop2']['total'] = 0;
if ($this->_sections['loop2']['show']):

            for ($this->_sections['loop2']['index'] = $this->_sections['loop2']['start'], $this->_sections['loop2']['iteration'] = 1;
                 $this->_sections['loop2']['iteration'] <= $this->_sections['loop2']['total'];
                 $this->_sections['loop2']['index'] += $this->_sections['loop2']['step'], $this->_sections['loop2']['iteration']++):
$this->_sections['loop2']['rownum'] = $this->_sections['loop2']['iteration'];
$this->_sections['loop2']['index_prev'] = $this->_sections['loop2']['index'] - $this->_sections['loop2']['step'];
$this->_sections['loop2']['index_next'] = $this->_sections['loop2']['index'] + $this->_sections['loop2']['step'];
$this->_sections['loop2']['first']      = ($this->_sections['loop2']['iteration'] == 1);
$this->_sections['loop2']['last']       = ($this->_sections['loop2']['iteration'] == $this->_sections['loop2']['total']);
?>
	<tr>
		<td><strong>����</strong></td>
		<td class="text_l"><strong><a href="qna_view.php?no=<?php echo $this->_tpl_vars['ntc_list'][$this->_sections['loop2']['index']]['no']; ?>
<?php echo $this->_tpl_vars['urlpage']; ?>
"><?php echo $this->_tpl_vars['ntc_list'][$this->_sections['loop2']['index']]['subject']; ?>
</a></strong> <?php echo $this->_tpl_vars['ntc_list'][$this->_sections['loop2']['index']]['getnew']; ?>
</td>
		<td>������</td>
		<td><?php echo $this->_tpl_vars['ntc_list'][$this->_sections['loop2']['index']]['date']; ?>
</td>
		<td></td>
	</tr>
	<?php endfor; endif; ?>
	<?php unset($this->_sections['loop']);
$this->_sections['loop']['name'] = 'loop';
$this->_sections['loop']['loop'] = is_array($_loop=$this->_tpl_vars['qa_list']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['loop']['show'] = true;
$this->_sections['loop']['max'] = $this->_sections['loop']['loop'];
$this->_sections['loop']['step'] = 1;
$this->_sections['loop']['start'] = $this->_sections['loop']['step'] > 0 ? 0 : $this->_sections['loop']['loop']-1;
if ($this->_sections['loop']['show']) {
    $this->_sections['loop']['total'] = $this->_sections['loop']['loop'];
    if ($this->_sections['loop']['total'] == 0)
        $this->_sections['loop']['show'] = false;
} else
    $this->_sections['loop']['total'] = 0;
if ($this->_sections['loop']['show']):

            for ($this->_sections['loop']['index'] = $this->_sections['loop']['start'], $this->_sections['loop']['iteration'] = 1;
                 $this->_sections['loop']['iteration'] <= $this->_sections['loop']['total'];
                 $this->_sections['loop']['index'] += $this->_sections['loop']['step'], $this->_sections['loop']['iteration']++):
$this->_sections['loop']['rownum'] = $this->_sections['loop']['iteration'];
$this->_sections['loop']['index_prev'] = $this->_sections['loop']['index'] - $this->_sections['loop']['step'];
$this->_sections['loop']['index_next'] = $this->_sections['loop']['index'] + $this->_sections['loop']['step'];
$this->_sections['loop']['first']      = ($this->_sections['loop']['iteration'] == 1);
$this->_sections['loop']['last']       = ($this->_sections['loop']['iteration'] == $this->_sections['loop']['total']);
?>
	<tr>
		<td><?php echo $this->_tpl_vars['qa_list'][$this->_sections['loop']['index']]['noi']; ?>
</td>
		<td class="text_l">
		<!--�����ڸ� �ٷ� ��ȸȭ������ �ѿ������� ����/ ���� ������Ͻ� ��й�ȣâ ����-->
		<?php if ($this->_tpl_vars['ckadm'] == 'o'): ?>
		<a href="qna_view.php?no=<?php echo $this->_tpl_vars['qa_list'][$this->_sections['loop']['index']]['no']; ?>
<?php echo $this->_tpl_vars['urlpage']; ?>
">
		<?php else: ?>
		<a href="#qna" class="pw<?php echo $this->_tpl_vars['qa_list'][$this->_sections['loop']['index']]['noi']; ?>
">
		<?php endif; ?>
		<?php echo $this->_tpl_vars['qa_list'][$this->_sections['loop']['index']]['subject']; ?>
</a><?php echo $this->_tpl_vars['qa_list'][$this->_sections['loop']['index']]['getnew']; ?>
</td>
		<td><?php echo $this->_tpl_vars['qa_list'][$this->_sections['loop']['index']]['name']; ?>
</td>
		<td><?php echo $this->_tpl_vars['qa_list'][$this->_sections['loop']['index']]['date']; ?>
</td>
		<td><span style="color:#00f"><?php echo $this->_tpl_vars['qa_list'][$this->_sections['loop']['index']]['ans_status']; ?>
</span></td>
	</tr>
	<?php endfor; endif; ?>
	<?php endif; ?>
</tbody>
</table>

<div class="paging"><?php echo $this->_tpl_vars['pagelist']; ?>
</div><!-- //paging -->

<!-- ��ư -->
<div class="bbsbtn" style="text-align:right">
	<a href="qna_write.php"><img src="images/common/btn/btn_write.gif" alt="�۾���"></a>
</div>

<!-- �˻��κ� -->
<form name="schform"  action="qna.php"  method="post" onsubmit="return sc_submt()">
<div class="bbssearch">
	<label for="search" class="hidden">�˻��� ����</label>
	<select id="search" name = "search">
		<option value="subject" <?php if ($this->_tpl_vars['search'] == 'subject'): ?>  selected="selected" <?php endif; ?>>����</option>
		<option value="content" <?php if ($this->_tpl_vars['search'] == 'content'): ?>  selected="selected" <?php endif; ?>>����</option>
	</select>
	<label for="searinp" class="hidden">�˻��� �Է�</label>
	<input type="text" name="searinp" id="searinp" class="inp" style="width:50%" value="<?php echo $this->_tpl_vars['searinp']; ?>
">
	<input type="image" src="images/common/btn/btn_search.gif" alt="�˻�" >
</div><!-- //bbssearch -->
</form>
<!-- ��й�ȣ Ȯ�� -->
<div class="pwdlayer" style="display:none">
<form name="pwform"  action="qna.php"  method="post">
	<div class="pwdbg"></div>
	<div id="pwdgroup">
		<dl>
			<dt>��й�ȣ Ȯ��</dt>
			<dd class="pwdinp">
				<label for="upwd">��й�ȣ �Է� : </label>
				<input type="password" name="upwd" id="upwd" class="inp" style="width:120px">
				<input type="hidden" name="no" value="">
				<input type="hidden" name="page" value="<?php echo $this->_tpl_vars['pages']; ?>
">
			</dd>
			<dd class="pwdbtn">
				<a href="#ok" onclick="pw_post(); return false;"><img src="images/common/btn/btn_confirm.gif" style="vertical-align:top" alt="���"></a>
				<a href="#cancel" class="pwdclose"><img src="images/common/btn/btn_cancel.gif" style="vertical-align:top" alt="���"></a>
			</dd>
		</dl>
	</div><!-- //pwdgroup -->
</form>
</div><!-- //pwdlayer -->



				</div><!-- //article -->
			</div><!-- //section -->
		</div><!-- //content -->
	</div><!-- //container -->

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>