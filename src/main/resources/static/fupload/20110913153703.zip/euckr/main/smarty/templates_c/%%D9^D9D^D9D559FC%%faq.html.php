<?php /* Smarty version 2.6.26, created on 2011-06-09 19:32:33
         compiled from faq.html */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

	<div id="container">

		<div id="sidebar">
			<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/snb04.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		</div><!-- //sidebar -->

		<div id="content">
			<div id="section">
				<div id="article">
					<div id="location">
						<span>HOME</span> &gt; Ŀ�´�Ƽ &gt; FAQ
					</div><!-- //location -->

					<h2>FAQ</h2>

<!-- ����Ʈ�κ� -->
<div class="faqlist">
	<script type="text/javascript">
		$(document).ready(function(){
		<?php unset($this->_sections['loop']);
$this->_sections['loop']['name'] = 'loop';
$this->_sections['loop']['loop'] = is_array($_loop=$this->_tpl_vars['rsc_list']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['loop']['show'] = true;
$this->_sections['loop']['max'] = $this->_sections['loop']['loop'];
$this->_sections['loop']['step'] = 1;
$this->_sections['loop']['start'] = $this->_sections['loop']['step'] > 0 ? 0 : $this->_sections['loop']['loop']-1;
if ($this->_sections['loop']['show']) {
    $this->_sections['loop']['total'] = $this->_sections['loop']['loop'];
    if ($this->_sections['loop']['total'] == 0)
        $this->_sections['loop']['show'] = false;
} else
    $this->_sections['loop']['total'] = 0;
if ($this->_sections['loop']['show']):

            for ($this->_sections['loop']['index'] = $this->_sections['loop']['start'], $this->_sections['loop']['iteration'] = 1;
                 $this->_sections['loop']['iteration'] <= $this->_sections['loop']['total'];
                 $this->_sections['loop']['index'] += $this->_sections['loop']['step'], $this->_sections['loop']['iteration']++):
$this->_sections['loop']['rownum'] = $this->_sections['loop']['iteration'];
$this->_sections['loop']['index_prev'] = $this->_sections['loop']['index'] - $this->_sections['loop']['step'];
$this->_sections['loop']['index_next'] = $this->_sections['loop']['index'] + $this->_sections['loop']['step'];
$this->_sections['loop']['first']      = ($this->_sections['loop']['iteration'] == 1);
$this->_sections['loop']['last']       = ($this->_sections['loop']['iteration'] == $this->_sections['loop']['total']);
?>
			$(".<?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['no']; ?>
").click(function(){
			$("#hd<?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['no']; ?>
").slideToggle("fast");
			var rmb = $("#remember").val();
			var newrmb = "<?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['no']; ?>
";
			if (rmb != newrmb)
			{
				$("#hd" + rmb).hide("fast");
			}
				$("#remember").attr("value","<?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['no']; ?>
");
			});
		<?php endfor; endif; ?>
		});
	</script>
	<dl>
		<?php if ($this->_tpl_vars['totalnum'] == 0): ?>
		<dt>��ϵ� ������ �����ϴ�.</dt>
		<?php else: ?>
		<?php unset($this->_sections['loop']);
$this->_sections['loop']['name'] = 'loop';
$this->_sections['loop']['loop'] = is_array($_loop=$this->_tpl_vars['rsc_list']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['loop']['show'] = true;
$this->_sections['loop']['max'] = $this->_sections['loop']['loop'];
$this->_sections['loop']['step'] = 1;
$this->_sections['loop']['start'] = $this->_sections['loop']['step'] > 0 ? 0 : $this->_sections['loop']['loop']-1;
if ($this->_sections['loop']['show']) {
    $this->_sections['loop']['total'] = $this->_sections['loop']['loop'];
    if ($this->_sections['loop']['total'] == 0)
        $this->_sections['loop']['show'] = false;
} else
    $this->_sections['loop']['total'] = 0;
if ($this->_sections['loop']['show']):

            for ($this->_sections['loop']['index'] = $this->_sections['loop']['start'], $this->_sections['loop']['iteration'] = 1;
                 $this->_sections['loop']['iteration'] <= $this->_sections['loop']['total'];
                 $this->_sections['loop']['index'] += $this->_sections['loop']['step'], $this->_sections['loop']['iteration']++):
$this->_sections['loop']['rownum'] = $this->_sections['loop']['iteration'];
$this->_sections['loop']['index_prev'] = $this->_sections['loop']['index'] - $this->_sections['loop']['step'];
$this->_sections['loop']['index_next'] = $this->_sections['loop']['index'] + $this->_sections['loop']['step'];
$this->_sections['loop']['first']      = ($this->_sections['loop']['iteration'] == 1);
$this->_sections['loop']['last']       = ($this->_sections['loop']['iteration'] == $this->_sections['loop']['total']);
?>
		<dt><a href="#q" class="<?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['no']; ?>
" onclick="return false;"><?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['subject']; ?>
</a></dt>
		<dd id = "hd<?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['no']; ?>
" style="display:none"><?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['content']; ?>
</dd>
		<?php endfor; endif; ?>
		<?php endif; ?>
	</dl>
</div><!-- //faqlist -->

<div class="paging">
	<?php echo $this->_tpl_vars['pagelist']; ?>

</div><!-- //paging -->

<!-- ��ư -->
<?php if ($this->_tpl_vars['ckadm'] == 'o'): ?>
<div class="bbsbtn" style="text-align:right">
	<a href="faq_write.php"><img src="images/common/btn/btn_write.gif" alt="�۾���"></a>
</div>
<?php endif; ?>
<!-- �˻��κ� -->
<form name="schform"  action="faq.php"  method="post">
<input type="hidden" id="remember" name="remember" value="">
<div class="bbssearch">
	<label for="search" class="hidden">�˻��� ����</label>
	<select id="search" name = "search">
		<option value="subject" <?php if ($this->_tpl_vars['search'] == 'subject'): ?>  selected="selected" <?php endif; ?>>����</option>
		<option value="content" <?php if ($this->_tpl_vars['search'] == 'content'): ?>  selected="selected" <?php endif; ?>>�亯</option>
	</select>
	<label for="searinp" class="hidden">�˻��� �Է�</label>
	<input type="text" name="searinp" id="searinp" class="inp" style="width:50%" value="<?php echo $this->_tpl_vars['searinp']; ?>
">
	<input type="image" src="images/common/btn/btn_search.gif" alt="�˻�" >
</div><!-- //bbssearch -->
</form>

				</div><!-- //article -->
			</div><!-- //section -->
		</div><!-- //content -->
	</div><!-- //container -->

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>