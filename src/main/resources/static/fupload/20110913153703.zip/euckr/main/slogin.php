<?php
	session_start();
	require('inc/common.php');
	echo $_SESSION["uid"];
	if (trim($_SESSION["uid"]))
	echo "<script>location.href='../main/board.php';</script>";
	if ($user_id && $pw)
	{
		$getpwd=substr(md5($pw),8,16);
		$mbsql = "select id,name from inun_admin where id ='$user_id' and pw = '$getpwd'";
		$cnt=$DB->num_rows($DB->query($mbsql));
		echo $cnt;
		if ($cnt == 1)
		{
			include 'inc/treuckr.php';
			$result=$DB->query($mbsql);
			$_SESSION["uid"] = $user_id;
			while($row = mysql_fetch_row($result))
			{
				$_SESSION["uname"] = $row[1];
			}

			echo "<script>location.href='board.php';</script>";
		}
		else
		{
			alert('��Ȯ�� ������ �Է��Ͽ��ּ���!');
		}
	}
	$smarty->display('login.tpl');
?>
