<?php /* Smarty version 2.6.26, created on 2011-06-09 13:38:57
         compiled from faq_write.html */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

	<div id="container">

		<div id="sidebar">
			<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/snb04.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		</div><!-- //sidebar -->

		<div id="content">
			<div id="location">
				<span>HOME</span> &gt; Ŀ�´�Ƽ &gt; FAQ
			</div><!-- //location -->

			<h2>FAQ</h2>

<!-- �۾���κ� -->
<form name="faq_frm" id="faq_frm" action="faq_write.php" method="post" onsubmit="return faq_post();">

<div class="faqwrite">
	<dl>
		<dt><label for="title">����</label></dt>
		<dd><input type="text" name="title" id="title" class="inp" style="width:730px"></dd>
		<dt><label for="content1">�亯</label></dt>
		<dd><textarea name="content1" id="content1" cols="70" rows="9" style="width:730px;height:200px"></textarea></dd>
	</dl>
</div><!-- //faqwrite -->

<!-- ��ư -->
<div class="bbsbtn" style="text-align:center">
	<input type="image" src="images/common/btn/btn_confirm.gif" alt="���" >
	<a href="faq.html"><img src="images/common/btn/btn_cancel.gif" alt="���"></a>
</div>

</form>


		</div><!-- //content -->
	</div><!-- //container -->

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>