<?php /* Smarty version 2.6.26, created on 2011-06-09 18:57:47
         compiled from appok2.html */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

	<div id="container">

		<div id="sidebar">
			<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/snb03.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		</div><!-- //sidebar -->

		<div id="content">
			<div id="location">
				<span>HOME</span> &gt; ��ǰ���� �� Ȯ�� &gt; ����Ȯ��
			</div><!-- //location -->

			<h2>����Ȯ��</h2>

<?php unset($this->_sections['loop']);
$this->_sections['loop']['name'] = 'loop';
$this->_sections['loop']['loop'] = is_array($_loop=$this->_tpl_vars['cnts']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['loop']['show'] = true;
$this->_sections['loop']['max'] = $this->_sections['loop']['loop'];
$this->_sections['loop']['step'] = 1;
$this->_sections['loop']['start'] = $this->_sections['loop']['step'] > 0 ? 0 : $this->_sections['loop']['loop']-1;
if ($this->_sections['loop']['show']) {
    $this->_sections['loop']['total'] = $this->_sections['loop']['loop'];
    if ($this->_sections['loop']['total'] == 0)
        $this->_sections['loop']['show'] = false;
} else
    $this->_sections['loop']['total'] = 0;
if ($this->_sections['loop']['show']):

            for ($this->_sections['loop']['index'] = $this->_sections['loop']['start'], $this->_sections['loop']['iteration'] = 1;
                 $this->_sections['loop']['iteration'] <= $this->_sections['loop']['total'];
                 $this->_sections['loop']['index'] += $this->_sections['loop']['step'], $this->_sections['loop']['iteration']++):
$this->_sections['loop']['rownum'] = $this->_sections['loop']['iteration'];
$this->_sections['loop']['index_prev'] = $this->_sections['loop']['index'] - $this->_sections['loop']['step'];
$this->_sections['loop']['index_next'] = $this->_sections['loop']['index'] + $this->_sections['loop']['step'];
$this->_sections['loop']['first']      = ($this->_sections['loop']['iteration'] == 1);
$this->_sections['loop']['last']       = ($this->_sections['loop']['iteration'] == $this->_sections['loop']['total']);
?>
<!-- ����Ȯ�� -->
<form id ="fregisterfrm"  name="fregisterfrm" method="post" action="app.php">
<table cellpadding="0" cellspacing="0" border="1" class="bbsapp">
<tbody>
	<tr>
		<th scope="row" class="thtit">������ȣ</th>
		<td colspan="2"><?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['rcp_no']; ?>
</td>
	</tr>
	<tr>
		<th scope="row" class="thtit">������</th>
		<td colspan="2"><?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['rcp_date']; ?>
</td>
	</tr>
	<tr>
		<th scope="row" class="thtit">�� ��</th>
		<td colspan="2"><?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['rcp_type']; ?>
</td>
	</tr>
	<tr>
		<th scope="row" class="thtit">��������</th>
		<td colspan="2"><?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['t_type']; ?>
</td>
	</tr>
	<tr>
		<th scope="row" rowspan="7" class="thtit" style="width:84px">��ǥ��</th>
		<th scope="row" class="thtit1" style="width:100px">�̸�</th>
		<td><?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['rcp_name']; ?>
</td>
	</tr> 
	<tr>
		<th scope="row" class="thtit1">�ֹε�Ϲ�ȣ</th>
		<td><?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['jumin1']; ?>
-<?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['jumin2']; ?>
</td>
	</tr>
	<tr>
		<th scope="row" class="thtit1">�ּ�</th>
		<td>[<?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['zip']; ?>
] <?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['addr1']; ?>
 <?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['addr2']; ?>
</td>
	</tr>
	<tr>
		<th scope="row" class="thtit1">�ڵ���</th>
		<td><?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['mobile']; ?>
</td>
	</tr>
	<tr>
		<th scope="row" class="thtit1">��ȭ</th>
		<td><?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['phone']; ?>
</td>
	</tr>
	<tr>
		<th scope="row" class="thtit1">E-mail</th>
		<td><?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['email']; ?>
</td>
	</tr>
	<tr>
		<th scope="row" class="thtit1">�Ҽ�</th>
		<td><?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['school']; ?>
 ����(��) <?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['class']; ?>
 �к�(�а�)</td>
	</tr>
	<tr>
		<th scope="row" rowspan="3" class="thtit">��ǰ��</th>
		<th scope="row" class="thtit1">��ǰ����</th>
		<td><?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['subject']; ?>
</td>
	</tr>
	<tr>
		<th scope="row" class="thtit1">����÷��</th>
		<td><a href="#file"><?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['filename1']; ?>
</a></td>
	</tr>
	<tr>
		<th scope="row" class="thtit1">��ǰ����<br>(500�� �̳�)</th>
		<td><?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['content']; ?>
</td>
	</tr>
</tbody>
</table>

<!--sub ���� ����-->
<?php unset($this->_sections['loop2']);
$this->_sections['loop2']['name'] = 'loop2';
$this->_sections['loop2']['loop'] = is_array($_loop=$this->_tpl_vars['subcnts']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['loop2']['show'] = true;
$this->_sections['loop2']['max'] = $this->_sections['loop2']['loop'];
$this->_sections['loop2']['step'] = 1;
$this->_sections['loop2']['start'] = $this->_sections['loop2']['step'] > 0 ? 0 : $this->_sections['loop2']['loop']-1;
if ($this->_sections['loop2']['show']) {
    $this->_sections['loop2']['total'] = $this->_sections['loop2']['loop'];
    if ($this->_sections['loop2']['total'] == 0)
        $this->_sections['loop2']['show'] = false;
} else
    $this->_sections['loop2']['total'] = 0;
if ($this->_sections['loop2']['show']):

            for ($this->_sections['loop2']['index'] = $this->_sections['loop2']['start'], $this->_sections['loop2']['iteration'] = 1;
                 $this->_sections['loop2']['iteration'] <= $this->_sections['loop2']['total'];
                 $this->_sections['loop2']['index'] += $this->_sections['loop2']['step'], $this->_sections['loop2']['iteration']++):
$this->_sections['loop2']['rownum'] = $this->_sections['loop2']['iteration'];
$this->_sections['loop2']['index_prev'] = $this->_sections['loop2']['index'] - $this->_sections['loop2']['step'];
$this->_sections['loop2']['index_next'] = $this->_sections['loop2']['index'] + $this->_sections['loop2']['step'];
$this->_sections['loop2']['first']      = ($this->_sections['loop2']['iteration'] == 1);
$this->_sections['loop2']['last']       = ($this->_sections['loop2']['iteration'] == $this->_sections['loop2']['total']);
?>
	<table cellpadding="0" cellspacing="0" border="1" class="bbsapp">
	<tbody>
		<tr>
			<th scope="row" rowspan="7" class="thtit" style="width:84px">����</th>
			<th scope="row" class="thtit1" style="width:100px">�̸�</th>
			<td>
				<?php echo $this->_tpl_vars['subcnts'][$this->_sections['loop2']['index']]['name']; ?>

			</td>
		</tr> 
		<tr>
			<th scope="row" class="thtit1">�ֹε�Ϲ�ȣ</th>
			<td>
				<?php echo $this->_tpl_vars['subcnts'][$this->_sections['loop2']['index']]['jumin1']; ?>
 - <?php echo $this->_tpl_vars['subcnts'][$this->_sections['loop2']['index']]['jumin2']; ?>

			</td>
		</tr>
		<tr>
			<th scope="row" class="thtit1">�ּ�</th>
			<td>
				<?php echo $this->_tpl_vars['subcnts'][$this->_sections['loop2']['index']]['addr1']; ?>

			</td>
		</tr>
		<tr>
			<th scope="row" class="thtit1">�ڵ���</th>
			<td>
				<?php echo $this->_tpl_vars['subcnts'][$this->_sections['loop2']['index']]['mobile']; ?>

			</td>
		</tr>
		<tr>
			<th scope="row" class="thtit1">��ȭ</th>
			<td>
				<?php echo $this->_tpl_vars['subcnts'][$this->_sections['loop2']['index']]['phone']; ?>

			</td>
		</tr>
		<tr>
			<th scope="row" class="thtit1">E-mail</th>
			<td>
				<?php echo $this->_tpl_vars['subcnts'][$this->_sections['loop2']['index']]['email']; ?>

			</td>
		</tr>
		<tr>
			<th scope="row" class="thtit1">�Ҽ�</th>
			<td>
				<?php echo $this->_tpl_vars['subcnts'][$this->_sections['loop2']['index']]['school']; ?>
 ����(��) <?php echo $this->_tpl_vars['subcnts'][$this->_sections['loop2']['index']]['class']; ?>
 �к�(�а�)
			</td>
		</tr>
	</tbody>
	</table>
<!--sub ���� ����-->
<?php endfor; endif; ?>
<!-- ��ư -->
<div class="bbsbtn" style="text-align:center">
	<a href="<?php echo $this->_tpl_vars['cnts'][$this->_sections['loop']['index']]['gpgurl']; ?>
" target="_blank"><img src="images/common/btn/btn_print.gif" alt="����Ʈ"></a>
	<a href="main.php"><img src="images/common/btn/btn_cancel.gif" alt="���"></a>
	<!--<input type="image" src="images/common/btn/btn_ok.gif" alt="Ȯ��">-->
</div>
</form>
<?php endfor; endif; ?>

		</div><!-- //content -->
	</div><!-- //container -->

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>