<?php /* Smarty version 2.6.26, created on 2011-09-13 14:31:37
         compiled from inc/header.tpl */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="ko">
<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<meta http-equiv="X-UA-Compatible" content="IE=7">
<title> �� &middot; ���л��� �Բ��ϴ� 2011 �۷ι���Ƽ�� ������ </title>
<link rel="stylesheet" type="text/css" href="css/layout.css">
<link rel="stylesheet" type="text/css" href="css/default.css">
<script type="text/javascript" src="js/comm.js" charset="euc-kr"></script>
<script type="text/javascript" src="js/jquery-1.4.min.js" charset="euc-kr"></script>
<script type="text/javascript" src="js/myjquery.js" charset="euc-kr"></script>
<script type="text/javascript" src="js/HuskyEZCreator.js" charset="utf-8"></script>
<script type="text/javascript">
$(document).ready(function(){
	$('.pwdlayer').css("display","none");
//  Loop ���鼭 Ŭ�� ��ũ��Ʈ �ۼ�
	<?php unset($this->_sections['loop']);
$this->_sections['loop']['name'] = 'loop';
$this->_sections['loop']['loop'] = is_array($_loop=$this->_tpl_vars['qa_list']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['loop']['show'] = true;
$this->_sections['loop']['max'] = $this->_sections['loop']['loop'];
$this->_sections['loop']['step'] = 1;
$this->_sections['loop']['start'] = $this->_sections['loop']['step'] > 0 ? 0 : $this->_sections['loop']['loop']-1;
if ($this->_sections['loop']['show']) {
    $this->_sections['loop']['total'] = $this->_sections['loop']['loop'];
    if ($this->_sections['loop']['total'] == 0)
        $this->_sections['loop']['show'] = false;
} else
    $this->_sections['loop']['total'] = 0;
if ($this->_sections['loop']['show']):

            for ($this->_sections['loop']['index'] = $this->_sections['loop']['start'], $this->_sections['loop']['iteration'] = 1;
                 $this->_sections['loop']['iteration'] <= $this->_sections['loop']['total'];
                 $this->_sections['loop']['index'] += $this->_sections['loop']['step'], $this->_sections['loop']['iteration']++):
$this->_sections['loop']['rownum'] = $this->_sections['loop']['iteration'];
$this->_sections['loop']['index_prev'] = $this->_sections['loop']['index'] - $this->_sections['loop']['step'];
$this->_sections['loop']['index_next'] = $this->_sections['loop']['index'] + $this->_sections['loop']['step'];
$this->_sections['loop']['first']      = ($this->_sections['loop']['iteration'] == 1);
$this->_sections['loop']['last']       = ($this->_sections['loop']['iteration'] == $this->_sections['loop']['total']);
?>
	$('.pw<?php echo $this->_tpl_vars['qa_list'][$this->_sections['loop']['index']]['noi']; ?>
').click(function(){
		$('.pwdlayer').fadeIn();
	});
	$('.pw<?php echo $this->_tpl_vars['qa_list'][$this->_sections['loop']['index']]['noi']; ?>
').click(function(){
		$('.pwdlayer').css("display","block");
		var frm = document.pwform;
		frm.no.value = <?php echo $this->_tpl_vars['qa_list'][$this->_sections['loop']['index']]['no']; ?>
;
		return false;
	});
	$('.pw<?php echo $this->_tpl_vars['qa_list'][$this->_sections['loop']['index']]['noi']; ?>
 .pwdbg').click(function(){
		$('.pwdlayer').fadeOut();
	});
	<?php endfor; endif; ?>
//  Loop ����
	$('.pwdclose').click(function(){
		$('.pwdlayer').css("display","none");
		return false;
	});
	
});
</script>
<!--[if IE 6]>
<link rel="stylesheet" type="text/css" href="css/ie6.css">
<script type="text/javascript" src="js/DD_belatedPNG_0.0.7a-min.js"></script>
<script type="text/javascript">DD_belatedPNG.fix('body, h1, h2, h3, h4, h5, h6, div, p, ul, ol, dl, dt, dd, li, a, span, strong, img');</script>
<![endif]-->
<!--[if IE 7]><link rel="stylesheet" type="text/css" href="css/ie7.css"><![endif]-->
<!--[if IE 8]><link rel="stylesheet" type="text/css" href="css/ie8.css"><![endif]-->
</head>

<body>