<?php
	session_start();

	require('inc/common.php');
	$ckadm = $_SESSION["uid"];
	$ckadm = (trim($ckadm)!='admin') ? "x" : "o";
	if ($no)
	{
		$addone="update inun_board set hit = hit+1  where no = '$no' ";
		$result=$DB->query($addone);

		$noa = $no - 1;
		$nob = $no + 1;
		$sql = "select no,subject,content,hit,date(pub_date) as date,imgname,imgname2 from inun_board where no = $no";
		$sqla = "SELECT no,subject,pub_date as date FROM inun_board WHERE no <$no and table_id = 'bd' and status ='o' ORDER BY no LIMIT 0 , 1 ";
		$sqlb = "SELECT no,subject,pub_date as date FROM inun_board WHERE no >$no and table_id = 'bd' and status ='o' ORDER BY no LIMIT 0 , 1 ";

		include 'inc/treuckr.php';
		$result=$DB->query($sql);
		$resulta=$DB->query($sqla);
		$resultb=$DB->query($sqlb);

		$url2 = "?no=".$no."&amp;page=".$page;//�亯�� ���Ǵ� url
		$smarty->assign("url2",$url2);
		while ($row=$DB->fetch_row($result))
		{
			$fileox = ($row['imgname'] =='') ? "x" : 'o'; //���� �ִ��� ������ Ȯ��
			$array[]= array("no"=>$row['no'],"subject"=>$row['subject'],"content"=>$row['content'],"hit"=>$row['hit'],"date"=>$row['date'],"noa"=>$noa,"nob"=>$nob,"imgname"=>$row['imgname'],"imgname2"=>$row['imgname2'],"nofile"=>$nofile,"ckadm"=>$ckadm,"fileox"=>$fileox);
			$smarty->assign("viewctt",$array);
		}
		if ($page)
			{
				$urlpage = "&amp;page=".$page;
				$urllist = "?page=".$page;
				$smarty->assign("urlpage",$urlpage);
				$smarty->assign("urllist",$urllist);
			}
		while ($row2=$DB->fetch_row($resulta))
		{
			
			$smarty->assign("preno",$row2['no']);
			$smarty->assign("presubject",$row2['subject']);
			$smarty->assign("predate",$row2['date']);

		}

		while ($row3=$DB->fetch_row($resultb))
		{
			$smarty->assign("nextno",$row3['no']);
			$smarty->assign("nextsubject",$row3['subject']);
			$smarty->assign("nextdate",$row3['date']);
			$cknext = $row3['no'];
		}
	}
	else
	{
		alert('�������ڰ��� �����ϴ�.','board.php');
	}
	//��������
	//if($ckadm=='o' && $no && $de)
	if( $no && $de)
	{
		$desql="update inun_board set status = 'x'  where no = '$no' and table_id = 'bd'";
		$result=$DB->query($desql);
		echo "<script>location.href='board.php';</script>";
	}
	$smarty->display('board_view.html');
?>
