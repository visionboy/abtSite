<?php /* Smarty version 2.6.26, created on 2011-09-13 15:06:38
         compiled from board.html */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

	

<!-- ����Ʈ�κ� -->
<table cellpadding="0" cellspacing="0" border="1" summary="��ȣ,����,�ۼ���,��¥�� ������ �����ִ� ǥ�Դϴ�." class="bbslist">
<caption>����Ʈ</caption>
<thead>
	<tr>
		<th scope="col" class="first" style="width:10%"><span>��ȣ</span></th>
		<th scope="col" style="width:40%"><span>����</span></th>
		<th scope="col" style="width:10%"><span>�ۼ���</span></th>
		<th scope="col" class="last" style="width:10%"><span>��¥</span></th>
	</tr>
</thead>
<tbody>
	<!-- ������ ������ -->
	<?php if ($this->_tpl_vars['totalnum'] == 0): ?>
	<tr>
		<td colspan="4" class="text_c" >��ϵ� ���� �����ϴ�.</td>
	</tr>
	<?php else: ?>
	<!-- ������ ������ -->
	<?php unset($this->_sections['loop']);
$this->_sections['loop']['name'] = 'loop';
$this->_sections['loop']['loop'] = is_array($_loop=$this->_tpl_vars['rsc_list']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['loop']['show'] = true;
$this->_sections['loop']['max'] = $this->_sections['loop']['loop'];
$this->_sections['loop']['step'] = 1;
$this->_sections['loop']['start'] = $this->_sections['loop']['step'] > 0 ? 0 : $this->_sections['loop']['loop']-1;
if ($this->_sections['loop']['show']) {
    $this->_sections['loop']['total'] = $this->_sections['loop']['loop'];
    if ($this->_sections['loop']['total'] == 0)
        $this->_sections['loop']['show'] = false;
} else
    $this->_sections['loop']['total'] = 0;
if ($this->_sections['loop']['show']):

            for ($this->_sections['loop']['index'] = $this->_sections['loop']['start'], $this->_sections['loop']['iteration'] = 1;
                 $this->_sections['loop']['iteration'] <= $this->_sections['loop']['total'];
                 $this->_sections['loop']['index'] += $this->_sections['loop']['step'], $this->_sections['loop']['iteration']++):
$this->_sections['loop']['rownum'] = $this->_sections['loop']['iteration'];
$this->_sections['loop']['index_prev'] = $this->_sections['loop']['index'] - $this->_sections['loop']['step'];
$this->_sections['loop']['index_next'] = $this->_sections['loop']['index'] + $this->_sections['loop']['step'];
$this->_sections['loop']['first']      = ($this->_sections['loop']['iteration'] == 1);
$this->_sections['loop']['last']       = ($this->_sections['loop']['iteration'] == $this->_sections['loop']['total']);
?>
	<tr>
		<td><?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['noi']; ?>
</td>
		<td class="text_l"><a href="board_view.php?no=<?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['no']; ?>
<?php echo $this->_tpl_vars['urlpage']; ?>
"><?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['subject']; ?>
</a><?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['getnew']; ?>
</td>
		<td><?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['name']; ?>
</td>
		<td><?php echo $this->_tpl_vars['rsc_list'][$this->_sections['loop']['index']]['date']; ?>
</td>
	</tr>
	<?php endfor; endif; ?>
	<?php endif; ?>
</tbody>
</table>
<div class="paging"><?php echo $this->_tpl_vars['pagelist']; ?>
</div>
<!--
<div class="paging">
	<a href="#prev"><img src="images/common/btn/btn_prev.gif" alt="����"></a>
	<strong>[1]</strong>
	<a href="#num">[2]</a>
	<a href="#num">[3]</a>
	<a href="#num">[4]</a>
	<a href="#num">[5]</a>
	<a href="#num">[6]</a>
	<a href="#num">[7]</a>
	<a href="#num">[8]</a>
	<a href="#num">[9]</a>
	<a href="#num">[10]</a>
	<a href="#next"><img src="images/common/btn/btn_next.gif" alt="����"></a>
</div>--><!-- //paging -->

<!-- ��ư -->
<?php if ($this->_tpl_vars['ckadm'] == 'o'): ?>
<div class="bbsbtn" style="text-align:right">
	<a href="board_write.php"><img src="images/common/btn/btn_write.gif" alt="�۾���"></a>
</div>
<?php endif; ?>
<!-- �˻��κ� -->
<form name="schform"  action="board.php"  method="post" onsubmit="return sc_submt()">
<div class="bbssearch">
	<label for="search" class="hidden">�˻��� ����</label>
	<select id="search" name = "search">
		<option value="subject" <?php if ($this->_tpl_vars['search'] == 'subject'): ?>  selected="selected" <?php endif; ?>>����</option>
		<option value="content" <?php if ($this->_tpl_vars['search'] == 'content'): ?>  selected="selected" <?php endif; ?>>����</option>
	</select>
	<label for="searinp" class="hidden">�˻��� �Է�</label>
	<input type="text" name="searinp" id="searinp" class="inp" style="width:50%" value="<?php echo $this->_tpl_vars['searinp']; ?>
">
	<input type="image" src="images/common/btn/btn_search.gif" alt="�˻�" >
</div><!-- //bbssearch -->
</form>



<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>