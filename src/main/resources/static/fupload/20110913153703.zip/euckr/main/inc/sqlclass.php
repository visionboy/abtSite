 <?php  
 class mysql
 {
 	var $conn,$query_num,$row_num,$host,$pass,$user,$db,$row ;
 	function mysql($dbsever,$dbuser,$dbpwd,$db)
 	{
 		$this->host = $dbsever;
 		$this->pass = $dbpwd;
 		$this->user = $dbuser;
 		$this->db = $db;
 		$this->conn=@mysql_connect($this->host,$this->user,$this->pass) or die("");
 		mysql_query("SET NAMES 'gbk'");
             //mysql_query("SET NAMES 'UTF8'");//gb2312
 		mysql_select_db($db);
 	}

 	function query($sql)
 	{
 		$query = @mysql_query($sql,$this->conn) or die("��$sql <br />".$this->geterror());
 		$this->query_num();
 		return $query;
 	}
 	function query_num()
 	{
 		$this->query_num++;
 	}

 	function geterror()
 	{
 		return mysql_error();
 	}
 	function num_rows($query)
 	{
 		$this->row_num = @mysql_num_rows($query);
 		return $this->row_num;
 	}
 	function fetch_row($query)
 	{
    return @mysql_fetch_array($query);

 	}
	function fetch_array($query)
	{	//return	@mysql_fetch_row($query);
		return  @mysql_fetch_array($query);
	}
 }
?>