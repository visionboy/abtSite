<?php /* Smarty version 2.6.26, created on 2011-06-09 19:23:59
         compiled from post.html */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="ko">
<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<meta http-equiv="X-UA-Compatible" content="IE=7">
<title> ������ȣ ã�� </title>
<link rel="stylesheet" type="text/css" href="css/common.css">
<script type="text/javascript" charset="utf-8" >
function   zipg(){ 
	var frm = document.zipsc;

		if (frm.sc.value.replace(/ /g, '') == "" )
		{
			alert("�˻��� ������ �Է��Ͽ� �ּ���!");
			frm.sc.focus();
			return false; 
		}
	}
</script>
<style type="text/css">
.postwrap{width:500px;height:500px;text-align:left}
.postarticle{margin:8px auto;width:474px;border:3px solid #e2e2e2}
.postarticle{
-moz-border-radius-topleft: 8px;
-moz-border-radius-topright:8px;
-moz-border-radius-bottomleft:8px;
-moz-border-radius-bottomright:8px;
-webkit-border-top-left-radius:8px;
-webkit-border-top-right-radius:8px;
-webkit-border-bottom-left-radius:8px;
-webkit-border-bottom-right-radius:8px;
border-top-left-radius:8px;
border-top-right-radius:8px;
border-bottom-left-radius:8px;
border-bottom-right-radius:8px}
.postwrap h1{margin:0px auto;padding:8px 12px;width:450px;background:#e8f0f8;border-bottom:3px solid #e2e2e2}
.psearch{margin:0px auto;padding:10px;width:430px;line-height:150%;text-align:left;border-bottom:2px solid #4f83af}
.psearch p{margin:5px 0px}
.particle{margin:10px auto 20px auto;width:450px;height:300px;overflow:auto;border-bottom:2px solid #4f83af}
.particle p{margin:130px 0px;text-align:center}
.particle ul{}
.particle ul li{padding:5px;line-height:150%;border-bottom:1px solid #ccc}
.particle ul li span{margin-right:2px}
.particle ul li a{}
.particle ul li a:hover{text-decoration:underline}
</style>
</head>

<body style="background:#fff">
<div class="postwrap">
	<form name="zipsc" method="post" action="post.php">
	<div class="postarticle">
		<h1><img src="images/common/title_post.gif" alt="������ȣ ã��"></h1>
		<div class="psearch">
			<p>
				<label for="sc"><strong>������</strong></label>
				<input type="text" name="sc" id="sc" class="inp" style="width:150px" value="<?php echo $this->_tpl_vars['sc']; ?>
">
				<input type="image" src="images/common/btn/btn_search.gif" alt="�˻�" onclick="return zipg();return false;">
				<span>��) ���ﵿ, ������, ������</span>
			</p>
			<p style="margin-bottom:0px">��'(��/��/��)' �̸��� �Է��ϼ���.</p>
		</div><!-- //psearch -->

		<div class="particle">
			<!-- �˻������ ���� ��� -->
			<?php if (( $this->_tpl_vars['totalnum'] == 0 )): ?>
			<p><strong>�˻� ����� �����ϴ�. �ٽ� �˻����ּ���.</strong></p>
			<?php else: ?>
			<!-- �˻������ ���� ��� -->
			<ul>
				<?php unset($this->_sections['loop']);
$this->_sections['loop']['name'] = 'loop';
$this->_sections['loop']['loop'] = is_array($_loop=$this->_tpl_vars['addlist']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['loop']['show'] = true;
$this->_sections['loop']['max'] = $this->_sections['loop']['loop'];
$this->_sections['loop']['step'] = 1;
$this->_sections['loop']['start'] = $this->_sections['loop']['step'] > 0 ? 0 : $this->_sections['loop']['loop']-1;
if ($this->_sections['loop']['show']) {
    $this->_sections['loop']['total'] = $this->_sections['loop']['loop'];
    if ($this->_sections['loop']['total'] == 0)
        $this->_sections['loop']['show'] = false;
} else
    $this->_sections['loop']['total'] = 0;
if ($this->_sections['loop']['show']):

            for ($this->_sections['loop']['index'] = $this->_sections['loop']['start'], $this->_sections['loop']['iteration'] = 1;
                 $this->_sections['loop']['iteration'] <= $this->_sections['loop']['total'];
                 $this->_sections['loop']['index'] += $this->_sections['loop']['step'], $this->_sections['loop']['iteration']++):
$this->_sections['loop']['rownum'] = $this->_sections['loop']['iteration'];
$this->_sections['loop']['index_prev'] = $this->_sections['loop']['index'] - $this->_sections['loop']['step'];
$this->_sections['loop']['index_next'] = $this->_sections['loop']['index'] + $this->_sections['loop']['step'];
$this->_sections['loop']['first']      = ($this->_sections['loop']['iteration'] == 1);
$this->_sections['loop']['last']       = ($this->_sections['loop']['iteration'] == $this->_sections['loop']['total']);
?>
				<li>
					<span>[<?php echo $this->_tpl_vars['addlist'][$this->_sections['loop']['index']]['zipcode']; ?>
]</span>
					<a href='javascript:;' onclick="find_zip('<?php echo $this->_tpl_vars['addlist'][$this->_sections['loop']['index']]['zip1']; ?>
', '<?php echo $this->_tpl_vars['addlist'][$this->_sections['loop']['index']]['zip2']; ?>
', '<?php echo $this->_tpl_vars['addlist'][$this->_sections['loop']['index']]['sido']; ?>
<?php echo $this->_tpl_vars['addlist'][$this->_sections['loop']['index']]['gugun']; ?>
<?php echo $this->_tpl_vars['addlist'][$this->_sections['loop']['index']]['dong']; ?>
');"><?php echo $this->_tpl_vars['addlist'][$this->_sections['loop']['index']]['sido']; ?>
<?php echo $this->_tpl_vars['addlist'][$this->_sections['loop']['index']]['gugun']; ?>
<?php echo $this->_tpl_vars['addlist'][$this->_sections['loop']['index']]['dong']; ?>
<?php echo $this->_tpl_vars['addlist'][$this->_sections['loop']['index']]['bunji']; ?>
</a>
				</li>
				<?php endfor; endif; ?>
				<?php endif; ?>
				
			</ul>
		</div><!-- //particle -->

		<!-- ��ư -->
		<div class="bbsbtn" style="text-align:center">
			<a href="#close" onclick="javascript:self.close(); return false;"><img src="images/common/btn/btn_close.gif" alt="�ݱ�"></a>
		</div>
	</div><!-- //postarticle -->
	</form>
</div><!-- //postwrap -->
	<script type="text/javascript" language="javascript">
	function find_zip(zip1, zip2, addr1)
	{
		var of = opener.document.fregisterfrm;
		of.mb_zip1.value  = zip1;
		of.mb_zip2.value  = zip2;
		of. mb_addr1.value = addr1;
		of. mb_addr2.focus();
		window.close();
		return false;
	}
	</script>
</body>
</html>