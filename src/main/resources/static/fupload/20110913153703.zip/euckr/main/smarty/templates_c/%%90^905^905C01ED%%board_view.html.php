<?php /* Smarty version 2.6.26, created on 2011-09-13 15:07:23
         compiled from board_view.html */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<!-- ����κ� -->
<?php unset($this->_sections['loop']);
$this->_sections['loop']['name'] = 'loop';
$this->_sections['loop']['loop'] = is_array($_loop=$this->_tpl_vars['viewctt']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['loop']['show'] = true;
$this->_sections['loop']['max'] = $this->_sections['loop']['loop'];
$this->_sections['loop']['step'] = 1;
$this->_sections['loop']['start'] = $this->_sections['loop']['step'] > 0 ? 0 : $this->_sections['loop']['loop']-1;
if ($this->_sections['loop']['show']) {
    $this->_sections['loop']['total'] = $this->_sections['loop']['loop'];
    if ($this->_sections['loop']['total'] == 0)
        $this->_sections['loop']['show'] = false;
} else
    $this->_sections['loop']['total'] = 0;
if ($this->_sections['loop']['show']):

            for ($this->_sections['loop']['index'] = $this->_sections['loop']['start'], $this->_sections['loop']['iteration'] = 1;
                 $this->_sections['loop']['iteration'] <= $this->_sections['loop']['total'];
                 $this->_sections['loop']['index'] += $this->_sections['loop']['step'], $this->_sections['loop']['iteration']++):
$this->_sections['loop']['rownum'] = $this->_sections['loop']['iteration'];
$this->_sections['loop']['index_prev'] = $this->_sections['loop']['index'] - $this->_sections['loop']['step'];
$this->_sections['loop']['index_next'] = $this->_sections['loop']['index'] + $this->_sections['loop']['step'];
$this->_sections['loop']['first']      = ($this->_sections['loop']['iteration'] == 1);
$this->_sections['loop']['last']       = ($this->_sections['loop']['iteration'] == $this->_sections['loop']['total']);
?>
<table cellpadding="0" cellspacing="0" border="1" summary="����,�ۼ���,��¥,����,������ ������ �����ִ� ǥ�Դϴ�." class="bbsview">
<caption>����</caption>
<tbody>
	<tr class="first">
		<th scope="col" colspan="6"><span><?php echo $this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['subject']; ?>
</span></th>
	</tr>
	<tr>
		<th scope="row" style="width:14%"><span>�ۼ��� : </span></th>
		<td style="width:30%">������</td>
		<th scope="row" style="width:8%"><span>��¥ : </span></th>
		<td style="width:30%"><?php echo $this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['date']; ?>
</td>
		<th scope="row" style="width:8%"><span>��ȸ : </span></th>
		<td style="width:10%"><?php echo $this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['hit']; ?>
</td>
	</tr>
	<?php if ($this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['fileox'] == 'o'): ?>
	<tr class="last">
		<th scope="row"><span>÷������ : </span></th>
		<td colspan="5"><a href="fupload/<?php echo $this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['imgname2']; ?>
"><?php echo $this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['imgname']; ?>
</a></td>
	</tr>
	<?php endif; ?>
	<tr class="subject">
		<td colspan="6">
			<?php echo $this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['content']; ?>

		</td>
	</tr>
</tbody>
</table>

<!-- ��ư -->
<div class="bbsbtn" style="text-align:center">
	<a href="board.php<?php echo $this->_tpl_vars['urllist']; ?>
"  ><img src="images/common/btn/btn_list.gif" alt="���"></a>
	<?php if ($this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['ckadm'] == 'o'): ?>
	<a href="#update" onclick="mo('board_write.php<?php echo $this->_tpl_vars['url2']; ?>
&amp;mo=o'); return false;"><img src="images/common/btn/btn_modify.gif" alt="����"></a>
	<a href="#delete" onclick="de('board_view.php<?php echo $this->_tpl_vars['url2']; ?>
&amp;de=o'); return false;"><img src="images/common/btn/btn_delete.gif" alt="����"></a>
	<?php endif; ?>
</div>
<?php endfor; endif; ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>