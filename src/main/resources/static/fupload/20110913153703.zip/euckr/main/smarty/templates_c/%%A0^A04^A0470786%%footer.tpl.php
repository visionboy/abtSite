<?php /* Smarty version 2.6.26, created on 2011-09-13 14:31:37
         compiled from inc/footer.tpl */ ?>

</body>
</html>