<?php /* Smarty version 2.6.26, created on 2011-06-09 16:15:47
         compiled from main.html */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="ko">
<head>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<meta http-equiv="X-UA-Compatible" content="IE=7">
<title> �� &middot; ���л��� �Բ��ϴ� 2011 �۷ι���Ƽ�� ������ </title>
<link rel="stylesheet" type="text/css" href="css/main.css">
<script type="text/javascript" src="js/jquery-1.4.min.js" charset="euc-kr"></script>
<!--[if IE 6]>
<link rel="stylesheet" type="text/css" href="css/ie6.css">
<script type="text/javascript" src="js/DD_belatedPNG_0.0.7a-min.js"></script>
<script type="text/javascript">DD_belatedPNG.fix('body, h1, h2, h3, h4, h5, h6, div, p, ul, ol, dl, dt, dd, li, a, span, strong, img');</script>
<![endif]-->
<!--[if IE 7]><link rel="stylesheet" type="text/css" href="css/ie7.css"><![endif]-->
<!--[if IE 8]><link rel="stylesheet" type="text/css" href="css/ie8.css"><![endif]-->
</head>

<body style="background:url(images/common/bg/bg_main.jpg) repeat left top">
<div id="wrap">

	<h1><a href="main.php"><img src="images/common/logo.png" alt="2010-2012 �ѱ��湮����"></a></h1>
	<div id="gnb">
		<ul id="gNavi">
			<li id="mNavi01"><a href="view_intro.php" class="gm1"><img src="images/common/gnb01.png" alt="������ �Ұ�"></a></li>
			<li id="mNavi02"><a href="view_contest.php" class="gm2"><img src="images/common/gnb02.png" alt="����䰭"></a></li>
			<li id="mNavi03"><a href="app.php" class="gm3"><img src="images/common/gnb03.png" alt="��ǰ���� �� Ȯ��"></a></li>
			<li id="mNavi04"><a href="board.php" class="gm4"><img src="images/common/gnb04.png" alt="Ŀ�´�Ƽ"></a></li>
			<li id="mNavi05"><a href="view_info.php" class="gm5"><img src="images/common/gnb05.png" alt="�۷ι���Ƽ�� �Ұ�"></a></li>
		</ul>
	</div><!-- //gnb -->

	<div class="visual">
		<img src="images/common/visual.png" alt="">
	</div>
	<!-- <div id="content">
			<div class="notice">
			<h2>��������</h2>
			<p class="nsubject">��ϵ� ���� �����ϴ�.</p>

			<ul>
				<li><a href="board_view.php">�����Դϴ�. <img src="images/common/ico/ico_n.gif" alt="NEW"></a></li>
				<li><a href="board_view.php">�����Դϴ�. <img src="images/common/ico/ico_n.gif" alt="NEW"></a></li>
				<li><a href="board_view.php">�����Դϴ�. <img src="images/common/ico/ico_n.gif" alt="NEW"></a></li>
			</ul>
			<p class="btn"><a href="board.php" title="�������� ��ü����">MORE</a></p>
		</div>
	</div>//content -->

</div><!-- //wrap -->

<div id="footer">
	<p><img src="images/common/footer.png" alt=""></p>
</div><!-- //footer -->
</body>
</html>