<?php /* Smarty version 2.6.26, created on 2011-06-10 11:06:31
         compiled from qna_view.html */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

	<div id="container">

		<div id="sidebar">
			<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/snb04.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		</div><!-- //sidebar -->

		<div id="content">
			<div id="section">
				<div id="article">
					<div id="location">
						<span>HOME</span> &gt; Ŀ�´�Ƽ &gt; Q&amp;A
					</div><!-- //location -->

					<h2>Q&amp;A</h2>

<?php unset($this->_sections['loop']);
$this->_sections['loop']['name'] = 'loop';
$this->_sections['loop']['loop'] = is_array($_loop=$this->_tpl_vars['viewctt']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['loop']['show'] = true;
$this->_sections['loop']['max'] = $this->_sections['loop']['loop'];
$this->_sections['loop']['step'] = 1;
$this->_sections['loop']['start'] = $this->_sections['loop']['step'] > 0 ? 0 : $this->_sections['loop']['loop']-1;
if ($this->_sections['loop']['show']) {
    $this->_sections['loop']['total'] = $this->_sections['loop']['loop'];
    if ($this->_sections['loop']['total'] == 0)
        $this->_sections['loop']['show'] = false;
} else
    $this->_sections['loop']['total'] = 0;
if ($this->_sections['loop']['show']):

            for ($this->_sections['loop']['index'] = $this->_sections['loop']['start'], $this->_sections['loop']['iteration'] = 1;
                 $this->_sections['loop']['iteration'] <= $this->_sections['loop']['total'];
                 $this->_sections['loop']['index'] += $this->_sections['loop']['step'], $this->_sections['loop']['iteration']++):
$this->_sections['loop']['rownum'] = $this->_sections['loop']['iteration'];
$this->_sections['loop']['index_prev'] = $this->_sections['loop']['index'] - $this->_sections['loop']['step'];
$this->_sections['loop']['index_next'] = $this->_sections['loop']['index'] + $this->_sections['loop']['step'];
$this->_sections['loop']['first']      = ($this->_sections['loop']['iteration'] == 1);
$this->_sections['loop']['last']       = ($this->_sections['loop']['iteration'] == $this->_sections['loop']['total']);
?>
<!-- �������� -->
<table cellpadding="0" cellspacing="0" border="1" summary="����,�ۼ���,��¥,����,������ ������ �����ִ� ǥ�Դϴ�." class="bbsview" style="margin-bottom:20px">
<caption>��������</caption>
<tbody>
	<tr class="first">
		<th scope="col" colspan="6"><span><?php echo $this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['subject']; ?>
</span></th>
	</tr>
	<tr>
		<th scope="row" style="width:14%"><span>�ۼ��� : </span></th>
		<td style="width:30%"><?php echo $this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['qa_name']; ?>
</td>
		<th scope="row" style="width:8%"><span>��¥ : </span></th>
		<td style="width:30%"><?php echo $this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['date']; ?>
</td>
		<th scope="row" style="width:8%"><span>��ȸ : </span></th>
		<td style="width:10%"><?php echo $this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['hit']; ?>
</td>
	</tr>
	<?php if ($this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['fileox'] == 'o'): ?>
	<tr class="last">
		<th scope="row"><span>÷������ : </span></th>
		<td colspan="5"><a href="fupload/<?php echo $this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['imgname2']; ?>
"><?php echo $this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['imgname']; ?>
</a></td>
	</tr>
	<?php endif; ?>
	<tr class="subject">
		<td colspan="6"><?php echo $this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['content']; ?>
</td>
	</tr>
</tbody>
</table>

<!-- �亯���� -->
<!--����� �������� �����ش�-->
<?php if ($this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['ck_ans'] == 'o'): ?>
<h3 class="bbstit">[�亯] <?php echo $this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['subject']; ?>
</h3>
<table cellpadding="0" cellspacing="0" border="1" summary="����,�ۼ���,��¥,����,������ ������ �����ִ� ǥ�Դϴ�." class="bbsview1" style="margin-bottom:20px">
<caption>�亯����</caption>
<tbody>
	<tr class="first">
		<th scope="row" style="width:14%"><span>�ۼ��� : </span></th>
		<td style="width:30%">������</td>
		<th scope="row" style="width:8%"><span>��¥ : </span></th>
		<td style="width:48%"><?php echo $this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['last_edite_date']; ?>
</td>
	</tr>
	<tr class="subject">
		<td colspan="4"><?php echo $this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['Answer']; ?>
</td>
	</tr>
</tbody>
</table>
<?php endif; ?>

<?php if ($this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['ckadm'] == 'o'): ?>
<form id ="answer_frm"  name="answer_frm" method="post" action="qna_view.php<?php echo $this->_tpl_vars['url2']; ?>
">
<!-- �亯�Է� -->
<dl class="qnawrite">
	<dt><label for="actt">�亯���� �Է�</label></dt>
	<dd><textarea name="actt" id="actt" cols="70" rows="9" style="width:740px;height:200px"><?php echo $this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['oans']; ?>
</textarea></dd>
</dl><!-- //qnawrite -->
</form>
<?php endif; ?>

<!-- ��ư -->
<div class="bbsbtn" style="text-align:center">
	<a href="qna.php<?php echo $this->_tpl_vars['urllist']; ?>
"><img src="images/common/btn/btn_list.gif" alt="���"></a>
	<?php if ($this->_tpl_vars['viewctt'][$this->_sections['loop']['index']]['ckadm'] == 'o'): ?>
	<a href="#answer" onclick="ans_post('qna_view.php<?php echo $this->_tpl_vars['url2']; ?>
'); return false;"><img src="images/common/btn/btn_re.gif" alt="�亯"></a>
	<a href="#modify" onclick="mo('qna_write.php<?php echo $this->_tpl_vars['url2']; ?>
&amp;mo=o'); return false;"><img src="images/common/btn/btn_modify.gif" alt="����"></a>
	<a href="#delete" onclick="de('qna_view.php<?php echo $this->_tpl_vars['url2']; ?>
&amp;de=o'); return false;"><img src="images/common/btn/btn_delete.gif" alt="����"></a>
	<?php endif; ?>
</div>
<?php endfor; endif; ?>

				</div><!-- //article -->
			</div><!-- //section -->
		</div><!-- //content -->
	</div><!-- //container -->

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc/footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>